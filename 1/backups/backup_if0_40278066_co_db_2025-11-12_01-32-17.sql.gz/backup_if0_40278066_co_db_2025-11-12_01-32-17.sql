-- نسخة احتياطية لقاعدة البيانات
-- التاريخ: 2025-11-12 01:32:17
-- نوع النسخة: daily
-- قاعدة البيانات: if0_40278066_co_db

SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET AUTOCOMMIT=0;
SET time_zone='+00:00';
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- هيكل الجدول `advance_requests`
DROP TABLE IF EXISTS `advance_requests`;
CREATE TABLE `advance_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `requested_month` int(2) NOT NULL,
  `requested_year` int(4) NOT NULL,
  `salary_id` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `salary_id` (`salary_id`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  KEY `requested_month_year` (`requested_month`,`requested_year`),
  CONSTRAINT `advance_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `advance_requests_ibfk_2` FOREIGN KEY (`salary_id`) REFERENCES `salaries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `advance_requests_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `advance_requests`
-- لا توجد بيانات في الجدول `advance_requests`

-- هيكل الجدول `approvals`
DROP TABLE IF EXISTS `approvals`;
CREATE TABLE `approvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('financial','sales','production','inventory','other') NOT NULL,
  `reference_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `requested_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approval_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`reference_id`),
  KEY `requested_by` (`requested_by`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  CONSTRAINT `approvals_ibfk_1` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `approvals_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `approvals`
-- لا توجد بيانات في الجدول `approvals`

-- هيكل الجدول `attendance`
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `check_in` time DEFAULT NULL,
  `check_out` time DEFAULT NULL,
  `status` enum('present','absent','late','half_day') DEFAULT 'present',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_date` (`user_id`,`date`),
  KEY `date` (`date`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `attendance`
-- لا توجد بيانات في الجدول `attendance`

-- هيكل الجدول `attendance_notification_logs`
DROP TABLE IF EXISTS `attendance_notification_logs`;
CREATE TABLE `attendance_notification_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `notification_kind` enum('checkin','checkout') NOT NULL,
  `sent_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_kind_date` (`user_id`,`notification_kind`,`sent_date`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `attendance_notification_logs`
INSERT INTO `attendance_notification_logs` (`id`, `user_id`, `notification_kind`, `sent_date`, `created_at`) VALUES
('1','3','checkin','2025-11-10','2025-11-10 08:52:49'),
('2','2','checkin','2025-11-11','2025-11-11 17:50:33');

-- هيكل الجدول `attendance_records`
DROP TABLE IF EXISTS `attendance_records`;
CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `check_in_time` datetime NOT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `delay_minutes` int(11) DEFAULT 0,
  `work_hours` decimal(5,2) DEFAULT 0.00,
  `photo_path` varchar(255) DEFAULT NULL,
  `checkout_photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `date` (`date`),
  KEY `user_date` (`user_id`,`date`),
  KEY `check_in_time` (`check_in_time`),
  CONSTRAINT `attendance_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `attendance_records`
INSERT INTO `attendance_records` (`id`, `user_id`, `date`, `check_in_time`, `check_out_time`, `delay_minutes`, `work_hours`, `photo_path`, `checkout_photo_path`, `created_at`, `updated_at`) VALUES
('3','4','2025-11-10','2025-11-10 02:42:14','2025-11-10 21:33:27','0','18.85','deleted_after_send','deleted_after_send','2025-11-10 04:42:14','2025-11-10 21:33:28'),
('4','4','2025-11-11','2025-11-11 00:48:28','2025-11-11 21:41:24','0','20.88','deleted_after_send','deleted_after_send','2025-11-11 00:48:28','2025-11-11 21:41:24'),
('5','4','2025-11-11','2025-11-11 21:41:43',NULL,'762','0.00','deleted_after_send',NULL,'2025-11-11 21:41:43','2025-11-11 21:41:43');

-- هيكل الجدول `audit_logs`
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `old_data` text DEFAULT NULL,
  `new_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `entity_type` (`entity_type`,`entity_id`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `audit_logs`
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `old_value`, `new_value`, `old_data`, `new_data`, `ip_address`, `user_agent`, `created_at`) VALUES
('1','3','delete_webauthn_credential','webauthn_credentials','8',NULL,NULL,NULL,NULL,'154.237.95.195','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-10 08:59:44'),
('60','4','create_product_template','product_templates','5',NULL,'{\"product\":\"\\u0643\",\"status\":\"active\",\"main_supplier_id\":null}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 00:03:02'),
('61','1','create_product_template','product_templates','6',NULL,'{\"product\":\"\\u0645\",\"status\":\"active\",\"main_supplier_id\":null}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 00:05:57'),
('62','4','create_product_template','product_templates','7',NULL,'{\"product\":\"\\u062c\",\"status\":\"active\",\"main_supplier_id\":null}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 00:13:16'),
('63','1','add_olive_oil','olive_oil_stock','6',NULL,'{\"quantity\":10}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 00:15:21'),
('64','4','check_in','attendance','4',NULL,'{\"delay_minutes\":0}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 00:48:28'),
('65','4','request_advance','salary_advance','1',NULL,'{\"amount\":100}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 00:48:41'),
('66','4','create_from_template','production','17',NULL,'{\"template_id\":7,\"quantity\":1,\"batch_number\":\"BATCH-20251111-715\",\"honey_supplier_id\":null,\"packaging_supplier_id\":4}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 00:57:28'),
('67','4','create_from_template','production','19',NULL,'{\"template_id\":7,\"quantity\":1,\"batch_number\":\"BATCH-20251111-610\",\"honey_supplier_id\":null,\"packaging_supplier_id\":4}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 01:34:40'),
('68','4','login','user','4',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 02:41:54'),
('69','4','create_from_template','production','20',NULL,'{\"template_id\":7,\"quantity\":2,\"batch_number\":\"BATCH-20251111-587\",\"honey_supplier_id\":null,\"packaging_supplier_id\":4}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 02:43:04'),
('70','4','logout','user','4',NULL,NULL,NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 03:27:25'),
('71','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 03:27:29'),
('72','1','logout','user','1',NULL,NULL,NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:08:14'),
('73','3','login','user','3',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:08:24'),
('74','3','logout','user','3',NULL,NULL,NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:08:53'),
('75','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:09:37'),
('76','1','logout','user','1',NULL,NULL,NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:09:54'),
('77','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:10:04'),
('78','2','logout','user','2',NULL,NULL,NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:11:43'),
('79','3','login','user','3',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:11:47'),
('80','3','logout','user','3',NULL,NULL,NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:24:18'),
('81','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:24:22'),
('82','1','collect_customer_debt','customer','2',NULL,'{\"collected_amount\":100,\"previous_balance\":500,\"new_balance\":400}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:25:14'),
('83','1','collect_customer_debt','customer','2',NULL,'{\"collected_amount\":100,\"previous_balance\":400,\"new_balance\":300}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:25:19'),
('84','1','update_customer_location','customer','2',NULL,'{\"latitude\":30.585651200000000926593202166259288787841796875,\"longitude\":31.1263232000000016341800801455974578857421875}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:26:39'),
('85','1','collect_customer_debt','customer','2',NULL,'{\"collected_amount\":100,\"previous_balance\":300,\"new_balance\":200}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:26:49'),
('86','6','login','user','6',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.222.99','Mozilla/5.0 (iPhone; CPU iPhone OS 26_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.128 Mobile/15E148 Safari/604.1','2025-11-11 04:28:10'),
('87','1','logout','user','1',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:42:49'),
('88','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:43:14'),
('89','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:43:14'),
('90','2','accountant_approve_advance','salary_advance','1',NULL,'{\"user_id\":4,\"amount\":\"100.00\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:47:47'),
('91','2','logout','user','2',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:48:15'),
('92','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 04:48:27'),
('93','1','logout','user','1',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:21:09'),
('94','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:21:26'),
('95','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (iPhone; CPU iPhone OS 26_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.128 Mobile/15E148 Safari/604.1','2025-11-11 17:22:43'),
('96','2','logout','user','2',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:23:21'),
('97','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:23:26'),
('98','1','logout','user','1',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:25:33'),
('99','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:25:46'),
('100','2','update_profile','user','2',NULL,'{\"full_name\":\"\\u0627\\u0644\\u0645\\u062d\\u0627\\u0633\\u0628 \\u0627\\u0644\\u0623\\u0648\\u0644\",\"email\":\"accountant@company.com\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:56:56'),
('101','2','change_password','user','2',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:57:05'),
('102','2','update_profile','user','2',NULL,'{\"full_name\":\"\\u0627\\u0644\\u0645\\u062d\\u0627\\u0633\\u0628 \\u0627\\u0644\\u0623\\u0648\\u0644\",\"email\":\"accountant@company.com\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:57:05'),
('103','2','logout','user','2',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:57:10'),
('104','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 17:57:15'),
('105','2','logout','user','2',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:05:38'),
('106','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:05:41'),
('107','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:07:58'),
('108','1','delete_all_login_attempts','login_attempts',NULL,NULL,'{\"deleted_count\":33}',NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:19:31'),
('109','1','delete_backup','backup','56',NULL,NULL,NULL,NULL,'154.237.99.51','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:19:44'),
('110','6','login','user','6',NULL,'{\"method\":\"webauthn\"}',NULL,NULL,'197.121.153.118','Mozilla/5.0 (iPhone; CPU iPhone OS 26_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.128 Mobile/15E148 Safari/604.1','2025-11-11 20:40:35'),
('111','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0','2025-11-11 21:31:21'),
('112','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:32:44'),
('113','2','logout','user','2',NULL,NULL,NULL,NULL,'197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:40:41'),
('114','4','login','user','4',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:40:46'),
('115','4','check_out','attendance',NULL,NULL,'{\"work_hours\":20.879999999999999005240169935859739780426025390625}',NULL,NULL,'197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:41:24'),
('116','4','check_in','attendance','5',NULL,'{\"delay_minutes\":762}',NULL,NULL,'197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:41:43'),
('117','4','create_product_template','product_templates','8',NULL,'{\"product\":\"999\",\"status\":\"active\",\"main_supplier_id\":null}',NULL,NULL,'197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:04'),
('118','4','create_product_template','product_templates','9',NULL,'{\"product\":\"777\",\"status\":\"active\",\"main_supplier_id\":null}',NULL,NULL,'197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:50');

-- هيكل الجدول `backups`
DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `backup_type` enum('full','incremental','manual') DEFAULT 'full',
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  CONSTRAINT `backups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `backups`
INSERT INTO `backups` (`id`, `filename`, `file_path`, `file_size`, `backup_type`, `status`, `created_by`, `created_at`) VALUES
('54','backup_if0_40278066_co_db_2025-11-10_20-59-33.sql.gz','/home/vol15_8/infinityfree.com/if0_40239608/htdocs/v1/backups/backup_if0_40278066_co_db_2025-11-10_20-59-33.sql.gz','58949','manual','completed','1','2025-11-10 20:59:34'),
('55','backup_if0_40278066_co_db_2025-11-10_20-59-59.sql.gz','/home/vol15_8/infinityfree.com/if0_40239608/htdocs/v1/backups/backup_if0_40278066_co_db_2025-11-10_20-59-59.sql.gz','58897','','completed',NULL,'2025-11-10 20:59:59'),
('57','backup_if0_40278066_co_db_2025-11-11_18-19-45.sql.gz','/home/vol15_8/infinityfree.com/if0_40239608/htdocs/v1/backups/backup_if0_40278066_co_db_2025-11-11_18-19-45.sql.gz','60072','','completed',NULL,'2025-11-11 18:19:45');

-- هيكل الجدول `barcode_scans`
DROP TABLE IF EXISTS `barcode_scans`;
CREATE TABLE `barcode_scans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_number_id` int(11) NOT NULL,
  `scanned_by` int(11) DEFAULT NULL,
  `scan_location` varchar(255) DEFAULT NULL,
  `scan_type` enum('in','out','verification','sale','return') DEFAULT 'verification',
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_number_id` (`batch_number_id`),
  KEY `scanned_by` (`scanned_by`),
  KEY `scan_type` (`scan_type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `barcode_scans_ibfk_1` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `barcode_scans_ibfk_2` FOREIGN KEY (`scanned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `barcode_scans`
-- لا توجد بيانات في الجدول `barcode_scans`

-- هيكل الجدول `batch_numbers`
DROP TABLE IF EXISTS `batch_numbers`;
CREATE TABLE `batch_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `production_id` int(11) DEFAULT NULL,
  `production_date` date NOT NULL,
  `honey_supplier_id` int(11) DEFAULT NULL,
  `honey_variety` varchar(50) DEFAULT NULL COMMENT 'نوع العسل المستخدم',
  `packaging_materials` text DEFAULT NULL COMMENT 'JSON array of packaging material IDs',
  `packaging_supplier_id` int(11) DEFAULT NULL,
  `all_suppliers` text DEFAULT NULL COMMENT 'JSON array of all suppliers with their materials',
  `workers` text DEFAULT NULL COMMENT 'JSON array of worker IDs',
  `quantity` int(11) NOT NULL DEFAULT 1,
  `status` enum('in_production','completed','in_stock','sold','expired') DEFAULT 'in_production',
  `expiry_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_number` (`batch_number`),
  KEY `product_id` (`product_id`),
  KEY `production_id` (`production_id`),
  KEY `production_date` (`production_date`),
  KEY `honey_supplier_id` (`honey_supplier_id`),
  KEY `packaging_supplier_id` (`packaging_supplier_id`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `batch_numbers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `batch_numbers_ibfk_2` FOREIGN KEY (`production_id`) REFERENCES `production` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_3` FOREIGN KEY (`honey_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_4` FOREIGN KEY (`packaging_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_numbers`
-- لا توجد بيانات في الجدول `batch_numbers`

-- هيكل الجدول `batch_packaging`
DROP TABLE IF EXISTS `batch_packaging`;
CREATE TABLE `batch_packaging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `packaging_material_id` int(11) DEFAULT NULL,
  `packaging_name` varchar(255) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `quantity_used` decimal(12,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `packaging_material_id` (`packaging_material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_packaging`
-- لا توجد بيانات في الجدول `batch_packaging`

-- هيكل الجدول `batch_raw_materials`
DROP TABLE IF EXISTS `batch_raw_materials`;
CREATE TABLE `batch_raw_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `raw_material_id` int(11) DEFAULT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `quantity_used` decimal(12,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `raw_material_id` (`raw_material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_raw_materials`
INSERT INTO `batch_raw_materials` (`id`, `batch_id`, `raw_material_id`, `material_name`, `unit`, `quantity_used`, `created_at`) VALUES
('1','2',NULL,'زيت زيتون','كجم','1.000','2025-11-11 01:34:40'),
('2','3',NULL,'زيت زيتون','كجم','2.000','2025-11-11 02:43:04');

-- هيكل الجدول `batch_workers`
DROP TABLE IF EXISTS `batch_workers`;
CREATE TABLE `batch_workers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_workers`
INSERT INTO `batch_workers` (`id`, `batch_id`, `employee_id`, `created_at`) VALUES
('1','1','4','2025-11-11 00:57:28'),
('2','2','4','2025-11-11 01:34:40'),
('3','3','4','2025-11-11 02:43:04');

-- هيكل الجدول `batches`
DROP TABLE IF EXISTS `batches`;
CREATE TABLE `batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `batch_number` varchar(100) NOT NULL,
  `production_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `status` enum('in_production','completed','cancelled') DEFAULT 'in_production',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_batch_number` (`batch_number`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batches`
INSERT INTO `batches` (`id`, `product_id`, `batch_number`, `production_date`, `expiry_date`, `quantity`, `status`, `created_at`, `updated_at`) VALUES
('1',NULL,'BATCH-20251111-715','2025-11-11','2026-11-11','1','in_production','2025-11-11 00:57:28','2025-11-11 00:57:28'),
('2',NULL,'BATCH-20251111-610','2025-11-11','2026-11-11','1','in_production','2025-11-11 01:34:40','2025-11-11 01:34:40'),
('3',NULL,'BATCH-20251111-587','2025-11-11','2026-11-11','2','in_production','2025-11-11 02:43:04','2025-11-11 02:43:04');

-- هيكل الجدول `beeswax_product_templates`
DROP TABLE IF EXISTS `beeswax_product_templates`;
CREATE TABLE `beeswax_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `beeswax_weight` decimal(10,2) NOT NULL COMMENT 'وزن شمع العسل (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `beeswax_product_templates`
-- لا توجد بيانات في الجدول `beeswax_product_templates`

-- هيكل الجدول `beeswax_stock`
DROP TABLE IF EXISTS `beeswax_stock`;
CREATE TABLE `beeswax_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الوزن (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `beeswax_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `beeswax_stock`
INSERT INTO `beeswax_stock` (`id`, `supplier_id`, `weight`, `created_at`, `updated_at`) VALUES
('1','8','10.00','2025-11-08 04:38:53',NULL);

-- هيكل الجدول `blocked_ips`
DROP TABLE IF EXISTS `blocked_ips`;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `blocked_until` timestamp NULL DEFAULT NULL,
  `blocked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `blocked_until` (`blocked_until`),
  KEY `blocked_by` (`blocked_by`),
  CONSTRAINT `blocked_ips_ibfk_1` FOREIGN KEY (`blocked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `blocked_ips`
-- لا توجد بيانات في الجدول `blocked_ips`

-- هيكل الجدول `collections`
DROP TABLE IF EXISTS `collections`;
CREATE TABLE `collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer','check','other') DEFAULT 'cash',
  `reference_number` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `collected_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `collected_by` (`collected_by`),
  KEY `date` (`date`),
  CONSTRAINT `collections_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `collections_ibfk_2` FOREIGN KEY (`collected_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `collections`
-- لا توجد بيانات في الجدول `collections`

-- هيكل الجدول `customer_order_items`
DROP TABLE IF EXISTS `customer_order_items`;
CREATE TABLE `customer_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `customer_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `customer_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `customer_order_items`
-- لا توجد بيانات في الجدول `customer_order_items`

-- هيكل الجدول `customer_orders`
DROP TABLE IF EXISTS `customer_orders`;
CREATE TABLE `customer_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `order_date` date NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `status` enum('pending','confirmed','in_production','ready','delivered','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `order_date` (`order_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `customer_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_orders_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customer_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `customer_orders`
-- لا توجد بيانات في الجدول `customer_orders`

-- هيكل الجدول `customers`
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `location_captured_at` datetime DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_customers_created_by` (`created_by`),
  CONSTRAINT `fk_customers_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `customers`
INSERT INTO `customers` (`id`, `name`, `phone`, `email`, `address`, `latitude`, `longitude`, `location_captured_at`, `balance`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
('1','1','01000000001',NULL,NULL,NULL,NULL,NULL,'0.00','active','1','2025-11-08 19:37:41',NULL),
('2','2',NULL,NULL,NULL,'30.58565120','31.12632320','2025-11-11 04:26:39','200.00','active','1','2025-11-08 19:38:00','2025-11-11 04:26:49');

-- هيكل الجدول `derivatives_product_templates`
DROP TABLE IF EXISTS `derivatives_product_templates`;
CREATE TABLE `derivatives_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `derivative_type` varchar(100) NOT NULL COMMENT 'نوع المشتق المستخدم',
  `derivative_weight` decimal(10,2) NOT NULL COMMENT 'وزن المشتق (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `derivative_type` (`derivative_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `derivatives_product_templates`
-- لا توجد بيانات في الجدول `derivatives_product_templates`

-- هيكل الجدول `derivatives_stock`
DROP TABLE IF EXISTS `derivatives_stock`;
CREATE TABLE `derivatives_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `derivative_type` varchar(100) NOT NULL COMMENT 'نوع المشتق',
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الوزن (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_derivative` (`supplier_id`,`derivative_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `derivative_type` (`derivative_type`),
  CONSTRAINT `derivatives_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `derivatives_stock`
INSERT INTO `derivatives_stock` (`id`, `supplier_id`, `derivative_type`, `weight`, `created_at`, `updated_at`) VALUES
('1','7','غذاء ملكات','10.50','2025-11-09 09:21:20',NULL);

-- هيكل الجدول `exchange_new_items`
DROP TABLE IF EXISTS `exchange_new_items`;
CREATE TABLE `exchange_new_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `batch_number_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `exchange_new_items_ibfk_1` FOREIGN KEY (`exchange_id`) REFERENCES `product_exchanges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_new_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_new_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `exchange_new_items`
-- لا توجد بيانات في الجدول `exchange_new_items`

-- هيكل الجدول `exchange_return_items`
DROP TABLE IF EXISTS `exchange_return_items`;
CREATE TABLE `exchange_return_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `batch_number_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `exchange_return_items_ibfk_1` FOREIGN KEY (`exchange_id`) REFERENCES `product_exchanges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_return_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_return_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `exchange_return_items`
-- لا توجد بيانات في الجدول `exchange_return_items`

-- هيكل الجدول `exchanges`
DROP TABLE IF EXISTS `exchanges`;
CREATE TABLE `exchanges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_number` varchar(50) NOT NULL,
  `return_id` int(11) DEFAULT NULL,
  `original_sale_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `exchange_date` date NOT NULL,
  `exchange_type` enum('same_product','different_product','upgrade','downgrade') DEFAULT 'same_product',
  `reason` text DEFAULT NULL,
  `original_total` decimal(15,2) NOT NULL,
  `new_total` decimal(15,2) NOT NULL,
  `difference_amount` decimal(15,2) DEFAULT 0.00,
  `difference_paid` tinyint(1) DEFAULT 0,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `exchange_number` (`exchange_number`),
  KEY `return_id` (`return_id`),
  KEY `original_sale_id` (`original_sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `exchange_date` (`exchange_date`),
  KEY `status` (`status`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `exchanges_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `returns` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_2` FOREIGN KEY (`original_sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchanges_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchanges_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `exchanges`
-- لا توجد بيانات في الجدول `exchanges`

-- هيكل الجدول `financial_transactions`
DROP TABLE IF EXISTS `financial_transactions`;
CREATE TABLE `financial_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('expense','income','transfer','payment') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `financial_transactions_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_transactions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `financial_transactions_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `financial_transactions`
-- لا توجد بيانات في الجدول `financial_transactions`

-- هيكل الجدول `finished_products`
DROP TABLE IF EXISTS `finished_products`;
CREATE TABLE `finished_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `batch_number` varchar(100) NOT NULL,
  `production_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity_produced` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number` (`batch_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `finished_products`
INSERT INTO `finished_products` (`id`, `batch_id`, `product_id`, `product_name`, `batch_number`, `production_date`, `expiry_date`, `quantity_produced`, `created_at`) VALUES
('1','1',NULL,'ج','BATCH-20251111-715','2025-11-11','2026-11-11','1','2025-11-11 00:57:28'),
('2','2',NULL,'ج','BATCH-20251111-610','2025-11-11','2026-11-11','1','2025-11-11 01:34:40'),
('3','3',NULL,'ج','BATCH-20251111-587','2025-11-11','2026-11-11','2','2025-11-11 02:43:04');

-- هيكل الجدول `honey_filtration`
DROP TABLE IF EXISTS `honey_filtration`;
CREATE TABLE `honey_filtration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `raw_honey_quantity` decimal(10,2) NOT NULL,
  `filtered_honey_quantity` decimal(10,2) NOT NULL,
  `filtration_loss` decimal(10,2) NOT NULL COMMENT 'الكمية المفقودة (0.5%)',
  `filtration_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `filtration_date` (`filtration_date`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `honey_filtration_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `honey_filtration_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `honey_filtration`
INSERT INTO `honey_filtration` (`id`, `supplier_id`, `raw_honey_quantity`, `filtered_honey_quantity`, `filtration_loss`, `filtration_date`, `notes`, `created_by`, `created_at`) VALUES
('3','2','100.00','99.50','0.50','2025-11-06',NULL,'4','2025-11-06 19:30:31'),
('4','3','60.00','59.70','0.30','2025-11-07',NULL,'4','2025-11-07 08:03:57');

-- هيكل الجدول `honey_stock`
DROP TABLE IF EXISTS `honey_stock`;
CREATE TABLE `honey_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `honey_variety` enum('سدر','جبلي','حبة البركة','موالح','نوارة برسيم','أخرى') DEFAULT 'أخرى' COMMENT 'نوع العسل',
  `raw_honey_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `filtered_honey_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`),
  KEY `honey_variety` (`honey_variety`),
  KEY `supplier_variety` (`supplier_id`,`honey_variety`),
  CONSTRAINT `honey_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `honey_stock`
INSERT INTO `honey_stock` (`id`, `supplier_id`, `honey_variety`, `raw_honey_quantity`, `filtered_honey_quantity`, `created_at`, `updated_at`) VALUES
('2','2','سدر','0.00','99.50','2025-11-06 19:30:18','2025-11-06 19:30:31'),
('3','3','حبة البركة','60.00','59.70','2025-11-07 08:01:18','2025-11-07 08:03:57');

-- هيكل الجدول `inventory_movements`
DROP TABLE IF EXISTS `inventory_movements`;
CREATE TABLE `inventory_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `type` enum('in','out','adjustment','transfer') NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `quantity_before` decimal(10,2) NOT NULL,
  `quantity_after` decimal(10,2) NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL COMMENT 'production, sales, purchase, etc.',
  `reference_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `reference` (`reference_type`,`reference_id`),
  KEY `type` (`type`),
  KEY `created_at` (`created_at`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `inventory_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_movements_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_movements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `inventory_movements`
-- لا توجد بيانات في الجدول `inventory_movements`

-- هيكل الجدول `invoice_items`
DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `invoice_items`
-- لا توجد بيانات في الجدول `invoice_items`

-- هيكل الجدول `invoices`
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `tax_amount` decimal(15,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(15,2) DEFAULT 0.00,
  `remaining_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('draft','sent','paid','partial','overdue','cancelled') DEFAULT 'draft',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `date` (`date`),
  KEY `due_date` (`due_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `invoices`
-- لا توجد بيانات في الجدول `invoices`

-- هيكل الجدول `login_attempts`
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `success` tinyint(1) DEFAULT 0,
  `failure_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `username` (`username`),
  KEY `created_at` (`created_at`),
  KEY `success` (`success`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `login_attempts`
INSERT INTO `login_attempts` (`id`, `username`, `ip_address`, `user_agent`, `success`, `failure_reason`, `created_at`) VALUES
('168','1','197.121.153.118','Mozilla/5.0 (iPhone; CPU iPhone OS 26_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.128 Mobile/15E148 Safari/604.1','0','كلمة مرور خاطئة','2025-11-11 20:40:22'),
('169','admin','197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0','1',NULL,'2025-11-11 21:31:21'),
('170','a','197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','1',NULL,'2025-11-11 21:32:44'),
('171','p','197.121.153.118','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','1',NULL,'2025-11-11 21:40:46');

-- هيكل الجدول `mixed_nuts`
DROP TABLE IF EXISTS `mixed_nuts`;
CREATE TABLE `mixed_nuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(255) NOT NULL COMMENT 'اسم الخلطة',
  `supplier_id` int(11) NOT NULL COMMENT 'المورد الخاص بالخلطة',
  `total_quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'إجمالي الوزن',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `mixed_nuts_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mixed_nuts_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `mixed_nuts`
INSERT INTO `mixed_nuts` (`id`, `batch_name`, `supplier_id`, `total_quantity`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1','1','5','10.000',NULL,'4','2025-11-08 05:35:28',NULL),
('2','تشكيله 2','5','7.000',NULL,'4','2025-11-09 09:22:21',NULL);

-- هيكل الجدول `mixed_nuts_ingredients`
DROP TABLE IF EXISTS `mixed_nuts_ingredients`;
CREATE TABLE `mixed_nuts_ingredients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mixed_nuts_id` int(11) NOT NULL COMMENT 'رقم الخلطة',
  `nuts_stock_id` int(11) NOT NULL COMMENT 'رقم المكسرات المنفردة',
  `quantity` decimal(10,3) NOT NULL COMMENT 'الكمية المستخدمة',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mixed_nuts_id` (`mixed_nuts_id`),
  KEY `nuts_stock_id` (`nuts_stock_id`),
  CONSTRAINT `mixed_nuts_ingredients_ibfk_1` FOREIGN KEY (`mixed_nuts_id`) REFERENCES `mixed_nuts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mixed_nuts_ingredients_ibfk_2` FOREIGN KEY (`nuts_stock_id`) REFERENCES `nuts_stock` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `mixed_nuts_ingredients`
INSERT INTO `mixed_nuts_ingredients` (`id`, `mixed_nuts_id`, `nuts_stock_id`, `quantity`, `created_at`) VALUES
('1','1','1','10.000','2025-11-08 05:35:28'),
('2','2','2','5.000','2025-11-09 09:22:21'),
('3','2','3','2.000','2025-11-09 09:22:21');

-- هيكل الجدول `notification_settings`
DROP TABLE IF EXISTS `notification_settings`;
CREATE TABLE `notification_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role` enum('manager','accountant','sales','production','all') DEFAULT NULL,
  `notification_type` varchar(50) NOT NULL,
  `telegram_enabled` tinyint(1) DEFAULT 0,
  `telegram_chat_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `role` (`role`),
  KEY `notification_type` (`notification_type`),
  CONSTRAINT `notification_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `notification_settings`
-- لا توجد بيانات في الجدول `notification_settings`

-- هيكل الجدول `notifications`
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role` enum('manager','accountant','sales','production','all') DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `link` varchar(255) DEFAULT NULL,
  `read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `role` (`role`),
  KEY `read` (`read`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10972 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `notifications`
INSERT INTO `notifications` (`id`, `user_id`, `role`, `title`, `message`, `type`, `link`, `read`, `created_at`) VALUES
('10773','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:20'),
('10774','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:35'),
('10775','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:35'),
('10776','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:36'),
('10777','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:36'),
('10778','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:36'),
('10779','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:36'),
('10780','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:38'),
('10781','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:38'),
('10782','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:40'),
('10783','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:40'),
('10784','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:40'),
('10785','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:40'),
('10786','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:45'),
('10787','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:45'),
('10788','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:47'),
('10789','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:47'),
('10790','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:47'),
('10791','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:47'),
('10792','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:51'),
('10793','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:51'),
('10794','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:53'),
('10795','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:53'),
('10796','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:53'),
('10797','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:53:53'),
('10798','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:04'),
('10799','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:04'),
('10800','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:13'),
('10801','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:13'),
('10802','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:13'),
('10803','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:13'),
('10804','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:13'),
('10805','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:13'),
('10806','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:14'),
('10807','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:14'),
('10808','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:17'),
('10809','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:17'),
('10810','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:18'),
('10811','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:18'),
('10812','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:27'),
('10813','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:27'),
('10814','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:29'),
('10815','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:29'),
('10816','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:29'),
('10817','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:29'),
('10818','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:34'),
('10819','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:34'),
('10820','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:36'),
('10821','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:36'),
('10822','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:36'),
('10823','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:36'),
('10824','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:41'),
('10825','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:41'),
('10826','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:44'),
('10827','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:44'),
('10828','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:44'),
('10829','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:44'),
('10830','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:50'),
('10831','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:50'),
('10832','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:52'),
('10833','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:52'),
('10834','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:52'),
('10835','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:55:52'),
('10836','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:59:22'),
('10837','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 21:59:22'),
('10838','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:00:49'),
('10839','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:00:49'),
('10840','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:01:37'),
('10841','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:01:37'),
('10842','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:14:36'),
('10843','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:14:36'),
('10844','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:14:38'),
('10845','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:14:38'),
('10846','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:15:04'),
('10847','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:15:04'),
('10848','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:15:21'),
('10849','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:15:21'),
('10850','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:15:25'),
('10851','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:15:25'),
('10852','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:15:46'),
('10853','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:15:46'),
('10854','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:05'),
('10855','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:05'),
('10856','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:17'),
('10857','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:17'),
('10858','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:20'),
('10859','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:20'),
('10860','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:26'),
('10861','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:26'),
('10862','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:56'),
('10863','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:16:56'),
('10864','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:17:10'),
('10865','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:17:10'),
('10866','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:17:20'),
('10867','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:17:20'),
('10868','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:17:26'),
('10869','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:17:26'),
('10870','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:22:24'),
('10871','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:22:24'),
('10872','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:29:16'),
('10873','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:29:16'),
('10874','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:29:18'),
('10875','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:29:18'),
('10876','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:29:21'),
('10877','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:29:21'),
('10878','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:29:34'),
('10879','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:29:34'),
('10880','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:30:14'),
('10881','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:30:14'),
('10882','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:30:19'),
('10883','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:30:19'),
('10884','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:30:24'),
('10885','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:30:24'),
('10886','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:30:45'),
('10887','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:30:45'),
('10888','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:02'),
('10889','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:02'),
('10890','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:08'),
('10891','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:08'),
('10892','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:11'),
('10893','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:11'),
('10894','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:14'),
('10895','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:14'),
('10896','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:23'),
('10897','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:23'),
('10898','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:23'),
('10899','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:23'),
('10900','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:28'),
('10901','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:28'),
('10902','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:31'),
('10903','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:31'),
('10904','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:54'),
('10905','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:54'),
('10906','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:57'),
('10907','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:57'),
('10908','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:58'),
('10909','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:34:58'),
('10910','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:02'),
('10911','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:02'),
('10912','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:02'),
('10913','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:02'),
('10914','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:05'),
('10915','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:05'),
('10916','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:15'),
('10917','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:15'),
('10918','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:15'),
('10919','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:15'),
('10920','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:18'),
('10921','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:18'),
('10922','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:20'),
('10923','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:20'),
('10924','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:23'),
('10925','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:23'),
('10926','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:26'),
('10927','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:35:26'),
('10928','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:37:47'),
('10929','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:37:47'),
('10930','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:37:55'),
('10931','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:37:55'),
('10932','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:38:09'),
('10933','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:38:09'),
('10934','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:38:09'),
('10935','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:38:09'),
('10936','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:05'),
('10937','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:05'),
('10938','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:20'),
('10939','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:20'),
('10940','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:25'),
('10941','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:25'),
('10942','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:30'),
('10943','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:30'),
('10944','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:41'),
('10945','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:39:41'),
('10946','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:04'),
('10947','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:04'),
('10948','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:05'),
('10949','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:05'),
('10950','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:09'),
('10951','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:09'),
('10952','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:13'),
('10953','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:13'),
('10954','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:23'),
('10955','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:23'),
('10956','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:26'),
('10957','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:26'),
('10958','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:32'),
('10959','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:32'),
('10960','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:50'),
('10961','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:50'),
('10962','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:50'),
('10963','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:50'),
('10964','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:53'),
('10965','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:40:53'),
('10966','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:41:00'),
('10967','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:41:00'),
('10968','1',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:41:06'),
('10969','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-11 22:41:06'),
('10970','1',NULL,'تقرير المخازن اليومي','تم إرسال تقرير المخازن منخفضة الكمية إلى شات Telegram.','info',NULL,'0','2025-11-12 01:32:17'),
('10971','6',NULL,'تقرير المخازن اليومي','تم إرسال تقرير المخازن منخفضة الكمية إلى شات Telegram.','info',NULL,'0','2025-11-12 01:32:17');

-- هيكل الجدول `nuts_stock`
DROP TABLE IF EXISTS `nuts_stock`;
CREATE TABLE `nuts_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `nut_type` varchar(100) NOT NULL COMMENT 'نوع المكسرات (لوز، جوز، فستق، إلخ)',
  `quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالكيلوجرام',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT 'سعر الكيلو',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`),
  KEY `nut_type` (`nut_type`),
  KEY `supplier_nut` (`supplier_id`,`nut_type`),
  CONSTRAINT `nuts_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `nuts_stock`
INSERT INTO `nuts_stock` (`id`, `supplier_id`, `nut_type`, `quantity`, `unit_price`, `notes`, `created_at`, `updated_at`) VALUES
('1','5','عين جمل','0.000',NULL,NULL,'2025-11-08 05:35:00','2025-11-08 05:35:28'),
('2','5','بندق','5.000',NULL,NULL,'2025-11-08 05:36:51','2025-11-09 09:22:21'),
('3','5','لوز','3.000',NULL,NULL,'2025-11-08 05:39:18','2025-11-09 09:22:21');

-- هيكل الجدول `olive_oil_product_templates`
DROP TABLE IF EXISTS `olive_oil_product_templates`;
CREATE TABLE `olive_oil_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `olive_oil_quantity` decimal(10,2) NOT NULL COMMENT 'كمية زيت الزيتون (لتر)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `olive_oil_product_templates`
-- لا توجد بيانات في الجدول `olive_oil_product_templates`

-- هيكل الجدول `olive_oil_stock`
DROP TABLE IF EXISTS `olive_oil_stock`;
CREATE TABLE `olive_oil_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية (لتر)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `olive_oil_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `olive_oil_stock`
INSERT INTO `olive_oil_stock` (`id`, `supplier_id`, `quantity`, `created_at`, `updated_at`) VALUES
('1','6','106.00','2025-11-09 09:20:46','2025-11-11 02:43:04');

-- هيكل الجدول `packaging_damage_logs`
DROP TABLE IF EXISTS `packaging_damage_logs`;
CREATE TABLE `packaging_damage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `source_table` enum('packaging_materials','products') NOT NULL DEFAULT 'packaging_materials',
  `quantity_before` decimal(15,4) DEFAULT 0.0000,
  `damaged_quantity` decimal(15,4) NOT NULL,
  `quantity_after` decimal(15,4) DEFAULT 0.0000,
  `unit` varchar(50) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `recorded_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `recorded_by` (`recorded_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `packaging_damage_logs`
INSERT INTO `packaging_damage_logs` (`id`, `material_id`, `material_name`, `source_table`, `quantity_before`, `damaged_quantity`, `quantity_after`, `unit`, `reason`, `recorded_by`, `created_at`) VALUES
('1','17','أغطية - غطاء 43م','packaging_materials','10.0000','1.0000','9.0000','قطعة','كده','4','2025-11-08 06:45:57'),
('2','14','أغطية - غطاء سنبله','packaging_materials','100.0000','10.0000','90.0000','قطعة','باظ','4','2025-11-09 01:13:04');

-- هيكل الجدول `packaging_materials`
DROP TABLE IF EXISTS `packaging_materials`;
CREATE TABLE `packaging_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` varchar(50) NOT NULL COMMENT 'معرف فريد مثل PKG-001',
  `name` varchar(255) NOT NULL COMMENT 'اسم مأخوذ من type + specifications',
  `alias` varchar(255) DEFAULT NULL,
  `type` varchar(100) NOT NULL COMMENT 'نوع الأداة مثل: عبوات زجاجية',
  `specifications` varchar(255) DEFAULT NULL COMMENT 'المواصفات مثل: برطمان 720م دائري',
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(50) DEFAULT 'قطعة',
  `unit_price` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_id` (`material_id`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `packaging_materials`
INSERT INTO `packaging_materials` (`id`, `material_id`, `name`, `alias`, `type`, `specifications`, `quantity`, `unit`, `unit_price`, `status`, `created_at`, `updated_at`) VALUES
('1','PKG-001','صناديق كرتون - كراتين كيلو',NULL,'صناديق كرتون','كراتين كيلو','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('2','PKG-002','صناديق كرتون - كراتين نصف',NULL,'صناديق كرتون','كراتين نصف','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('3','PKG-003','عبوات زجاجية - برطمان 720م دائري',NULL,'عبوات زجاجية','برطمان 720م دائري','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('4','PKG-004','عبوات زجاجية - برطمان 370م دائري',NULL,'عبوات زجاجية','برطمان 370م دائري','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('5','PKG-005','عبوات زجاجية - برطمان 290م سداسي',NULL,'عبوات زجاجية','برطمان 290م سداسي','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('6','PKG-006','عبوات زجاجية - برطمان 285م فازه',NULL,'عبوات زجاجية','برطمان 285م فازه','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('7','PKG-007','عبوات زجاجية - برطمان 212 ملل',NULL,'عبوات زجاجية','برطمان 212 ملل','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('8','PKG-008','عبوات زجاجية - برطمان 100 ملل',NULL,'عبوات زجاجية','برطمان 100 ملل','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('9','PKG-009','عبوات زجاجية - برطمان 1ك مشرشر',NULL,'عبوات زجاجية','برطمان 1ك مشرشر','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('10','PKG-010','عبوات زجاجية - برطمان نص ك مشرشر',NULL,'عبوات زجاجية','برطمان نص ك مشرشر','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('11','PKG-011','عبوات بلاستيكية - سكويز 400م',NULL,'عبوات بلاستيكية','سكويز 400م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('12','PKG-012','عبوات بلاستيكية - سكويز 200م',NULL,'عبوات بلاستيكية','سكويز 200م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('13','PKG-013','أغطية - غطاء 63م متعدد',NULL,'أغطية','غطاء 63م متعدد','10.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-08 06:09:54'),
('14','PKG-014','أغطية - غطاء سنبله',NULL,'أغطية','غطاء سنبله','90.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-09 01:13:04'),
('15','PKG-015','أغطية - غطاء 82م',NULL,'أغطية','غطاء 82م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('16','PKG-016','أغطية - غطاء زيت زيتون متعدد',NULL,'أغطية','غطاء زيت زيتون متعدد','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('17','PKG-017','أغطية - غطاء 43م','2000','أغطية','غطاء 43م','5.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-11 02:43:04'),
('18','PKG-018','أغطية - غطاء سكويز 400م',NULL,'أغطية','غطاء سكويز 400م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('19','PKG-019','أغطية - غطاء فليبتوب 200م ذهبي',NULL,'أغطية','غطاء فليبتوب 200م ذهبي','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('20','PKG-020','أغطية - غطاء فليبتوب 200م اسود',NULL,'أغطية','غطاء فليبتوب 200م اسود','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('21','PKG-021','أغطية - غطاء دبدوب',NULL,'أغطية','غطاء دبدوب','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('22','PKG-022','طبات - طبه دبدوب',NULL,'طبات','طبه دبدوب','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('23','PKG-023','طبات - طبه سنبله',NULL,'طبات','طبه سنبله','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('24','PKG-024','طبات - طبه سكويز 200م',NULL,'طبات','طبه سكويز 200م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('25','PKG-025','طبات - طبه سكويز 400م',NULL,'طبات','طبه سكويز 400م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('26','PKG-026','طبات - طبه فليبتوب 200م',NULL,'طبات','طبه فليبتوب 200م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('27','PKG-027','عبوات بلاستيكية - علبة شمع نص ك',NULL,'عبوات بلاستيكية','علبة شمع نص ك','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('28','PKG-028','عبوات بلاستيكية - علبة شمع ك',NULL,'عبوات بلاستيكية','علبة شمع ك','10.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-08 04:42:43'),
('29','PKG-029','عبوات بلاستيكية - جركن 20 ل',NULL,'عبوات بلاستيكية','جركن 20 ل','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('30','PKG-030','أكياس - أكياس',NULL,'أكياس','أكياس','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('31','PKG-031','لوازم التعبئة - شريط لاصق',NULL,'لوازم التعبئة','شريط لاصق','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('32','PKG-032','عبوات زجاجية - برطمان دبدوب',NULL,'عبوات زجاجية','برطمان دبدوب','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('33','PKG-033','عبوات زجاجية - برطمان دبله',NULL,'عبوات زجاجية','برطمان دبله','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('34','PKG-034','عبوات بلاستيكية - برطمان سكويز 200',NULL,'عبوات بلاستيكية','برطمان سكويز 200','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('35','PKG-035','عبوات بلاستيكية - برطمان سكويز 400',NULL,'عبوات بلاستيكية','برطمان سكويز 400','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('36','PKG-036','عبوات زجاجية - برطمان سنبله ك',NULL,'عبوات زجاجية','برطمان سنبله ك','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('37','PKG-037','عبوات بلاستيكية - بابلز',NULL,'عبوات بلاستيكية','بابلز','8.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-10 06:31:06');

-- هيكل الجدول `packaging_usage_logs`
DROP TABLE IF EXISTS `packaging_usage_logs`;
CREATE TABLE `packaging_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `material_code` varchar(100) DEFAULT NULL,
  `source_table` enum('packaging_materials','products') NOT NULL DEFAULT 'packaging_materials',
  `quantity_before` decimal(15,4) DEFAULT 0.0000,
  `quantity_used` decimal(15,4) NOT NULL,
  `quantity_after` decimal(15,4) DEFAULT 0.0000,
  `unit` varchar(50) DEFAULT NULL,
  `used_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `used_by` (`used_by`),
  KEY `source_table` (`source_table`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `packaging_usage_logs`
INSERT INTO `packaging_usage_logs` (`id`, `material_id`, `material_name`, `material_code`, `source_table`, `quantity_before`, `quantity_used`, `quantity_after`, `unit`, `used_by`, `created_at`) VALUES
('1','37','عبوات بلاستيكية - بابلز','PKG-037','packaging_materials','10.0000','1.0000','9.0000','قطعة','4','2025-11-10 04:53:30'),
('2','37','عبوات بلاستيكية - بابلز','PKG-037','packaging_materials','9.0000','1.0000','8.0000','قطعة','4','2025-11-10 06:31:06');

-- هيكل الجدول `payment_reminders`
DROP TABLE IF EXISTS `payment_reminders`;
CREATE TABLE `payment_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_schedule_id` int(11) NOT NULL,
  `reminder_type` enum('before_due','on_due','after_due','custom') DEFAULT 'before_due',
  `reminder_date` date NOT NULL,
  `days_before_due` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `sent_to` enum('sales_rep','customer','both') DEFAULT 'sales_rep',
  `sent_status` enum('pending','sent','failed') DEFAULT 'pending',
  `sent_at` timestamp NULL DEFAULT NULL,
  `sent_method` enum('notification','telegram','sms','email') DEFAULT 'notification',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `payment_schedule_id` (`payment_schedule_id`),
  KEY `reminder_date` (`reminder_date`),
  KEY `sent_status` (`sent_status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_reminders_ibfk_1` FOREIGN KEY (`payment_schedule_id`) REFERENCES `payment_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_reminders_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `payment_reminders`
-- لا توجد بيانات في الجدول `payment_reminders`

-- هيكل الجدول `payment_schedules`
DROP TABLE IF EXISTS `payment_schedules`;
CREATE TABLE `payment_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `due_date` date NOT NULL,
  `payment_date` date DEFAULT NULL,
  `status` enum('pending','paid','overdue','cancelled') DEFAULT 'pending',
  `installment_number` int(11) DEFAULT 1,
  `total_installments` int(11) DEFAULT 1,
  `notes` text DEFAULT NULL,
  `reminder_sent` tinyint(1) DEFAULT 0,
  `reminder_sent_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `due_date` (`due_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_schedules_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `payment_schedules`
-- لا توجد بيانات في الجدول `payment_schedules`

-- هيكل الجدول `permissions`
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `permissions`
INSERT INTO `permissions` (`id`, `name`, `description`, `category`, `created_at`) VALUES
('1','view_financial','عرض البيانات المالية','financial','2025-11-04 08:14:12'),
('2','create_financial','إنشاء معاملات مالية','financial','2025-11-04 08:14:12'),
('3','approve_financial','الموافقة على المعاملات المالية','financial','2025-11-04 08:14:12'),
('4','view_sales','عرض المبيعات','sales','2025-11-04 08:14:12'),
('5','create_sales','إنشاء مبيعات','sales','2025-11-04 08:14:12'),
('6','approve_sales','الموافقة على المبيعات','sales','2025-11-04 08:14:12'),
('7','view_inventory','عرض المخزون','inventory','2025-11-04 08:14:12'),
('8','manage_inventory','إدارة المخزون','inventory','2025-11-04 08:14:12'),
('9','view_production','عرض الإنتاج','production','2025-11-04 08:14:12'),
('10','manage_production','إدارة الإنتاج','production','2025-11-04 08:14:12'),
('11','view_reports','عرض التقارير','reports','2025-11-04 08:14:12'),
('12','generate_reports','توليد التقارير','reports','2025-11-04 08:14:12'),
('13','manage_users','إدارة المستخدمين','users','2025-11-04 08:14:12'),
('14','manage_permissions','إدارة الصلاحيات','users','2025-11-04 08:14:12'),
('15','view_audit_logs','عرض سجل التدقيق','system','2025-11-04 08:14:12'),
('16','manage_settings','إدارة إعدادات النظام','system','2025-11-04 08:14:12');

-- هيكل الجدول `product_exchanges`
DROP TABLE IF EXISTS `product_exchanges`;
CREATE TABLE `product_exchanges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `original_invoice_id` int(11) DEFAULT NULL,
  `original_sale_id` int(11) DEFAULT NULL,
  `return_id` int(11) DEFAULT NULL,
  `exchange_date` date NOT NULL,
  `exchange_type` enum('same_product','different_product','upgrade','downgrade') DEFAULT 'same_product',
  `reason` text DEFAULT NULL,
  `original_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `new_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `difference_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `exchange_number` (`exchange_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `original_invoice_id` (`original_invoice_id`),
  KEY `original_sale_id` (`original_sale_id`),
  KEY `return_id` (`return_id`),
  KEY `status` (`status`),
  KEY `product_exchanges_ibfk_6` (`approved_by`),
  KEY `product_exchanges_ibfk_7` (`processed_by`),
  KEY `product_exchanges_ibfk_8` (`created_by`),
  CONSTRAINT `product_exchanges_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_exchanges_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_exchanges_ibfk_3` FOREIGN KEY (`original_invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_4` FOREIGN KEY (`original_sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_5` FOREIGN KEY (`return_id`) REFERENCES `sales_returns` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_7` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_exchanges`
-- لا توجد بيانات في الجدول `product_exchanges`

-- هيكل الجدول `product_template_materials`
DROP TABLE IF EXISTS `product_template_materials`;
CREATE TABLE `product_template_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL COMMENT 'القالب',
  `material_type` enum('honey','other','ingredient') NOT NULL DEFAULT 'other' COMMENT 'نوع المادة',
  `material_name` varchar(255) NOT NULL COMMENT 'اسم المادة',
  `material_id` int(11) DEFAULT NULL COMMENT 'معرف المادة (supplier_id للعسل أو product_id للمواد الأخرى)',
  `quantity_per_unit` decimal(10,3) NOT NULL COMMENT 'الكمية لكل وحدة منتج',
  `unit` varchar(50) DEFAULT 'كجم' COMMENT 'وحدة القياس',
  `is_required` tinyint(1) DEFAULT 1 COMMENT 'هل المادة مطلوبة',
  `notes` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0 COMMENT 'ترتيب العرض',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `material_type` (`material_type`),
  CONSTRAINT `product_template_materials_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `product_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_template_materials`
INSERT INTO `product_template_materials` (`id`, `template_id`, `material_type`, `material_name`, `material_id`, `quantity_per_unit`, `unit`, `is_required`, `notes`, `sort_order`, `created_at`) VALUES
('1','7','ingredient','زيت زيتون',NULL,'1.000','كجم','1',NULL,'0','2025-11-11 00:13:16'),
('2','8','honey','عسل مصفى',NULL,'1.000','كجم','1',NULL,'0','2025-11-11 22:40:04'),
('3','9','honey','عسل مصفى',NULL,'1.000','كجم','1',NULL,'0','2025-11-11 22:40:50');

-- هيكل الجدول `product_template_packaging`
DROP TABLE IF EXISTS `product_template_packaging`;
CREATE TABLE `product_template_packaging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL COMMENT 'القالب',
  `packaging_material_id` int(11) DEFAULT NULL COMMENT 'مادة التعبئة',
  `packaging_name` varchar(255) DEFAULT NULL COMMENT 'اسم أداة التعبئة',
  `quantity_per_unit` decimal(10,3) NOT NULL DEFAULT 1.000 COMMENT 'الكمية لكل وحدة منتج',
  `unit` varchar(50) DEFAULT 'قطعة' COMMENT 'الوحدة',
  `is_required` tinyint(1) DEFAULT 1 COMMENT 'هل أداة التعبئة مطلوبة',
  `notes` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0 COMMENT 'ترتيب العرض',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `packaging_material_id` (`packaging_material_id`),
  CONSTRAINT `product_template_packaging_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `product_templates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_template_packaging_ibfk_2` FOREIGN KEY (`packaging_material_id`) REFERENCES `packaging_materials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_template_packaging`
INSERT INTO `product_template_packaging` (`id`, `template_id`, `packaging_material_id`, `packaging_name`, `quantity_per_unit`, `unit`, `is_required`, `notes`, `sort_order`, `created_at`, `updated_at`) VALUES
('5','7','17','أغطية - غطاء 43م','1.000','قطعة','1',NULL,'0','2025-11-11 00:13:16',NULL),
('6','8','17','أغطية - غطاء 43م','1.000','قطعة','1',NULL,'0','2025-11-11 22:40:04',NULL),
('7','9','13','أغطية - غطاء 63م متعدد','1.000','قطعة','1',NULL,'0','2025-11-11 22:40:50',NULL);

-- هيكل الجدول `product_template_raw_materials`
DROP TABLE IF EXISTS `product_template_raw_materials`;
CREATE TABLE `product_template_raw_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `material_name` varchar(255) NOT NULL COMMENT 'اسم المادة (مثل: مكسرات، لوز، إلخ)',
  `quantity_per_unit` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالجرام',
  `unit` varchar(50) DEFAULT 'جرام',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_template_raw_materials`
INSERT INTO `product_template_raw_materials` (`id`, `template_id`, `material_name`, `quantity_per_unit`, `unit`, `created_at`) VALUES
('1','5','زيت زيتون','1.000','كجم','2025-11-11 00:03:02'),
('2','6','شمع عسل','1.000','كجم','2025-11-11 00:05:57'),
('3','7','زيت زيتون','1.000','كجم','2025-11-11 00:13:16'),
('4','8','عسل مصفى','1.000','كجم','2025-11-11 22:40:04'),
('5','9','عسل مصفى','1.000','كجم','2025-11-11 22:40:50');

-- هيكل الجدول `product_templates`
DROP TABLE IF EXISTS `product_templates`;
CREATE TABLE `product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(255) NOT NULL COMMENT 'اسم القالب',
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL COMMENT 'اسم المنتج',
  `honey_quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'كمية العسل بالجرام',
  `template_type` varchar(50) DEFAULT 'general',
  `source_template_id` int(11) DEFAULT NULL,
  `main_supplier_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `details_json` longtext DEFAULT NULL,
  `target_quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية المستهدفة',
  `unit` varchar(50) DEFAULT 'قطعة' COMMENT 'الوحدة',
  `description` text DEFAULT NULL COMMENT 'الوصف',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) NOT NULL COMMENT 'منشئ القالب',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `source_template_id` (`source_template_id`),
  KEY `main_supplier_id` (`main_supplier_id`),
  CONSTRAINT `product_templates_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_templates`
INSERT INTO `product_templates` (`id`, `template_name`, `product_id`, `product_name`, `honey_quantity`, `template_type`, `source_template_id`, `main_supplier_id`, `notes`, `details_json`, `target_quantity`, `unit`, `description`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
('7','',NULL,'ج','0.000','advanced',NULL,NULL,NULL,'{\"product_name\":\"ج\",\"status\":\"active\",\"main_supplier_id\":null,\"notes\":\"\",\"raw_materials\":[{\"type\":\"olive_oil\",\"name\":\"زيت زيتون\",\"supplier_id\":null,\"honey_variety\":null,\"quantity\":1,\"unit\":\"كجم\"}],\"packaging\":[{\"packaging_material_id\":17,\"quantity_per_unit\":1}],\"submitted_at\":\"2025-11-11T00:13:16+02:00\",\"submitted_by\":4}','0.00','قطعة',NULL,'active','4','2025-11-11 00:13:16',NULL),
('8','',NULL,'999','1.000','advanced',NULL,NULL,NULL,'{\"product_name\":\"999\",\"status\":\"active\",\"main_supplier_id\":null,\"notes\":\"\",\"raw_materials\":[{\"type\":\"honey_filtered\",\"name\":\"عسل مصفى\",\"supplier_id\":null,\"honey_variety\":null,\"quantity\":1,\"unit\":\"كجم\"}],\"packaging\":[{\"packaging_material_id\":17,\"quantity_per_unit\":1}],\"submitted_at\":\"2025-11-11T22:40:04+02:00\",\"submitted_by\":4}','0.00','قطعة',NULL,'active','4','2025-11-11 22:40:04',NULL),
('9','',NULL,'777','1.000','advanced',NULL,NULL,NULL,'{\"product_name\":\"777\",\"status\":\"active\",\"main_supplier_id\":null,\"notes\":\"\",\"raw_materials\":[{\"type\":\"honey_filtered\",\"name\":\"عسل مصفى\",\"supplier_id\":null,\"honey_variety\":null,\"quantity\":1,\"unit\":\"كجم\"}],\"packaging\":[{\"packaging_material_id\":13,\"quantity_per_unit\":1}],\"submitted_at\":\"2025-11-11T22:40:50+02:00\",\"submitted_by\":4}','0.00','قطعة',NULL,'active','4','2025-11-11 22:40:50',NULL);

-- هيكل الجدول `production`
DROP TABLE IF EXISTS `production`;
CREATE TABLE `production` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `customer_order_item_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `production_date` date NOT NULL,
  `worker_id` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `production_line_id` int(11) DEFAULT NULL COMMENT 'خط الإنتاج',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `worker_id` (`worker_id`),
  KEY `production_date` (`production_date`),
  KEY `customer_order_item_id` (`customer_order_item_id`),
  KEY `production_line_id` (`production_line_id`),
  CONSTRAINT `production_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_ibfk_line` FOREIGN KEY (`production_line_id`) REFERENCES `production_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_ibfk_order_item` FOREIGN KEY (`customer_order_item_id`) REFERENCES `customer_order_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production`
INSERT INTO `production` (`id`, `product_id`, `customer_order_item_id`, `quantity`, `production_date`, `worker_id`, `notes`, `status`, `created_at`, `production_line_id`) VALUES
('17','28',NULL,'1.00','2025-11-11','4',NULL,'completed','2025-11-11 00:57:28',NULL),
('19','30',NULL,'1.00','2025-11-11','4',NULL,'completed','2025-11-11 01:34:40',NULL),
('20','31',NULL,'2.00','2025-11-11','4',NULL,'completed','2025-11-11 02:43:04',NULL);

-- هيكل الجدول `production_line_materials`
DROP TABLE IF EXISTS `production_line_materials`;
CREATE TABLE `production_line_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL COMMENT 'خط الإنتاج',
  `material_type` enum('honey','packaging','other') NOT NULL DEFAULT 'other',
  `material_id` int(11) NOT NULL COMMENT 'معرف المادة (supplier_id للم العسل أو packaging_material_id)',
  `required_quantity` decimal(10,2) NOT NULL COMMENT 'الكمية المطلوبة',
  `used_quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية المستخدمة',
  `unit` varchar(50) DEFAULT 'كجم',
  `stage_id` int(11) DEFAULT NULL COMMENT 'المرحلة التي تستخدم فيها المادة',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `line_id` (`line_id`),
  KEY `stage_id` (`stage_id`),
  KEY `material_type` (`material_type`),
  CONSTRAINT `production_line_materials_ibfk_1` FOREIGN KEY (`line_id`) REFERENCES `production_lines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_line_materials_ibfk_2` FOREIGN KEY (`stage_id`) REFERENCES `production_line_stages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production_line_materials`
-- لا توجد بيانات في الجدول `production_line_materials`

-- هيكل الجدول `production_line_stages`
DROP TABLE IF EXISTS `production_line_stages`;
CREATE TABLE `production_line_stages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL COMMENT 'خط الإنتاج',
  `stage_name` varchar(255) NOT NULL COMMENT 'اسم المرحلة',
  `stage_order` int(11) NOT NULL DEFAULT 1 COMMENT 'ترتيب المرحلة',
  `status` enum('pending','in_progress','completed','skipped') DEFAULT 'pending',
  `estimated_duration` int(11) DEFAULT NULL COMMENT 'المدة المتوقعة بالدقائق',
  `actual_duration` int(11) DEFAULT NULL COMMENT 'المدة الفعلية بالدقائق',
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `worker_id` int(11) DEFAULT NULL COMMENT 'العامل المسؤول',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `line_id` (`line_id`),
  KEY `worker_id` (`worker_id`),
  KEY `status` (`status`),
  CONSTRAINT `production_line_stages_ibfk_1` FOREIGN KEY (`line_id`) REFERENCES `production_lines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_line_stages_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production_line_stages`
-- لا توجد بيانات في الجدول `production_line_stages`

-- هيكل الجدول `production_lines`
DROP TABLE IF EXISTS `production_lines`;
CREATE TABLE `production_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_name` varchar(255) NOT NULL COMMENT 'اسم خط الإنتاج',
  `product_id` int(11) NOT NULL COMMENT 'المنتج النهائي',
  `target_quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية المستهدفة',
  `current_quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية المنتجة حتى الآن',
  `status` enum('planned','in_progress','paused','completed','cancelled') DEFAULT 'planned',
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `start_date` date DEFAULT NULL COMMENT 'تاريخ البدء',
  `end_date` date DEFAULT NULL COMMENT 'تاريخ الانتهاء المتوقع',
  `actual_end_date` date DEFAULT NULL COMMENT 'تاريخ الانتهاء الفعلي',
  `worker_id` int(11) DEFAULT NULL COMMENT 'العامل المسؤول',
  `created_by` int(11) NOT NULL COMMENT 'منشئ الخط',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `worker_id` (`worker_id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  CONSTRAINT `production_lines_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_lines_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_lines_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production_lines`
-- لا توجد بيانات في الجدول `production_lines`

-- هيكل الجدول `production_materials`
DROP TABLE IF EXISTS `production_materials`;
CREATE TABLE `production_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `production_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_used` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `production_id` (`production_id`),
  KEY `product_id` (`product_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `production_materials_ibfk_1` FOREIGN KEY (`production_id`) REFERENCES `production` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_materials_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_materials_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production_materials`
INSERT INTO `production_materials` (`id`, `production_id`, `product_id`, `quantity_used`, `created_at`, `supplier_id`) VALUES
('1','17','26','1.00','2025-11-11 00:57:28','4'),
('2','17','27','1.00','2025-11-11 00:57:28','6'),
('3','19','26','1.00','2025-11-11 01:34:40','4'),
('4','19','27','1.00','2025-11-11 01:34:40','6'),
('5','20','26','2.00','2025-11-11 02:43:04','4'),
('6','20','27','2.00','2025-11-11 02:43:04','6');

-- هيكل الجدول `products`
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(20) DEFAULT 'piece',
  `min_stock` decimal(10,2) DEFAULT 0.00,
  `min_stock_level` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `category` (`category`),
  KEY `warehouse_id` (`warehouse_id`),
  CONSTRAINT `products_ibfk_warehouse` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `products`
INSERT INTO `products` (`id`, `name`, `description`, `category`, `warehouse_id`, `unit_price`, `quantity`, `unit`, `min_stock`, `min_stock_level`, `status`, `created_at`, `updated_at`) VALUES
('26','أغطية - غطاء 43م',NULL,'packaging','2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-11 00:57:28','2025-11-11 22:15:04'),
('27','زيت زيتون',NULL,'raw_material','2','0.00','0.00','كجم','0.00','0.00','active','2025-11-11 00:57:28','2025-11-11 22:15:04'),
('28','منتج رقم 7',NULL,'finished','2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-11 00:57:28','2025-11-11 22:15:04'),
('30','منتج رقم 7',NULL,'finished','2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-11 01:34:40','2025-11-11 22:15:04'),
('31','منتج رقم 7',NULL,'finished','2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-11 02:43:04','2025-11-11 22:15:04');

-- هيكل الجدول `reader_access_log`
DROP TABLE IF EXISTS `reader_access_log`;
CREATE TABLE `reader_access_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `status` enum('success','not_found','error','rate_limited','invalid') NOT NULL DEFAULT 'success',
  `message` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `reader_access_log`
INSERT INTO `reader_access_log` (`id`, `session_id`, `ip_address`, `batch_number`, `status`, `message`, `created_at`) VALUES
('20','d17c8670ea9ab5a6a4ff4237c02dd8f9','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:05:02'),
('21','d17c8670ea9ab5a6a4ff4237c02dd8f9','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:05:04'),
('22','d17c8670ea9ab5a6a4ff4237c02dd8f9','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:05:11'),
('23','d17c8670ea9ab5a6a4ff4237c02dd8f9','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:16:05'),
('24','d17c8670ea9ab5a6a4ff4237c02dd8f9','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:16:17'),
('25','d17c8670ea9ab5a6a4ff4237c02dd8f9','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:28:27'),
('26','efb5f445dcfa0a8817b20a3a052feb89','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:31:48'),
('27','efb5f445dcfa0a8817b20a3a052feb89','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:32:31'),
('28','5f07e3e4644a0e434bdea2ab064eb3c7','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 01:55:18'),
('29','f9069f4e0cc756291e388441476f083a','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 02:26:07'),
('30','f9069f4e0cc756291e388441476f083a','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم.','2025-11-11 02:27:59'),
('31','f9069f4e0cc756291e388441476f083a','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم: Call to undefined function readerTableExists()','2025-11-11 02:32:15'),
('32','f9069f4e0cc756291e388441476f083a','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم: Call to undefined function readerTableExists()','2025-11-11 02:36:25'),
('33','f9069f4e0cc756291e388441476f083a','154.238.222.99','BATCH-20251111-715','error','خطأ داخلي في الخادم: Call to undefined function readerTableExists()','2025-11-11 02:36:39'),
('34','f9069f4e0cc756291e388441476f083a','154.238.222.99','BATCH-20251111-715','success','نجاح الاستعلام.','2025-11-11 02:40:18'),
('35','f9069f4e0cc756291e388441476f083a','154.238.222.99','BATCH-20251111-610','success','نجاح الاستعلام.','2025-11-11 02:42:26'),
('36','f9069f4e0cc756291e388441476f083a','154.238.222.99','BATCH-20251111-587','success','نجاح الاستعلام.','2025-11-11 02:43:18'),
('37',NULL,'197.121.153.118','BATCH-20251111-587','success','نجاح الاستعلام.','2025-11-11 22:16:26'),
('38',NULL,'197.121.153.118','BATCH-20251111-587','success','نجاح الاستعلام.','2025-11-11 22:30:24'),
('39',NULL,'197.121.153.118','BATCH-20251111-587','success','نجاح الاستعلام.','2025-11-11 22:34:14'),
('40',NULL,'197.121.153.118','BATCH-20251111-587','success','نجاح الاستعلام.','2025-11-11 22:34:31'),
('41',NULL,'197.121.153.118','BATCH-20251111-587','success','نجاح الاستعلام.','2025-11-11 22:35:26'),
('42',NULL,'197.121.153.118','BATCH-20251111-587','success','نجاح الاستعلام.','2025-11-11 22:37:55');

-- هيكل الجدول `remember_tokens`
DROP TABLE IF EXISTS `remember_tokens`;
CREATE TABLE `remember_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_used` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_token` (`user_id`,`token`),
  KEY `token` (`token`),
  KEY `expires_at` (`expires_at`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `remember_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `remember_tokens`
INSERT INTO `remember_tokens` (`id`, `user_id`, `token`, `expires_at`, `ip_address`, `user_agent`, `created_at`, `last_used`) VALUES
('1','4','47838ae4020824abc0e239108d39b28b8377f6756db9a89d72ce63e7882cad44','2025-12-06 05:44:09','105.83.34.177','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-06 07:44:09',NULL);

-- هيكل الجدول `reports`
DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `filters` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_type` enum('pdf','excel','csv') DEFAULT 'pdf',
  `status` enum('pending','generated','sent','deleted') DEFAULT 'pending',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `reports`
-- لا توجد بيانات في الجدول `reports`

-- هيكل الجدول `request_usage`
DROP TABLE IF EXISTS `request_usage`;
CREATE TABLE `request_usage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `method` varchar(10) NOT NULL,
  `path` text DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`,`created_at`),
  KEY `idx_ip_date` (`ip_address`,`created_at`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1800 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `request_usage`
INSERT INTO `request_usage` (`id`, `user_id`, `ip_address`, `method`, `path`, `user_agent`, `created_at`) VALUES
('1700','1','154.237.99.51','GET','/v1/dashboard/accountant.php?page=salaries&month=11&year=2025&view=list','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:26:21'),
('1701','1','154.237.99.51','GET','/v1/dashboard/manager.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:26:21'),
('1702','1','154.237.99.51','GET','/v1/dashboard/manager.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:26:23'),
('1703','1','154.237.99.51','GET','/v1/dashboard/manager.php?page=salaries','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:26:29'),
('1704','1','154.237.99.51','GET','/v1/dashboard/accountant.php?page=salaries&month=11&year=2025&view=advances','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:26:31'),
('1705','1','154.237.99.51','GET','/v1/dashboard/manager.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 18:26:31'),
('1706','2','154.237.99.51','GET','/v1/dashboard/accountant.php?page=salaries&view=calculate&month=11&year=2025','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:27:00'),
('1707','2','154.237.99.51','GET','/v1/dashboard/accountant.php?page=salaries&month=11&year=2025&view=list','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:27:08'),
('1708','2','154.237.99.51','GET','/v1/dashboard/accountant.php?page=salaries&report=1&month=11&year=2025&view=list','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:27:46'),
('1709','2','154.237.99.51','GET','/v1/dashboard/accountant.php?page=salaries&month=11&year=2025&view=list','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:27:53'),
('1710','2','154.237.99.51','GET','/v1/dashboard/accountant.php?page=salaries&month=11&year=2025&view=calculate','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:28:22'),
('1711','2','154.237.99.51','GET','/v1/dashboard/accountant.php?page=financial','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:28:41'),
('1712','2','154.237.99.51','GET','/v1/dashboard/accountant.php?page=suppliers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:30:19'),
('1713','2','154.237.99.51','GET','/v1/dashboard/accountant.php?page=financial','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','2025-11-11 18:31:12'),
('1714','6','197.121.153.118','GET','/v1/dashboard/manager.php','Mozilla/5.0 (iPhone; CPU iPhone OS 26_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.128 Mobile/15E148 Safari/604.1','2025-11-11 20:40:35'),
('1715','6','197.121.153.118','GET','/v1/dashboard/manager.php?page=orders','Mozilla/5.0 (iPhone; CPU iPhone OS 26_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.128 Mobile/15E148 Safari/604.1','2025-11-11 20:41:35'),
('1716','1','197.121.153.118','GET','/v1/dashboard/manager.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0','2025-11-11 21:31:23'),
('1717','2','197.121.153.118','GET','/v1/dashboard/accountant.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:32:46'),
('1718','2','197.121.153.118','GET','/v1/dashboard/accountant.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:33:02'),
('1719','2','197.121.153.118','GET','/v1/dashboard/accountant.php?page=financial','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:33:33'),
('1720','2','197.121.153.118','GET','/v1/dashboard/accountant.php?page=suppliers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:39:42'),
('1721','2','197.121.153.118','GET','/v1/dashboard/accountant.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:39:53'),
('1722','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:40:46'),
('1723','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:40:49'),
('1724','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:40:58'),
('1725','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:41:06'),
('1726','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:41:10'),
('1727','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:41:26'),
('1728','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:41:45'),
('1729','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:41:52'),
('1730','4','197.121.153.118','GET','/v1/dashboard/production.php?page=my_salary','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:43:38'),
('1731','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:44:46'),
('1732','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:44:49'),
('1733','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:45:00'),
('1734','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:45:03'),
('1735','4','197.121.153.118','GET','/v1/dashboard/sales.php?page=vehicle_inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:46:05'),
('1736','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:46:05'),
('1737','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:47:02'),
('1738','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:53:11'),
('1739','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:53:17'),
('1740','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:53:35'),
('1741','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:53:38'),
('1742','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:53:45'),
('1743','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:53:51'),
('1744','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:55:04'),
('1745','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:55:14'),
('1746','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:55:27'),
('1747','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:55:34'),
('1748','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:55:41'),
('1749','4','197.121.153.118','GET','/v1/dashboard/production.php?page=packaging_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:55:50'),
('1750','4','197.121.153.118','GET','/v1/dashboard/production.php?page=packaging_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 21:59:22'),
('1751','4','197.121.153.118','GET','/v1/dashboard/production.php?page=packaging_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:00:49'),
('1752','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:01:37'),
('1753','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:15:04'),
('1754','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:15:25'),
('1755','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:15:46'),
('1756','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:16:05'),
('1757','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:16:17'),
('1758','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:16:20'),
('1759','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:16:56'),
('1760','4','197.121.153.118','GET','/v1/dashboard/production.php?page=my_salary','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:17:10'),
('1761','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:17:21'),
('1762','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:17:26'),
('1763','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:29:18'),
('1764','4','197.121.153.118','GET','/v1/dashboard/production.php?page=my_salary','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:29:21'),
('1765','4','197.121.153.118','GET','/v1/dashboard/production.php?page=my_salary','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:29:34'),
('1766','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:30:14'),
('1767','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:30:19'),
('1768','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:30:45'),
('1769','4','197.121.153.118','GET','/v1/dashboard/production.php?page=my_salary','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:34:02'),
('1770','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:34:08'),
('1771','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:34:11'),
('1772','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:34:24'),
('1773','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:34:28'),
('1774','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:34:58'),
('1775','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:35:02'),
('1776','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:35:05'),
('1777','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:35:15'),
('1778','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:35:18'),
('1779','4','197.121.153.118','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:35:20'),
('1780','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:35:23'),
('1781','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:37:47'),
('1782','4','197.121.153.118','GET','/v1/dashboard/production.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:38:09'),
('1783','4','197.121.153.118','GET','/v1/dashboard/production.php?page=production','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:39:05'),
('1784','4','197.121.153.118','GET','/v1/dashboard/production.php?page=tasks','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:39:20'),
('1785','4','197.121.153.118','GET','/v1/dashboard/production.php?page=packaging_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:39:25'),
('1786','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:39:30'),
('1787','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:39:41'),
('1788','4','197.121.153.118','POST','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:04'),
('1789','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:05'),
('1790','4','197.121.153.118','GET','/v1/dashboard/production.php?page=production','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:09'),
('1791','4','197.121.153.118','GET','/v1/dashboard/production.php?page=production','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:13'),
('1792','4','197.121.153.118','GET','/v1/dashboard/production.php?page=inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:23'),
('1793','4','197.121.153.118','GET','/v1/dashboard/production.php?page=production','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:26'),
('1794','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:32'),
('1795','4','197.121.153.118','POST','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:50'),
('1796','4','197.121.153.118','GET','/v1/dashboard/production.php?page=raw_materials_warehouse','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:50'),
('1797','4','197.121.153.118','GET','/v1/dashboard/production.php?page=production','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:40:53'),
('1798','4','197.121.153.118','GET','/v1/dashboard/production.php?page=production','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:41:00'),
('1799','4','197.121.153.118','GET','/v1/dashboard/production.php?page=production&ajax=template_details&template_id=9&template_type=honey','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-11 22:41:06');

-- هيكل الجدول `request_usage_alerts`
DROP TABLE IF EXISTS `request_usage_alerts`;
CREATE TABLE `request_usage_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier_type` enum('user','ip') NOT NULL,
  `identifier_value` varchar(255) NOT NULL,
  `window_start` datetime NOT NULL,
  `window_end` datetime NOT NULL,
  `request_count` int(11) NOT NULL,
  `threshold` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_identifier_window` (`identifier_type`,`identifier_value`,`window_start`,`window_end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `request_usage_alerts`
-- لا توجد بيانات في الجدول `request_usage_alerts`

-- هيكل الجدول `return_items`
DROP TABLE IF EXISTS `return_items`;
CREATE TABLE `return_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `condition` enum('new','used','damaged','defective') DEFAULT 'new',
  `batch_number_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `return_id` (`return_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `return_items_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `sales_returns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `return_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `return_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `return_items`
-- لا توجد بيانات في الجدول `return_items`

-- هيكل الجدول `returns`
DROP TABLE IF EXISTS `returns`;
CREATE TABLE `returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_number` varchar(50) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `return_date` date NOT NULL,
  `return_type` enum('full','partial') DEFAULT 'full',
  `reason` enum('defective','wrong_item','customer_request','other') DEFAULT 'customer_request',
  `reason_description` text DEFAULT NULL,
  `refund_amount` decimal(15,2) DEFAULT 0.00,
  `refund_method` enum('cash','credit','exchange') DEFAULT 'cash',
  `status` enum('pending','approved','rejected','processed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `return_date` (`return_date`),
  KEY `status` (`status`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `returns`
-- لا توجد بيانات في الجدول `returns`

-- هيكل الجدول `role_permissions`
DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` enum('manager','accountant','sales','production') NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_permission` (`role`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `role_permissions`
-- لا توجد بيانات في الجدول `role_permissions`

-- هيكل الجدول `salaries`
DROP TABLE IF EXISTS `salaries`;
CREATE TABLE `salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `month` date NOT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `base_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `bonuses` decimal(15,2) DEFAULT 0.00,
  `deductions` decimal(15,2) DEFAULT 0.00,
  `advances_deduction` decimal(10,2) DEFAULT 0.00 COMMENT 'خصم السلف',
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','approved','paid') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `month` (`month`),
  KEY `status` (`status`),
  KEY `salaries_ibfk_2` (`approved_by`),
  KEY `salaries_ibfk_3` (`created_by`),
  CONSTRAINT `salaries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salaries_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salaries_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `salaries`
-- لا توجد بيانات في الجدول `salaries`

-- هيكل الجدول `salary_advances`
DROP TABLE IF EXISTS `salary_advances`;
CREATE TABLE `salary_advances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'الموظف',
  `amount` decimal(10,2) NOT NULL COMMENT 'مبلغ السلفة',
  `reason` text DEFAULT NULL COMMENT 'سبب السلفة',
  `request_date` date NOT NULL COMMENT 'تاريخ الطلب',
  `status` enum('pending','accountant_approved','manager_approved','rejected') DEFAULT 'pending' COMMENT 'حالة الطلب',
  `accountant_approved_by` int(11) DEFAULT NULL,
  `accountant_approved_at` timestamp NULL DEFAULT NULL,
  `manager_approved_by` int(11) DEFAULT NULL,
  `manager_approved_at` timestamp NULL DEFAULT NULL,
  `deducted_from_salary_id` int(11) DEFAULT NULL COMMENT 'الراتب الذي تم خصم السلفة منه',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `request_date` (`request_date`),
  KEY `accountant_approved_by` (`accountant_approved_by`),
  KEY `manager_approved_by` (`manager_approved_by`),
  KEY `deducted_from_salary_id` (`deducted_from_salary_id`),
  CONSTRAINT `salary_advances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_advances_ibfk_2` FOREIGN KEY (`accountant_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salary_advances_ibfk_3` FOREIGN KEY (`manager_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salary_advances_ibfk_4` FOREIGN KEY (`deducted_from_salary_id`) REFERENCES `salaries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `salary_advances`
INSERT INTO `salary_advances` (`id`, `user_id`, `amount`, `reason`, `request_date`, `status`, `accountant_approved_by`, `accountant_approved_at`, `manager_approved_by`, `manager_approved_at`, `deducted_from_salary_id`, `notes`, `created_at`) VALUES
('1','4','100.00',NULL,'2025-11-11','accountant_approved','2','2025-11-11 04:47:47',NULL,NULL,NULL,NULL,'2025-11-11 00:48:41');

-- هيكل الجدول `sales`
DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `date` date NOT NULL,
  `salesperson_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `product_id` (`product_id`),
  KEY `salesperson_id` (`salesperson_id`),
  KEY `approved_by` (`approved_by`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`salesperson_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `sales`
-- لا توجد بيانات في الجدول `sales`

-- هيكل الجدول `sales_batch_numbers`
DROP TABLE IF EXISTS `sales_batch_numbers`;
CREATE TABLE `sales_batch_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `invoice_item_id` int(11) DEFAULT NULL,
  `batch_number_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_item_id` (`invoice_item_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `sales_batch_numbers_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_batch_numbers_ibfk_2` FOREIGN KEY (`invoice_item_id`) REFERENCES `invoice_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_batch_numbers_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `sales_batch_numbers`
-- لا توجد بيانات في الجدول `sales_batch_numbers`

-- هيكل الجدول `sales_returns`
DROP TABLE IF EXISTS `sales_returns`;
CREATE TABLE `sales_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_number` varchar(50) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `return_type` enum('full','partial') DEFAULT 'full',
  `reason` enum('defective','wrong_item','customer_request','other') DEFAULT 'customer_request',
  `reason_description` text DEFAULT NULL,
  `refund_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `refund_method` enum('cash','credit','exchange') DEFAULT 'cash',
  `status` enum('pending','approved','rejected','processed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `invoice_id` (`invoice_id`),
  KEY `sale_id` (`sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `status` (`status`),
  KEY `sales_returns_ibfk_5` (`approved_by`),
  KEY `sales_returns_ibfk_6` (`processed_by`),
  KEY `sales_returns_ibfk_7` (`created_by`),
  CONSTRAINT `sales_returns_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_returns_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_returns_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_6` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `sales_returns`
-- لا توجد بيانات في الجدول `sales_returns`

-- هيكل الجدول `supplier_balance_history`
DROP TABLE IF EXISTS `supplier_balance_history`;
CREATE TABLE `supplier_balance_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `change_amount` decimal(15,2) NOT NULL,
  `previous_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `new_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `type` enum('topup','payment') NOT NULL,
  `notes` text DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL COMMENT 'ID of related record (financial transaction, etc)',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  KEY `type` (`type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `supplier_balance_history_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_balance_history_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `supplier_balance_history`
-- لا توجد بيانات في الجدول `supplier_balance_history`

-- هيكل الجدول `suppliers`
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(20) DEFAULT NULL,
  `type` enum('honey','packaging','nuts','olive_oil','derivatives','beeswax') DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `suppliers`
INSERT INTO `suppliers` (`id`, `supplier_code`, `type`, `name`, `contact_person`, `phone`, `email`, `address`, `balance`, `status`, `created_at`, `updated_at`) VALUES
('2','HNY001','honey','عمرو',NULL,NULL,NULL,NULL,'0.00','active','2025-11-06 09:28:16',NULL),
('3','HNY002','honey','مايكل',NULL,NULL,NULL,NULL,'0.00','active','2025-11-06 09:32:03',NULL),
('4','PKG001','packaging','تعبئه',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:56:26',NULL),
('5','NUT001','nuts','مكسرات',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:56:43',NULL),
('6','OIL001','olive_oil','زيت زيتون',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:57:15',NULL),
('7','DRV001','derivatives','مشتقات',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:57:25',NULL),
('8','WAX001','beeswax','شمع',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:57:35',NULL);

-- هيكل الجدول `system_daily_jobs`
DROP TABLE IF EXISTS `system_daily_jobs`;
CREATE TABLE `system_daily_jobs` (
  `job_key` varchar(120) NOT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `last_file_path` varchar(512) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`job_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `system_daily_jobs`
INSERT INTO `system_daily_jobs` (`job_key`, `last_sent_at`, `last_file_path`, `updated_at`) VALUES
('daily_backup_telegram','2025-11-11 18:19:45','backup_if0_40278066_co_db_2025-11-11_18-19-45.sql.gz','2025-11-11 18:19:45'),
('daily_consumption_report','2025-11-09 05:02:41','','2025-11-09 07:10:49'),
('low_stock_report','2025-11-12 01:32:17','low_stock/low-stock-report-20251112-013217.html','2025-11-12 01:32:17'),
('packaging_low_stock_alert','2025-11-11 00:02:06',NULL,'2025-11-11 00:02:06');

-- هيكل الجدول `system_scheduled_jobs`
DROP TABLE IF EXISTS `system_scheduled_jobs`;
CREATE TABLE `system_scheduled_jobs` (
  `job_key` varchar(120) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`job_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `system_scheduled_jobs`
INSERT INTO `system_scheduled_jobs` (`job_key`, `scheduled_at`, `executed_at`, `updated_at`) VALUES
('daily_backup_delivery','2025-11-09 05:31:37',NULL,'2025-11-09 07:30:07'),
('daily_consumption_report','2025-11-09 05:30:47',NULL,'2025-11-09 07:30:07'),
('daily_low_stock_report','2025-11-09 05:30:12',NULL,'2025-11-09 07:30:07'),
('daily_packaging_alert','2025-11-09 05:30:27',NULL,'2025-11-09 07:30:07');

-- هيكل الجدول `system_settings`
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=11976 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `system_settings`
INSERT INTO `system_settings` (`id`, `key`, `value`, `description`, `updated_at`) VALUES
('1','currency','جنيه',NULL,NULL),
('2','currency_symbol','ج.م',NULL,NULL),
('3','timezone','Africa/Cairo',NULL,NULL),
('4','company_name','شركة البركه',NULL,NULL),
('5','company_address','',NULL,NULL),
('6','company_phone','',NULL,NULL),
('7','company_email','',NULL,NULL),
('8','telegram_bot_token','',NULL,NULL),
('9','telegram_chat_id','',NULL,NULL),
('11','low_stock_report_status','{\"date\":\"2025-11-12\",\"status\":\"completed\",\"completed_at\":\"2025-11-12 01:32:17\",\"counts\":{\"honey\":1,\"olive_oil\":0,\"beeswax\":0,\"derivatives\":0,\"nuts\":3},\"file_deleted\":false,\"report_path\":\"low_stock/low-stock-report-20251112-013217.html\",\"viewer_path\":\"reports/view.php?type=low_stock&token=aa1d486d8705ddb2b6ab93d10741202c\",\"access_token\":\"aa1d486d8705ddb2b6ab93d10741202c\",\"report_url\":\"/v1/reports/view.php?type=low_stock&token=aa1d486d8705ddb2b6ab93d10741202c\",\"print_url\":\"/v1/reports/view.php?type=low_stock&token=aa1d486d8705ddb2b6ab93d10741202c&print=1\",\"absolute_report_url\":\"https://demo-system.rf.gd/v1/reports/view.php?type=low_stock&token=aa1d486d8705ddb2b6ab93d10741202c\",\"absolute_print_url\":\"https://demo-system.rf.gd/v1/reports/view.php?type=low_stock&token=aa1d486d8705ddb2b6ab93d10741202c&print=1\"}',NULL,'2025-11-12 01:32:17'),
('12','daily_backup_status','{\"date\":\"2025-11-12\",\"status\":\"running\",\"checked_at\":\"2025-11-12 01:32:17\",\"started_at\":\"2025-11-12 01:32:17\"}',NULL,'2025-11-12 01:32:17'),
('180','daily_consumption_report_status','{\"date\":\"2025-11-09\",\"target_date\":\"2025-11-08\",\"status\":\"already_sent\",\"checked_at\":\"2025-11-09 05:45:53\",\"last_sent_at\":\"2025-11-09 05:02:41\"}',NULL,'2025-11-09 07:45:53'),
('661','packaging_alert_status','{\"date\":\"2025-11-11\",\"status\":\"already_sent\",\"completed_at\":\"2025-11-11 00:02:06\",\"counts\":{\"total_items\":36,\"by_type\":{\"أغطية\":8,\"أكياس\":1,\"صناديق كرتون\":2,\"طبات\":5,\"عبوات بلاستيكية\":8,\"عبوات زجاجية\":11,\"لوازم التعبئة\":1}},\"preview\":[],\"report_path\":\"alerts/packaging-low-stock-20251111-000206.html\",\"viewer_path\":\"reports/view.php?type=packaging&token=28689209b1b7e5d3408bfe95db2c19c2\",\"access_token\":\"28689209b1b7e5d3408bfe95db2c19c2\",\"report_url\":\"/v1/reports/view.php?type=packaging&token=28689209b1b7e5d3408bfe95db2c19c2\",\"print_url\":\"/v1/reports/view.php?type=packaging&token=28689209b1b7e5d3408bfe95db2c19c2&print=1\",\"absolute_report_url\":\"https://demo-system.rf.gd/v1/reports/view.php?type=packaging&token=28689209b1b7e5d3408bfe95db2c19c2\",\"absolute_print_url\":\"https://demo-system.rf.gd/v1/reports/view.php?type=packaging&token=28689209b1b7e5d3408bfe95db2c19c2&print=1\",\"file_deleted\":false,\"checked_at\":\"2025-11-11 22:41:00\",\"last_sent_at\":\"2025-11-11 00:02:06\"}',NULL,'2025-11-11 22:41:00');

-- هيكل الجدول `tasks`
DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `status` enum('pending','received','in_progress','completed','cancelled') DEFAULT 'pending',
  `due_date` date DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `received_at` timestamp NULL DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `related_type` varchar(50) DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `due_date` (`due_date`),
  KEY `tasks_ibfk_3` (`product_id`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `tasks`
INSERT INTO `tasks` (`id`, `title`, `description`, `assigned_to`, `created_by`, `priority`, `status`, `due_date`, `completed_at`, `received_at`, `started_at`, `related_type`, `related_id`, `product_id`, `quantity`, `notes`, `created_at`, `updated_at`) VALUES
('1','برطمانات عسل 100ج','1312','4','1','urgent','completed','2025-11-08','2025-11-08 07:44:22','2025-11-08 07:43:30','2025-11-08 07:43:37','manager_production',NULL,NULL,'10.00',NULL,'2025-11-08 07:33:44','2025-11-08 07:44:22'),
('2','1',NULL,'4','1','normal','completed','2025-11-08','2025-11-09 00:35:49','2025-11-09 00:35:42','2025-11-09 00:35:45','manager_general',NULL,NULL,NULL,NULL,'2025-11-08 22:45:45','2025-11-09 00:35:49'),
('3','2','0000','4','1','low','cancelled','2025-11-14',NULL,NULL,NULL,'manager_general',NULL,NULL,NULL,NULL,'2025-11-08 23:09:14','2025-11-10 20:55:15'),
('4','111',NULL,'4','1','normal','pending','2025-11-10',NULL,NULL,NULL,'manager_general',NULL,NULL,NULL,NULL,'2025-11-10 19:20:35',NULL),
('5','111',NULL,'4','1','normal','pending','2025-11-10',NULL,NULL,NULL,'manager_general',NULL,NULL,NULL,NULL,'2025-11-10 20:55:00',NULL);

-- هيكل الجدول `template_packaging`
DROP TABLE IF EXISTS `template_packaging`;
CREATE TABLE `template_packaging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `packaging_material_id` int(11) NOT NULL COMMENT 'مادة التعبئة من جدول packaging_materials',
  `quantity_per_unit` decimal(10,3) NOT NULL DEFAULT 1.000 COMMENT 'الكمية المطلوبة لكل وحدة إنتاج',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `packaging_material_id` (`packaging_material_id`),
  CONSTRAINT `template_packaging_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `unified_product_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `template_packaging`
-- لا توجد بيانات في الجدول `template_packaging`

-- هيكل الجدول `template_raw_materials`
DROP TABLE IF EXISTS `template_raw_materials`;
CREATE TABLE `template_raw_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `material_type` enum('honey_raw','honey_filtered','olive_oil','beeswax','derivatives','nuts','other') NOT NULL COMMENT 'نوع المادة الخام',
  `material_name` varchar(255) NOT NULL COMMENT 'اسم المادة (للمواد الأخرى)',
  `supplier_id` int(11) DEFAULT NULL COMMENT 'المورد الخاص بالمادة',
  `honey_variety` varchar(50) DEFAULT NULL COMMENT 'نوع العسل (سدر، جبلي، إلخ)',
  `quantity` decimal(10,3) NOT NULL COMMENT 'الكمية المطلوبة',
  `unit` varchar(50) DEFAULT 'كجم' COMMENT 'وحدة القياس',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `material_type` (`material_type`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `template_raw_materials_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `unified_product_templates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `template_raw_materials_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `template_raw_materials`
-- لا توجد بيانات في الجدول `template_raw_materials`

-- هيكل الجدول `unified_product_templates`
DROP TABLE IF EXISTS `unified_product_templates`;
CREATE TABLE `unified_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL COMMENT 'اسم المنتج',
  `created_by` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `main_supplier_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `form_payload` longtext DEFAULT NULL COMMENT 'JSON يحتوي جميع مدخلات النموذج',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `main_supplier_id` (`main_supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `unified_product_templates`
-- لا توجد بيانات في الجدول `unified_product_templates`

-- هيكل الجدول `user_permissions`
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `granted` tinyint(1) DEFAULT 1,
  `granted_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permission` (`user_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  KEY `granted_by` (`granted_by`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_3` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `user_permissions`
INSERT INTO `user_permissions` (`id`, `user_id`, `permission_id`, `granted`, `granted_by`, `created_at`) VALUES
('1','2','3','0','1','2025-11-05 18:42:02'),
('2','2','2','0','1','2025-11-05 23:17:09'),
('3','2','1','0','1','2025-11-05 23:17:10'),
('4','3','3','0','1','2025-11-06 07:39:42'),
('5','3','2','1','1','2025-11-06 07:39:52'),
('6','3','12','1','1','2025-11-06 07:40:09'),
('7','3','6','1','1','2025-11-06 07:40:13'),
('8','3','5','1','1','2025-11-06 07:40:18'),
('9','3','4','1','1','2025-11-06 07:40:24');

-- هيكل الجدول `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `role` enum('accountant','sales','production','manager') NOT NULL,
  `webauthn_enabled` tinyint(1) DEFAULT 0,
  `full_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `profile_photo` longtext DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `users`
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `webauthn_enabled`, `full_name`, `phone`, `profile_photo`, `hourly_rate`, `status`, `created_at`, `updated_at`) VALUES
('1','admin','admin@company.com','$2y$10$cIXyIRjYeF.YHoKQfUIgluq8mWJ.qNlvr7iz0c1QcWbRrdI0yqNHS','manager','0','المدير العام','01000000004',NULL,'0.00','active','2025-11-04 08:14:12','2025-11-08 21:51:44'),
('2','a','accountant@company.com','$2y$10$uX9v.mRKgvVCXWEDfnPwHebLdTviE/T6xUChWUBYtyruZ5GwtIKN2','accountant','0','المحاسب الأول','',NULL,'0.00','active','2025-11-04 08:14:12','2025-11-11 17:57:05'),
('3','s','sales@company.com','$2y$10$DiSgJlH7fcYF3s4xxz9fRODANfMPzbtzwyoncher65zH1NRq1.C06','sales','1','مندوب اسامه','',NULL,'15.00','active','2025-11-04 08:14:12','2025-11-10 09:10:23'),
('4','p','production@company.com','$2y$10$91kPMaWrc859vTduCzBvNeoTwDRhn5G.MW0Xkt03EfPxI0btk7zaS','production','1','عامل الإنتاج الأول','01000000001',NULL,'20.00','active','2025-11-04 08:14:12','2025-11-09 01:04:16'),
('6','1','osama@co.co','$2y$10$i1WbOh67VWpXu6yo6hWuB.2svIcpwCYSeSAQRPsjSKCgTPAt5FMLy','manager','1','Osama s','0000000000','data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QDsRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAC5ADAAIAAAAUAAAApJAEAAIAAAAUAAAAuJAQAAIAAAAHAAAAzJARAAIAAAAHAAAA1JASAAIAAAAHAAAA3JKQAAIAAAAEMDAwAJKRAAIAAAAEMDAwAJKSAAIAAAAEMDAwAKABAAMAAAABAAEAAKACAAQAAAABAAACOaADAAQAAAABAAACOQAAAAAyMDI1OjEwOjI5IDA1OjQ0OjE2ADIwMjU6MTA6MjkgMDU6NDQ6MTYAKzAzOjAwAAArMDM6MDAAACswMzowMAAA/+0AfFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAABEHAFaAAMbJUccAgAAAgACHAI/AAYwNTQ0MTYcAj4ACDIwMjUxMDI5HAI3AAgyMDI1MTAyORwCPAALMDU0NDE2KzAzMDA4QklNBCUAAAAAABBRJgNzu38/WOObdmjaINW//8AAEQgCOQI5AwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAgICAgICAwICAwUDAwMFBgUFBQUGCAYGBgYGCAoICAgICAgKCgoKCgoKCgwMDAwMDA4ODg4ODw8PDw8PDw8PD//bAEMBAgMDBAQEBwQEBxALCQsQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEP/dAAQAJP/aAAwDAQACEQMRAD8A+yESpF+/QlSIlf5vn9GFipEqPZUiJQEyRKKKkRN1ZnOSQ/dqSo0TbVhE3UAKn3KfQny1IlAAiVJQlSIm6gxmKn3KfQny0UGJIlFFSIm9aABEqwiUIlSUAGyhEqRE3VIny0GYJ8tFFFABUlFFABUmyhEqTZRMCNEqTZUiJUmyucCNEqTZRRQAbKESpNlFXAiYbKNlFFEzLnDZRsooogHOGyo9lSUUTDnI9lFSUVAc5HRsqTZRsoNYFeo3TdVh0o2UFlfZUbpVio3TdWgEeyo6kf5aKzAjqOpKKuAEdRum6pKK1ArulR1Yb79R0AV2+/UdWHSq7/LQaEbpUdWKjegCu6bqjdKsVG6bqAK7pUdWHSo3Sg2gV3TdUb/LVio2+/QbFd03VG6basVBN96gCKo3SpKjegCu336jqw6b2qPZWhcCu9R1I/zUbKDU/9D7MSrCJsWo0qwlf5vn9B85IlSJUaVJQahViH7tRom6pETbWZmSVKn3KRE3VIny0AFSIlCVIlBjMESrCfLTE+5T6DEKkRKEqRKADZUqfcpETdUiJQBIlSIm6o0SrCfLQZgny0UUUTAKkRKESpKy5wDZQiVIibqkT5aOcARKk2UJRTImFFSbKKzMucNlFFFAc4UVIibqNlAEdSIm6jZUifLWhmR7KNlSUVmBHso2VY2VHWgFd/loqR03UbKzNCOipNlRv8tABRsoooDnI3SjZUlGyg1gV3So9lWHSo6Cyu6VHVh03VG6UAR1HUlFXACu6bqjf5asVG6bq1AjqN0qR/lqN6AK7/LUb1Yb79R0GhXoqR0qOgCNvv1XerDpuqN0oKgV3qN03VYdKjoOorv8tRum6rDffqOgCu6bajqWb71RUARulRulSPUb0FwK7ptqOrDpVetDU//R+1NlSIlFSJX+b5/Q84AlSUJUiJurMgkh+7UlRom2rCJuoAVPuU+hPlqRKDGYIlSIlCVKn3KDEeny0UVIlAAiVIiUJUqfcoAeiVJQlSIm6gBU+5T6E+WiiZmFSUUVmBIlSIm6o0SrCJWYAiVJsoooImCJUlFFBkFFSIm6jZQAIm6jZUiJUmygzI0SpNlFFABso2VIibqNlAEeyipNlGygCOipNlGygCPZRsqTZUb/AC0AR1G6bqsUbKAK+yo3+WrFRum6g0I6KH+WigAqN0qSig1gV6jdN1WHSo6Cyu6VHVhvv1HQBXeipHSo6uAEbpuqN0qxUbffrUCu6bqjdNtWKjdN7UAU3oqR0qOg0I6jb79SPUbpuoArvUb1YdKjdKDaBXdN1Rv8tWKjb79BsV3TdUbptqxUE33qAIqjepKjegCu9V6uOlR+T/tVoXzn/9L7YT50qREqNPkSrCV/m+f0ZMKsQ/dqvViH7tZnOSVKn3KiqVPuUAPqRKjqRKDGZIiVYT5aYn3KfQYhUiJQlSUACJVhEpifcqdKACpU+5SIm6pE+WiZmFSJUdSVmAVIiUJUqfcrMB6JUlCUUAFSUUUETCpETdQibqkT5aDIE+WiipESgzCpETdRsqRPloAj2UbKkooAE+WiiigAooooAKKKKACo3TdUlFAEeyjZUlFAFd0o2VI6bqjf5aAI3So9lWKjoNCu/wAtFSN9+o6AI3oqSo6DWBG6VXf5auVG6UFlN6KkdKjq4AR1G6bqkeitQK7/AC1G9WG+/Vd6AI2+/Vd6sOm6o3Sg0K70VI6VHQBG336rvVh03VG6UFQK71G336sPVd03UHUR1BN96p3+Wo3TdQBXqN6sOm2o6AK70VI9R0Af/9P7cSpEqNKk2ba/zbP6IJETdUiJtoh+7UlBmSIm6pE+WmJ9yn0ASJUlRpVhE3UGMxU+5T6E+WpEoMQSpKEqRE3UASp9yn1GnyJVhE3UGYqfcp9CfLRRMCRKKESpK5wBEqwiUxPuVOlAAiVJQlFBEwqRE3UIm6pE+WgyBPlooqREoMwRKsJ8tCfLRQAUUUUAFFFFABRUmyjZQBHUmyiigCOipKNlAEdFSbKNlAEdFFFABUbpuqSigCu/y0VI6bqjf5aAI3Sq7/LVyo3Sg0K9FD/LRQBHUb1YqN0oNYFdvv1HVh0qu/y0FkbpUdSPUb1cAI3TdUbpVio2+/WoFeo2+/Viq7ffoNCu9RvVio3oAjqNvv1JUbffoArvUdSPUb0G0CNvv1HUjffqOg2IJvvVFUs33qioAjejZQ9FAH//1PtxKkoSiv8ANs/oQsQ/dqSo4fu1YRN1ACp9yp0qNPlqRKDGZIlSp9yokqVPuUGI+pEqOpESgCRKsp9yqyJVhPloAkqVPuVEibqsJ8tBmFSJUdSUTAkSpETdUaVKn3K5wHolSIlCVIlBEwooqRE3UGQqfcp9CJUlBmCJVhPlpifcp9ABRRRQAUUVYRN60AR7KkRN61J5P+1QibaADyf9qjyf9qpKKAI/J/2qPJ/2qkooAj8n/ao8n/aqSigCPyf9qo3TbVio3TdQBXqOrnk/7VV3TY1AEdFSbKjoAKjdN1SUUAV3+WipHTdUb/LQBG6VXf5asPUbffoNCOo3qSirgawK71G336sOlRulEyyvUbpUj/LUb1AEdRum6pHoq4AV3+Wo3Te1WG+/Vd61NCu/y1G9WG+/Vd6AI6jb79SPUbpuoAjqN6kf5ajegqBXdN1Rv8tWKjb79B1Fd03VG6basVBN96gCs9FSUbKAP//V+4EqRE3VGlWIfu1/m2f0ICJtqyn3KiqVPuUAPqRKjqRKDGZIiVYT5aYn3KfQYkiVIlRpUiUASp9yn0qfcp9AEqfcp9MT7lPomZkiUUJUiVmAIlWESmJ9yp0rMARKkoSigiYVKn3KRE3VIiUGRIlSIm6o6lT7lBmPT5aKKKACiipKACrEP3ar1IrbP9ygCxvT+Ntn+9WXq2v6Nolu9xrN9Bp0KfekuJViT82IrzP45/FzSPgp8Or/AMbamVlmVWW0hbP7yXsvGfr9K/nj+Jvxf8dfFjWp9b8bajJcKwxHCDtSNMltoX0yT7+tfqHDnCE81h7ac+WAUYTq/Af0cf8AC3vhX/0OGkf+BcX/AMVR/wALf+Fn/Q4aV/4FRf41/L/bWz3Kf6DFJN/1zjq5/Y+rf8tNNuf+/L/4V9/Pw+wn/P46fq398/p0/wCFv/Cz/ocNK/8AAqL/ABoT4vfCxv8AmcNK/wDAqL/4qv5h20fVlb/kF3Df9sn/AMKP7E1r+DS7n/vy/wDhT/4h/hP+fwfVv75/Tw3xe+Fn/Q4aV/4FRf8AxVH/AAt74V/9DhpH/gXF/wDFV/MWNA13/oE3Tf8AbF/8KH0fWof9Zpdyn1gf/Cj/AIh/hP8An8OeGnH7Z/T5a/Fb4Z3s3kWvi3SpZf4VW7i/+KrtEmjeJZ43WRH+6ynctfyf/J9/5k8tv+WfyTK9fdn7Kf7WXiz4d+LLDwn461Q3vhPUpPL8y4Y7rRv4fXj19Ov18zH+HcIUpzw1Yy+rT+M/dwffeo3TdRbz291bpdW7b4pl3K3qtSV+DThOE+Sf2TLnK7ptqOrDpuqN021mBXooeigAqNvv1JUbpuoAjqN0qR/lqN6AK7/LRUjffqOg6YEb1G9WKjetCyu336rvVh03VG6VmBHUdSVG9XACNvv1HUjpuqN/lrUCu336rvVx03tVd0oArvRUjpUdBoRt9+q71Yb79V3oKgRvUbffqR6jb79B1EdQTfeqeoJvvUARUUUUAf/W+4EqxD92q9WIfu1/m2f0ISVKn3KiqVPuUATpUiVXSrFBjMlT7lPpifcp9BiSJUlEKb1qTZQBJD92pKjT5EqwibqDMVPuU+hPlqRKACpEqOpESspgSp9yp0qNEqREogRMkSiipETdRMyFT7lTpUafLUiVBmSIm6pE+WmJ9yn0AFFFFXACRKkRN1CJvWpETbROH8gBsof5FeP+P76/9sv9ZUjvs/75r4z/AG1/jbH8I/hhPpWkXKxeJ9fXyLdQ2HjT+JxwegPHvj3r3MowM8wxEKMAPzX/AG3fji3xc+Jg8OaRcOdA8PhoxEG+SS4J+dxz3AVf+A5714/8M/h3pmp6dP498dEweHrPqB96Ru3+f8jyvwd4X1Dxd4itdBsiZbm/kBkPog+834CvZPjd4ktrUWfw00Fz/ZejLtkYMf3kvfP0/nmv69o4eGFpQwFE9LknCHJA2Lv9olNGJsPAugWdpYJxGzoWZv8Aa4I/r9ajT9qbx7D9y0sPxgX/ABr5n3p/G3z0I9dsMopfbOn6nD7Z9QJ+1h8QU/5ctO/8Bh/8VVxf2u/iRDwllp3/AIDL/wDFV8p1G7/c/wB6ur+x8MKGGgfXi/tj/EtD8llpn/gMv/xVaFr+2v8AEuBwZtL0qWMfwm2Xa3/j2a+b9E+GnjvxJocvibQ9FnvNKgb5p1WuHR/k8vY2/d8ysv3a8yGAwk/ch8ZnCjA/RjQX+DX7WlrceHJ9Ii8GePUV/srWi/ubp/8Ac/dV8B+KfC2r+E/EGo+EPEKG3v7ORo5gTkbl+6wPof1qvoGuah4W12z8SaRM8F/YSLJG4PB2/wAJHoa++P2kfDVl8Zfhlof7T/hCASXcUaW2vQoCyxOhxubP+8o6dCKOSeCrex+wOfuT5PsH2R+wp8fV+Jnw/TwLq8hbxD4cCxDcT++ix8rZPUjBB/D1r70r+Yf4M/FPWvg18RdL8bafMzQRSqLuJePMt+4/Wv6WPC/iXTfGPhzTvE2iOJrLUo0ljZT1VxkH8q/AeOMl+r1frlGHuTPInDkmdBUbpuoR9/7yP7lSV+N/GBTdNjVHVmb71VnqgCiiigCNvv1HUjpuqN/loAjdKrv8tWHqNvv0GhHUb1JUb0GsCOo2+/Uj1G336uBZXeo3qR6jetQCo2+/UlRt9+gCu9Rt9+pHqNvv0AV3qN6keo3oNCNvv1HUjpuqN/loKgRvVd03VYb79R0GxXf5ajdN1WG+/UdBoV3TbUdSzfeqKgD/1/uCrEP3ar1Yh+7X+bZ/QhJVhKrom6rFAAlWKjSpKDGZKn3KfTE+5T6DEsJ8iVYT5qr1Kn3KAJ0qVPuVElSp9ygzH1IlR1IlAEiVKn3KiSpU+5RMCdKkSo0qRK5yJhUqfcqKrCVoZBUiJQlSp9yszMeny0UUUAFSJUdWETetAEkP3akqNE21JvTc+9tiVfOBn6trOlaBptzreqyrDa2cZaSRuiqK/m3/AGjPi/d/Gj4qap4vnkLWEMjQ6euSyhF9u2ev41+kH/BQr47xeH9Fg+D2g3G3VNW/eXew/wCriORtP1/p71+W/wAJvA58a+LLa2mXbpFgVkmOOi+n41/SvBWT/UsJ9ZrfGdOG/nmeweCrWD4R/DW88e3R8rWdZj8myQjLKv8Ae6/U/QCvl9V1PVL4xRQvcXl4chP9qvVPjF41XxZ4naz09h/ZemgQ26j7u1OB/wDW9sV65+yN4WtNZ8U6prWogSnTY0ZQf7xz/hX3c5/V6M8TOB08/JDnmR+E/wBkHxnr1rFd63qMOis67vKZd5/Qiuo1b9ijxMllJJomu293OB8sTKUz/wACyf5V2Hx3/aF8UeCvEjeE/CZW3nWNZJJjz8x5xtPFeL6B+138WdGvBNqN6mrQpyySqq5/FVFeJhq2c4iHtqJzQnWqw5zw/wAZfDrxn4BvDZ+L9Lk04L0kI3I30YcH8DXF/On31+R/u7fndq/Zj4efEP4aftNeE5PDuq2iRX8q5ktXPzKR/Eh9vXtR8Kf2OPAvgjX7zxLrxTVoonZoFfhY4sDhh3O7P4Y4rSHFMMJ7mMh74fXJw9yZyf7A/iu6vvBmqfD7V7V1trZzKCUx5iuFG3PtjNfBf7SPgS2+Hnxq8Q+GrZ8wySedCuPmCSDIHbpmv1wb9pj9nXwtro8OQ6pb2srcSNFbEIP+BbsV6xH8J/gx8T9dX4wNZW+rmWFFF0W3oFTkYXle/p2r46jnc8Fjp4mdGXJM5oVuSfPM/nDe0uNvmT2s8f8AvRuv8xX2Z+xj8W9D8LeJ734U+OnWTwb46gezmVjuWOU/dbk4Geh+ue1fph4//aA/ZE0LT9X8Ia7d6dLdRI8bWqWjKxbaQfm2Fc9utfgnqc2nnX7690SP7PZvPI0IH/PPcdv6V+h4DHzzXDz56Mo/4jt9t9YhyTPSPjh8KtX+DvxH1TwRqkZNvEzNbscBZom+6eP19wRX6Ef8E8/j3Mxl+Cnia7Vcx+dpcjMdzHktEPoBkc+vtXn/AIjkT9q39m+z8UWID+Ofh8nkzIWJlmthzvOBj+8enUH1r88/D/iC/wDCfiCz8S6RIbe802YSR4GQGX7yn1B/Wta2EhmeBnhq3xwNZ+/S5D+qxKkryv4LfE3SPi58ONL8Z6XIAZY1WeNTu8uXALL+H8iDXqn/AFzr+PcZhp4etOjM8iBG6bqrumxquVBN96vONStRQ9FABUbffqSo2+/QBXeo3qxUbpQBXqN6k2baKDpgV3qNvv1Yeq7puq4Fld6KkdKjrUCOo2+/Uj1G6bqAI6rt9+rD/LUc1BoU3qN6sVG9AEdRt9+pKjb79AFdvv1HUj1HQbQI2+/UdSN9+o6DYgm+9UVSzfeqKgD/0PuCrEP3ajRN1WNm2v8AN8/oQlT7lPpifcp9ZmZKn3KfTE+5U6JuoJmKn3KnSo0+WpEoMSRKlT7lRJVlPuUAPSpU+5UVSp9ygzH1IlR1IlEwJEqVPuVElSp9yswJ0qRKjSpErMiYVYSq/wA/91n/AOA1YRH/ALv/AAH+Ol8fwQMiRKlT7lVppIrKJp7pxbxJ/FKwVfzNeZ6/8b/hN4UhM2t+K7CMrzsWUO/TP3Uyf0r18NlWOxH8GBmesfJS7H/utXw14l/4KB/AbQzJHpj32tSR9HtYBs/3d0jr/LFeF+Iv+CmCPC0fhnwVJJJjiS6utoz/ALojP86+sw3BWZ1fjgL35n6ubNifOrJ/vVYT7vmIrOn95a/B/wAQ/wDBQn466lC8GnLpWkxvnlYC0o/4EzEfpXifiD9qH48+KVLan40ujuUL8hWHgf8AXILX11Hw4xfx1pmvsZn9JH2uBP8AXyxw/wC+6r/WvL/iP8ZPAXw18N6j4h1PUbeSewhaRYA6s8jfwgA+pr+bPUPHfjfWXLatrt5eN6vO7j8iTWW1tqWrsmI57sltoB3Pn+de/huAcPSnCdaZr9TrfbOk8ceNNX+JvjbVPHWr7jeaszMik52I33VH0HFe6a4Yfg78Kbfw7a/6Pr/iBUkucnLRr/d/mPzrP+EHwz1C3nk+IPja1MOnabG0oRsZZ0wV6kbcdee9eL+PPFlz438T3PiK8JMcrfu1P8K9hX6ZCHtZ+xo/BE7ocnPOBx9fUn7J/jC28P8AxFfSNQkEVrrMfl8j+LtXy2fuJUlrPd2Vyt7YSmGeH5o2H3lavXx2G9rh50TpnDnhyH3B+138K9Xg1ZfiRpVu8tm0QjuAo+6wJG76Y2ivh9Jv3UU8G54n/h276/Tj4F/tHeFvHGmweCfiLIIrwxiPfNhoplPqeAv48fyrU8dfsU+DPF15Nq/gnVDpZuG3LEg8yL3+YnI/M18Lg84hltGGGxh5FHE+y9yZ+afhDxZrXgfxBbeIdEkMc9hMshI4yvdT7Hoa/dzS/ETfGr4EXWveF3FteatZOh2Abkmxj9DXwPB/wT+8ZzXXlx+JrNE/vOH/APia++P2X/gj4h+B2gXPh7UNWTV7W4lLoIUK+XvAH94/3a+f4mx+XYiEMZD4zLGThI/APU7K+sr+50zUE8ue3mdLgN94MGxiv14/4Jkaxr1/o/ibSLyR5NLtmRo8/MuWzn9FFe6a3+xR8A9f8SXXizxKLiKfUrhpWAuVji3E5PAAP619OfCzwb8IvhZo58NeBTa2kcjbpCZVLMfeubO+JqWNy6FGjA5q2J9z3IH4J/tm6TbeHf2jfFltpc4WN5Ekwv8AekRWP6mvl/5HVI/4N2+v2w/aI/YLb4k+J9U8e+F/Ejf2pqXzCKVPlLBAAu/dx09K/I/4h/DHxn8Ldak8O+M9NeyuVJCPjMUig43K3Qiv0TIcyw9XCUaPP78T18HW54ch3H7Onxcufg78R7PV2Pm6RqbfZtSiJzmJu+M9QSCPpiuk/ah+Flt8PPiAuvaJH53hjxMBeafMn3B5hbcnU4xjIB7EV8x/6mV96/w7Gr74+E3iHR/j78Jn+BXiy7it/EWk7pNGuLg4Tkp8nAPJA/Ie2D6WMh9XxH1k0rQ5J85T/YW+PMXwt8bSeEPEt2bTwx4g3GMuQEhlxyxz67QDz/Kv2w0nx14Q12Lfout2d6ucZinVun+7mv5r/F/wj+IngfVpNB17RJg1v/GEZo2/2lY4B/zmvPzDrOlFcm4s2T+HLx/4V8bm/DOBzOr7bn98562G9/ngf1aQ3NvN/qHWb/cZW/lQ6b/n+4/91q/lr0n4k+O9Eb/iT+JtRtk44jncJ+QOK9U0D9qb9oTwsSdM8YXUkbZys22Vef8AeDY/Cvia3hzOf8GZl9Wn9g/o82fJv/8AQfnqOvwz0D/goh8ddKEaapFp2rxpjl4mWXbj1VwP0r3jQv8AgppZMFTxF4ImjPeW3uFf/wAcKL/6FXzeJ4BzGl8BnOFWHxwP1UqN03V8R+Hv+CgfwD1y4jg1O4utGd/+fqLb/wCiy1fTHhz4x/C3xXbC58O+KbC6LOUCLMnmbh22Z3fpXx2J4czTD+/OiZc56A/y1G9SI/2lPPg27P8Aaao/vf5+Svm60K0PjhyBCZG336jqR6jrlhOEzpgRvUdSPUb10wLI2+/Vd6sN9+q71rMCN6jd9tSPUbpurKAEb/NUb1I/y1G9agR7KrzfI1WHfbVd/neg0I6jb79SVG336AI6r1YqvQVAjb79R1I336joOogm+9UVSzfeqKgD/9H7ohqw9V4akr/Ns/oQlT7lPpifcqdKDMEqyn3KiSpU+5QTMfUiVHUiUGJIlWIfu1XSrKfcoAfUqfcqKpU+5QA+pEqOpE/293+6vzvRCE6vuQgYTJEqxD937+z/AGm+5XjfxB+Onwt+GUBbxTrsMcijPkIytL/3wOe9fC/xA/4KM2sEk1n8MPDrXA5Vby++Vd3+4Dz/AN9CvrcBwnmOK/uhDnn8ED9UP+WW+T5E/vV5X41+N/wp+H0LN4o8SW8EnXykO5+n90c/pX4T+OP2lvjX4+nZ9e8TyxwHjy7NjEgX+6QOv45rzfQvAvjDx/fRReH9E1HVrqRsbhE7oPqwBAr9RwfAOHhDnxlYcKM/t+6frB4t/wCCjPw+sBdWngzRLrWpcYWVsRxZ/U/pXy34y/b0+N3iV5odFjtfDkMi52W6+a3+9lt1c/oH7DXxk1aEah4sFh4atGP3rx1Eqr/uqG/nXQTfBD9lf4byonxG+IkuvXqLva20tdn/AADf5lfZYPK8jwk+TDQ5p/8AbxpyQPlfxN8X/iX4vkLeIvFd9dFgV8oTkR4P+wML+lc3pfhHxT4inUaTpd5fSesUbP8A+gg19oTfHX9mnwSvkfDn4afb5YPuz3/zuz/9+64fXf2y/iXqAki8PW9n4fgbjFvArEfi26vqIYnEfBRw3JAUIHH6L+y/8a9fAl/sc2ka85umVO2enX9K7hP2Um0eHzPF/jLSdIdMFkMis+PYNt9PWvC9c+L/AMT/ABGS2r+JLyQN0QOVT16DArz+6ubq8fzLqZ3f+JmbdmtPY46f2+U7YUZn1JN8Pf2c/Dyf8Tnxxc6rKn8NpGmyqf8Awk/7NOif8g7w/d6k6fxXLf8A2uvlvYm7ei1I/wB7+L/gTVr9QnOHvzH9WnM+nJvjx4Htv+Rf8D2ibPutIv8A9rrHuP2j/FLEtp+j6dabfu4iY7fzavnt/wDgSUI8iVrDLaMA+pwP0k+BfxGb4p6LeaRrgie8iLrIoG1ZEf8A2ense1fDfxQ8Gy+CvG2o6QyMlvJJ5kJP9ztVz4TeOLjwJ4zs9XjO6J22zDO35f8APNfZH7U/gu18S+CbDx9oS+bJZjLMoyZIu35cmvjfY/2bmPJ9iRxcnsqx+df8FFHyf8sF+T+Giv0jkgetOf8AIdR4N8J6h448T2Hh7TDia8kVS391e5/Cv38+HfgTT/Avhaw8NafK8gt41DGUsct3+lfkn+xLY2998crYXCB1t7eWRR/u4H9a+7P2jLX9oo61pcvwbS4a3t0Bm8ooRI+4tjYeSNoHY5Oe9fifFk543Fwwc58sDwMf70+Q3PjFqf7WOgGfUfh3b2V1p0XCIi75tpPdXBB/DJryf4Sft0+IR4stvBnxu0b+z52kWMXCIUZW/ushyR9f071x/hP9tT4u/DHUYNM+Ovh2WOBn2i4khMUo/wCBHAK/Qf4V9geJ/hT8FP2yPAR17w9NFDq4UGG8iG2WOUDcqPj7w56fkR1ryJ4PD4Sj9WxkPc/mObkhCHOcn+3d4D17xN8JrPx14Mmkk/sljJKsTsMxN1Yjpx/LNfiPZ+KPE8Z8+DVrqMj7pWZ1/ka/pc+CnhbxDF8ErbwL8S7c3FzZxtZ3IkbzPMiThGyefu4Ffhv+03+zV4l+CPjO8lggM/hu8kae3mQZ2q3RSvt6/wD6h7nCeZYSHPgPi5TTAYmE/cM/4T/tWfF34U6klzFq0urWG799b3TGRdp645yPwxX6sfavhv8AtqfCR2cRpcxRspK/620n2dRnG5fm9MEe/T8D4ZkfZJ9//ZWvvj/gnxrGtw/EfWdIgVzp1xZM0w/hDggD+Zr6jPsqhh6U8fR92Z24mjCHvnxn478G614B8Wap4Q1uPFzprMAcY3KeVP4jmubhnuLO4iuLeVopYW3KyHa3519wft96TZWXxms7+3ysl/p6NIO2dzjd+mPwr4bdNn3K+py3E/WsPCczuhyTgfRnhz9q3416Bp0elvqiapbRYwLqJZTx/t/e/WusT9r/AF66G3xB4S0W/QdcwMGJ6Z5Yj9DXyHQ/zvSrZbh6v2A+rQPsB/2gfhJr37vxH8NIE/69vk/9p1lzax+yhr3+v0W+8PSv/wA82318p7I9/mSLv/3qN/y7PuJWcMq5fgF9TPqD/hVfwP1tv+KZ8ftbM/3Y71dj1n6j+zbr06iTw9rthqa5xhJVIP48j9a+a9n/AC0dvnrQtr++s38y0nkh/wB1qPqeLhP9zMznRnA9A1f4NfEjQo5PtmiSyRr/ABW4WVef93NedpYXejzf6mS0lT+M7kYfyNdxpfxU+IOilW0/W7gBf4GYsv5HivUNO/aS8SyKbXxRpNhrMPcNEqt6fe5H/jtH+3Q+xGZnOEzzfQPjJ8UvCchbQfGF9FG3JQzmVPX7j5X9K+nPBf8AwUG+M/hoLa+Iks/EcITaN42S/XK4H6Vw/wDwmf7O/ir5PE/hq50eV/8Alpafw/8AkOpIfgb8J/FUW/4e/EGP7Q/3ba9XZ/5EkrxMT9Uq+5jKJj7h90eDf+CiXw01RY4PF+j3mhzDGXRPNiJ/D5v/AB2vrjwh8bPhT4+Abwn4psLuRsfuvN2SDP8A0zbDfpX4X+JP2Z/itoUJvU0satarn57F9+ce3DfpXh8llrPh28xew3WnXQPDYMcq/RuDXyVbg3KcV/B9w2hhp/HA/qQ3/cf5UTbv+b+Ko38xNm9W+ev54/Bf7TXxy+H8iR6R4klu7aMEBLpjOoz/AL2SPwIr7c+Hn/BRXTJBFbfEvQntGQ7WurM+arf8A2jH/fRr4DH8A46l7+G94znCrD7B+nj1XevL/Avxw+FvxJhW58J+JLO4kfH7pn8qZWxnaUPPT2r1B/MTZ5iMm/8AvV+XYzA4vCz5MZDlOXnI3oqR6jrhhOE/gOgjb79V3qw336rvWoEbpuqu/wAj1Yd9tV3+d6DQjqNvv1JUbffoArvUb1I9RvQVAjb79R1I336joOogm+9UVSzfeqKgD//S+6Ifu1JUcP3akr/Ns/oQlT7lTpUCfcqdKDMkSpU+5USVKn3KCZj6kSo6kSgxJEqyn3KrJViH5/kj+/R/gI5+QN6J+73Kn+9Ul1d2Gn2bX13cJDAn3nkbao/E18Z/HH9svwR8LLm68NaDF/bmv22VKZ2xRt7vhvxGP8K/K/4lfHr4n/FK4mfxRrbQ2Dni1hPlJgfwnH3vxzX6jk/BWLxcPbYn3YBDnnP3D9VPip+3F8KfAXnWfh2R/EeooMBVOy3DEf8APTDfoDX5x/Eb9sL4z+PZLhYtSfQNOk48mzJQ4/387u3rXL/Cf9mX4u/GJtvhbQprWw3c3l4pt7ccZ3K7AbvouT7V9WJ8Jf2UP2e9l18XvEsnjnxHAu9tNsG/cr/sP/rf491fr2DyXK8t/gw5pmc5w/xTPgPwz4J8Z/ETWhbeE9Jutc1G4O4kI0oCjqxYdAAOp4r7Q0H9grxRBBHrnxn8TWfg7ScjcJXWW42Yz90lFz/wI0eMP26/ENrYSeHvgjoFl4F0op5YeGFPtDf7RbGM4x/Dn3xxXxf4n8beNPHN0914x1y71V3+95klfVc+Lqw5Ie6aQniJ+5D3D70h8SfsHfBZnTStMu/iRrdr92e5+SHf/n/0KuH8U/t2fEi7t20z4faTYeDdP2FAlrF8+Sc7tx4H4KK+G97onlptRP8AZWiuiGV0vjrHVDBw+OZ2niX4jePfGk73XinX73UWfn97Kx/nmuLT5P4VT+9t/ioor14QhR+CB2whyBs+b+5/u0f99f8AAqKK0AKKKKDTnCiiigOcKKKKDMPn/gr9KP2YfFlh8R/Al/8ADfXADeW8LxKCc+ZCUxj+Y+mK/NevTPhH49vPhx44sPEVtnyTIqzAHGV7183nGA+sYf3PjgcOJhz++Yfj7wtc+CPE+qaDcjAtGbyz/eTsa4/5P4Gr9DP2yPAlhrmkaR8YfDQEsV4oWQr0Knoa/PP5P4Pu105LjPreHhP7cDWjP3D6k/Y31y20P486NLckBbyOWEZH99Tj9RX6iftB/H2+/Z8j0jV/7COp2d/J5byiXyjG30wd3T269e1fhv4R8RP4U8UaX4iTcPsFwkjFf7oOa/ej4p/DXT/2nvglp1vpl6lq2pCK8huGXf5bbduO3YEH61+b8TYalDHUa2J+A8TGfHzmf8O/iV8Ef2tdCn8O6hZRNfsrZtZeJUb+8jcbse2PcDv8f+Gfh38ZP2UP2krDQfBNvca14d8QToY4UGxZItzZ+Y79vlgk5PYZwAa+lPgd+wPovwt8RWHjO98U3l3qNockRARRfTdyenvX2J8S/jV8LfhbYtrXi/VrWO4iXMKLtllP0HU18licZ9XrTw2Ah7WEvsnFWn/Ianxb+Itt8OPh7q/jbUNkU1hbu0Ql5zKF4Xj1PFfCfwz/AG0/hF8btH/4Rf4rW9vp94zYYTfNFJ6NuPC/ifxNfB/7VP7VuqfHq+/sXR420/wnb48u3B/1hH8Tf09P1Pxvv2M/yr/3zX1uT8FYeGH563xnTg8HzwP3E8QfsUfs+eNLn+2NLM0EFyfMBs51ZG+mQ36Gu40bwz8Ef2ZPD889nMmkKwbJldZJZM84HT06AfhX4R6b4y8XaPH5On63fRIf4RO4UfgDgVT1PWtX1vnWr64vv+usrP8AzJr0p8OYur7lbE88D0Z4CrP7Z6p+0B8T/wDhb/xKv/EsBIs0UW1uD2RCT09ySa8X/gSP+4tDvI/3/wCD7tFfpGGw0MPR5IHpcnJ8AUUUV0moUUUUAFFFFABRvf7n8FFFZckAJE8hP4Nn+6zpUfz718tmSiitTKcOc9A8MfFH4h+D5Ufw/rlzbbP4fMr6A0b9rW9v4lsfif4ZsfEds2EeYxokwQDoG2ED8BXx/RXmzwOHkZ/VoTPuB/D37IvxXfZoeoXPgnWJ/wDlnIu+H/2lXN+LP2Lvizo1oNY8IPa+K7BgpSaxfdKVP+x3/wCAlq+Q9+9PIk/1X/j/AP33XoHg34qfEH4fXIufCGv3WnspJCK+5Dng5XofxFeb9TxEJ/uaxn7GrD4JnN3Ntq/hfUsXMd1pd/C23LhreVf5EV9IfDL9sj4yfDmeK2vr8a5YL963vMlygz8quckdfce1eoaH+1/4a8a2a6J+0P4Ls/EcbZUahaxeXcID05z2yfulfx6VsXn7LXwd+M0T6z+zn42iS7++2k6k3z7/AO4n7yuetWhV/c4yiZTnD/l8fWHws/ba+E3xAaDT9Xd/DWqS9Ybr/Vdvuy8DnPcLX2BBdQXUST28iPFIu5XU7lP4iv5v/iJ8HviR8Kb5rPxnoVxZRkkJM6Zt3wcbkfoenY11nwz/AGifil8J7gJ4e1hruzbk2t0TJEemdozx07EV+d5lwPhMR7+AnymfJD7Ez+hTfv8A4W/4FUb18n/Aj9rbwR8YpIdB1OP/AIR/X5gALeU5SR8fwtjn6ECvrCQPG4ST5JU+8v8Adavw7MsoxGX1uSsHORt9+q71Yb79V3rxCiN6jb79SPUbffoArvUb1YqvQVAjb79R1I336joOogm+9UVSzfeqKgD/0/uiH7tSVXR9tSI+6v8ANs/oQsp9yn0xPuU+gzJEqyn3Krp9yp0fbQTMkqRKjT5qkSgxJEr5r/at+LNz8J/hNPc6Q4TV9Zk+w2hzyu9SWYcHoAce+K+lEr81/wDgowT/AGF4IiH3Wu7xv++Iov8AGvtuE8NDEZnCEzM/Of4e+BvEvxe8cWfhDQf3+r6sfmdzwoHLN+AFfoI+ifsofskN5fiNv+Fl+O7Jfmtl/wCPWCf+5/y1ryv/AIJ5RxxfHe5dUVmTQ7jazfeU7V6V8X+Jp57jxLq91PIzyS3c252+83zmv6irUZ4jF+x5/ciROE51eSHwH0Z8UP2vvjJ8TRLpYv28P6GfljsbE+UoXOeSvLfia+X3fe3mP9/dvZv71R0V7f1OjS+A9KjhoUoA773/AIf+A0UUV2850hRRRWYBRRRQAUUUUAFFFFABRRRQAUUUUAFRv5jps3fJ/FUlFAH6WfsxeJbP4vfCvXPgjr0qtqUUMhsnc8hSvb3BJPFfnf4n8PX3hLXtQ8OalE0Nxp0rxMrV1Hws8d3nw18d6X4zs3IFnIvmD+8ncfiK+sP2y/A+n6lNpHx28LkPpHiqCPzgo/1c2W3Nx2K7R9RXx0P9ix3sfsSOHk9lM+C/vxPB/A/yNX0p8O/2tvjX8L/DUfhPwvqitYRfdEihsfmDXzOk0H/LPc/+7Ujvs/havfxNHD4j3K3wHdWhCZ9AeJv2qvj74rSSDUPFtxHFLjKodnT/AHcV4XqOp6lrNx9q1i8mvZf71w5kP5nJrP8A++akf5G/hoo4PD0oe4ZQowh8Afu/4N3/AAJqKk2b/wDV/PRtevWNSOiiiswCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooANkf8a/8CVtj1Ysr2/0y7ivbCd7SeHlZoWMco+jDBqvRWXJAJ+/8Z9meAf21PHui2i+GvifbReN/DbfK8V4m+VV4Hyuc9v7wb2xXaar8Fvgf8e9NuNf/Z61NtH8QQL9ol0O7/i/56eXX5//AMH3m/4DX0B+yrdXVl8fvCD2cphD3DK23ow8s8N7V5OMwfsv31E4p0Zw9+B4fcRat4a1jfAWsdR02f5WXh45I2/oRX7yfst/Fu4+MPwm0vWr47r+zP2O5bpuZAPm/HOa/Ff4x7E+LnjDy12f8TOf5Vr9IP8AgnMSvgfxSinMa6pEyr/d/dR18Txfg4YvLPbfbM60PgmfoY77qjepf4E/7af+h1E9fyoQRvUbffqSo2+/QBHVepHqN6CoEbffqOpG+/UdB1EE33qiqWb71RUAf//U+4KsQ/dqvViH7tf5tn9CFlPuU+o0fbUifNQZkqfcp9RpUlBMyVPuVOlQJ9yp0oMSRK/Nf/goqhfR/A3+1cX/AP6Kir9KEr83P+Ci2f7H8B/9fF//AOioq++4N/5G0APFv+Cex8346XP+3o1x/wCgrXxPrv8AyH9W/wCv26/9HNX2p/wTv/5LlPn/AKAdz/6CtfFetf8AIf1b/r8uf/RjV/T9H/fpm8P4s4GXRRRXvnaFFFFABRRRQAUUUUAFFFFABRRW54b8N6z4t1mLQ9Dg864dXespzhCHPMDDor1zxB8DviR4a0eTWtQsF+zRLubDDgV5H8n8Db1rPDYmjiIc8Ah7/vwCiinf/FV0gNor1T4bfBj4g/Fa3nu/B+nC4t7eTy2bcB82Pej4j/Bb4g/CmOzufGenfZIbyQqrKwYcfQmub65S9t7GEzKc4RPK/v8A+5/Gv96vtD4KftVaR4E+H8vw3+IvhlfFekGXfDv2/ufu46qcgYyM9zXxf8jqjx0fxfdX/vmssZgIYv3K32DWtR9r7kz9ELn9or9k2/8A+Ql8G5N7/wAUciVzdz8Tv2Jr/wCef4V6vbP/ANO0yV8J4/2ajeFHf7q1xQyqBzfVj7UvPEP7D9+v/IteL9Nf+7HJDs/9GVxd/Z/si3n7zSrnxbYf9dI4X/8AalfMaIifwr/wJaNqf3F/75rp+oTh8EzSFHkPaL/QfgQ+/wDs3xdrKf7Nzp6f+hxz1xd/oPhGF/8AiW+KFmT/AKbwvvri/wB2i/ItFaQo1f5zUsXKQQy+XBcx3if3lqvRRXdye4AUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFdZ4G8DeIfiH4ks/CfhO3F1f3Z4BIUKO5JPHSvePFn7HHx58G6Bc+Jda0SNLOzjaSRhIrcD6GuGtjKVKryTmHwfHM+W6K2PDHh7XPGGt6f4c8P232nUNRbYse6vozXf2Pfjr4d0q51fUNHVILONpJDvH3B9D6U62MpYefJOZlOcIny3XvH7Mb+T8ePB8n/TzXg/8Xl17p+zT8nxz8Jf9fVZ43+CFafuHJ/GZ/8Ai7Xi3/sIz1+kn/BOr/kSfFn/AGEIv/RaV+a/xgfzvir4rf8A6iM9fpR/wTq/5EnxZ/2EIv8A0WlfE8Tf8iU563wH6Gf/ABT/APodRt9+pP8A4p//AEOo3r+RYGUyOo2+/UlRt9+tSSu9RvUj1G9BUCNvv1HUjffqOg6iCb71RVLN96oqAP/V+4KsQ/dqvViH7tf5tn9CElSp9yoqlT7lBmTpUiVGlSJQTMlT7lTpUaUUGJYSvzX/AOCir/8AEn8DY/gnv/8A0VFX6SI9fm3/AMFFf+QP4J/673//AKKir77g3/kbQK+2eN/8E8zs+Ok6H/oDXH/oK18T61/yH9W/6/Ln/wBGNX2x/wAE8v8Aku9z/wBga4/9BWvifWv+Q/q3/X5c/wDoxq/qSj/v0zWH+8TMuiiivaO0KKKKACil/i/+Jr6T8G/sq/E/xjp8ep5t9LglGQtw5DfkAetcWMxlLD/HMJ8kPjPmuivsB/2MPiEi/wDIV09/+2lcn4n/AGXfiN4b0uXVd9tfpB97yJK8yGb4SU+TnOb20JnzXRQVkBKSKUZG2srdmor6A6PgCvZPgZ410jwP47g1PWmK2zRuu4LnGf8A9Vcn4W+G/jPxjKh0SwMkUnHmN8q/ma94039kbxnexrJqGo29of7uDL/8TXzeZYzCSh7GczixM6XJyTme0fEj47fDvUPAmr6Vpl+9xPfwmNQVPy5471+c/wC8TZvr7Qj/AGK9enOyLxBb4bn5omX+RauL8Vfsm/Fbw5BJe2scerwoQD5TfPz/ALPB/LNeLlWJy7D+5Csc+DnRhDk5z5joRPmT/eqxdWV3p9xJY6jE9vdJ95JBtP5Go0/g/wC+q++hyVYc563JDkP1k/YBto2+HWrycqz3pXn/AK5x1J/wULR0+Hnhp93/ADEXq5/wT7X/AItrq+f+gkf/AEFKP+ChcLzfDzwuiIzu+puiqtfgMJ8vEPxny/8Ay+PyI/h/4E9JX0x4C/ZG+OvxDjW40jQHtLaU5Wa4PlKfz57dga94g/4JpfHWaDzLjUdHRv7vnyn/ANpV+vVs7wNKfvzPfrYmB+de+pK/Qx/+CbHxrT7+raP/AN/5f/jVUx/wTn+M6/f1TSf+/sv/AMarj/1jyz7dYPbQ5D8/6K+vPGP7Evxu8IWjXq2lvq8a9RZuzt+RQH8s18n3un3+mXktlqMD29xC21o5F2sPzr2sNj8JiIf7NM0hOBToo+fcn9yT+KvdPhJ8AvGfxe0+fVNBaGC2t22s8rkfN+ANdOJxMMPDnrGtb3DwuivaPin8DPGHwnFnLrbRXEV+xWM27E9PXIFSeF/2efil4rjFzZ6X5EDDO+U7f/r/AKVzf2lh/Ywrc5n7aJ4nRX1Z/wAMf/EbZvfUdPR/7vnVT/4ZO8dw/wCs1Cx/4DJXDDOsJ/OZfWKJ8v0V9MP+y144Rv8Aj+sv+/lcvrv7PnxE0WH7StvHdLnH7p9x5+oFawzjCS9znNIYmjP3Dw+irFzbT2d1LY3UTQ3EH3laq9e3D3/gNQooq5pthfaxexabpUElzdztsWNVonyQ+OYFOivqzwr+x78VtfCy3q2+lwt1MzHeMf7IB/WvWIf2AfFbw738V2cb/wDXszf+1BXzlbPcDD7Zze1gfn3RX6Aal/wT5+Ikdt9o0TW7LUZM/dYGLj/x6vk/4jfBr4kfC0lvF+jPBbA4WZfmRvxFaYbOMJiJ8lGfvmkK0Dy+ij+FP9uivo/Yz5/fOmcD7Y/4J+pv/aT0T/rhO9ftp8e5t/wb8Z/M3/Hi/wAu6vxH/YCcr+0lpHp9nuP/AEUa/aD48XP/ABaDxnB/04vX888TTnDOaMIHzGI/in4N/sl7H/aC8KfL8nmvX7ofEO4a48LeIQ8hfzdPuV259Y2r8KP2S38n49eFZP7ks71+2/jq8/4pbXH/AOnG5/8ARZrp4m/36jA0xPxwP5x7n57qWT/af/0OvZP2b32fHPwlJ/09V4vN/wAfEv8AvSf+h17J+zr8nxr8KSf887qv2PE/7uetP4Dm/i3/AMlM8T5/5/5//Rhr9KP+CdX/ACJPiz/sIRf+i0r80/iy+74meJ/+whP/AOjDX6Wf8E6v+RJ8Wf8AYQi/9FpXx3E3/IlOafwH6Ef/ABT/APodRvUn/wAU/wD6HUb1/IsDSYVG336HfbUb/NWpnAjeo6kb79R0GxG336jqRvv1HQaEE33qiqWb71RUAf/W+4KsQ/dqulWIfu1/m2f0ISVKn3KiqVPuUATpUiVXqRKDGZcSio0qSgxJEr81/wDgor/yB/BP/Xe//wDRUVfpQlfmv/wUV/5A/gn/AK73/wD6Kir77g3/AJG0C4fGeP8A/BPbH/C97rP/AEBrj/0EV8T61/yH9W/6/Ln/ANGNX2x/wT5AT46Xkn93Rrj89or4n17/AJD+rf8AX5c/+jGr+n6M/wDbpmn/ADETMuitTQtC1HxLrlhoenqPPv5khXJ7ucD+dfeF5/wT2+JFnpX2/wDtuzeTbu8nHzfTO7FduPx9HC8kJzOmdaEPcmfn3RVzULK70zUrrSb5ds9nI8bfVDg/rVOvShOEzQ+hP2XvBtn4y+LdhBqkfmW1mrTkEZ3bOn6kV+umt6vDp+ky6heSC3s7OHc21ckL/dr8x/2LX2fE29k/552LvX2p8frl4fhL4j2bt/2X726vwribnxGYwozn7h83jPfrHm8X7Vvw31HxLH4atfOLSSLGH52licf3a9wuZo3/ALrxP95W/jr8U/D2/wDt7Sn3f8vlrX7MO6b4kj/up/6BXNnuT4fL50fq0zmxOG9kfkf8S7OCw8fa7aQfcjunq58LPA7+PvGNtojjNsnzSH/ZqD4o/P8AEbXZP791X0v+yRpSPb6xrm397u+zrX6jjMZ9XyyE4Hr1p/uec+wNE0fTtB0uKxsYltreBdny15P4s/aP+Hfg65n0+FH1ORT/AAfL+prU+O/iCfwj8ML+9tm8qe4ZbYMO2/8A+tmvyr/eP+881t8n3vmr4DIcihmEPrOMmcOGw3tYc8z9JNK/bM8F7kTUtFvraL/Zkr648A+OPCHxB08an4TvzKVGZFY/NG1fhP8A9dNv/Aa+hP2ZPGl/4Q+Kel21u5FnqzpbTIT1yePyOK9fOOE8JClz4Y1xOAhCHPA+4P2rfgpY+JfBk/jbS7JE1fSU3SFF5kiHPb+6Mn/Ir8l7b/VRf7df0gXulQanpt/pUq74rqF4W/3XGDX88fiLTv7H8R6hpW7clrdzRL9FdgP5Vlwbj51aM6MzTATnM/Wj/gneu74Yavlf+Ykf/QUr7w1f4feGvGN5pF14ishe/wBkzNNboT8plPqO/bg+lfEf/BOFN3wr1r5f+Yk3/ouOvqz9on4pyfB74Q6v4stMC/IaC3BG3DP0bHt1r8uz6FarnPsaM/iOKtD96anxK/aV+DHwbmNj4o1mNr+MAm1txlwp6KfT8a+d73/gph8Gw/lwaTq06p/Ftj/+Kr8O9a1rU/E2pz61q9699eXknmSE8DdWe/3/ALq1+rYbgTCcn+0z5pnbDLYfbP3Af/gpN8HX/wCYHqv/AAJaz0/4KI/BO8uPInsdSs0/56MtfifR/Ds2r/wKu2HAmWGv1CB/SR4P+JXhD4iaK2t+ENU+0QJtLDoyZGcMD0r4f/bX+C1trvh2X4maJapb6jYYNwiD/WKSBn68/wCcV8t/sX+N9Q0D4vW2i+Y39nayDHImflyASD+lfq548s/7Y8K67pU/zpdWs8Vfl2Jwf9iZpCFGfuHmVoTpTP539nzJs+5uSv1A/Yl+T4Xaj8oZvtr9R/spX5l3MLW95Pbj/lhcSR/9+2I/pX6WfsXvt+GV+p/5/wBv/QUr9W4snz5Yenj/AOFzn1B4g8OaLr+oWF1q9uJ2s2LRqfu7vp3rzPx38a/APgIva63fiS5Trb2/zOufX0/HFWPjd4+f4f8AgK/1uDAuZv3MI9GP8WPbrX456jfXmr3Ml5e3DyzyvmQ/7VfAcOcPTxsOfEz9w8jB0faw98/RCb9rbwKCw+xXzr/CwRP/AIqst/2pvAUnSyvR/vKi/wDsxr8+/k/gWj5K/Q4cIZd8H/yR68Muon34n7TngCaVI5Ir2FP722voDwl4l0HxTbf2noN/54QfMpGNv4V+Qe9/9Xu+X+7X0p+zB4hutN8fJoaNvtNUXYys1eJmXDOHpUvbYY5q2DhGHuHsn7Snwwtr7Qv+E20yERXlm374IPvL6/hXwP8AX/gNftB4m0tdX8Lavp8y8TW7Y9ivT9a/GN/vvHt2bGdP/H69fhDHzq4ecJmmAnzw5Cv8/m/d3/3V/wBuv1o/ZV+DWn+EPCNr4s1S3SfVL+MTLvXmPP1/Ovy78J6Z/bPibSNKzxdXcUZ+jOAf51/QBodhDYW9rp0C7Y7ZEjH0C4ryONcf7KEMND3eYePn9iByfjj4meEPhlpi3njfUTE+Nyog3Oef7v8AkV8xyft9+BbO4Mdv4f1GaIfdbKLu/wDHq+J/2m/Gl941+L2srdOTbae720cOfl/dnB/M5NfP/wDD5dGUcG4SeH9tiZihg4T+M/cj4X/ti/Cn4h6mNIuDNot43+rS4GVk+hGR+dfWmv8Ag7QfGui3PhrxFax3tnfx/KG+Ygj+JfQiv5f4DJBcRS28hiljbMbr1Vv8iv6HP2QfGVz8SvgRoevagS15bFrNmJ3E+X36emDXx3E3D8MqhDH4OZzYnB+xnzwPxL+PXwtufhB8T9U8IMrfZVPn27N1aI9On5fWvG6/Vz/gpt4RiiufB3jTH7+58yzkH+xEQ4/WQ1+Udfs/DmM+t4GFaZ7cJ88Oc+zP2Cp/J/aN0h9vBt5l/wDIbV+xnxyud/wj8Z/7di9fjP8AsMPs/aH0eT/phPX6+fG65/4tT4sz/wA+UuP++Wr8h4m/5HNE8rGfxYH4h/sov/xfXw1/11ev2k8dTbPDGuJ/043P/os1+Kf7LT+T8bvDT/8ATV6/ZTxtced4Y1p/+nO4/wDRZro4l/5GNEyx38aB/Pvcv/pEv+8//odewfs8P/xebwv/ANfSV4/N/wAfEv8AvSf+h165+z98nxf8NP8A9PSV+y1v90Pan8Bz/wAVf+SleJP+v2f/ANDNfpZ/wTq/5EnxZ/2EIv8A0WlfmX8T3874i+JH/wCn2f8A9GGv00/4J1f8iT4s/wCwhF/6LSvjeJv+RKc0/gP0I/8Ain/9DqN6kf8A9mf/ANDqOv5FgEyNvv1HUjffqu9ahAHqN6HqN6DYj37qjd9tSVBN96g0Ed91R0UUAf/X+4EqRH21GlFf5tn9CFhH3VZT7lVofu1Ij7aALFSJUdSJQYzJEerG/dVdKlT7lBiTpX5r/wDBRbP9j+Bv+u9//wCioq/SSvzb/wCCi2f7H8Df9d7/AP8ARUVffcG/8jaBcPjPG/8Agn43/F7b/wD7A1x/6CtfFWvf8h7VP+vyf/0Y1fZv7AM2z423mf8AoB3H/opa+Mte/wCQ9qn/AF+T/wDoxq/pqj/v0zT/AJenY/CDj4o+E/7p1K1T/vuRRX9FmpXP7q48tdm9X+7X85/wqmS2+Ivhi4f7seoQS/8AfEgNf0KXN5vil2Jv3q7r/t+alflXHHv4uicOM+M/nX+ID7/G+uP/ANPc/wD6Ga5Ou0+J1s+lfEHxBY3W7zY7x/4a4tHR1d03bE/2a/cMBCH1SjOEz1oe+fXH7Gz+T8S72T/npZulfZH7QM2/4S+Jf+uG2vjf9jy2kfx5qd9B88UFr96vrD4/Xnk/CPxB/wBN1RK/GM7hz5zDkPAxMP3x+U/h759Z0f8A6aXlrX7CPN+9i/3f/ZK/Hvw8+zWdK/2LmFv/AB8V+vH/AC3i/ubU/wDQK9fi+H72iGP96cD8r/iX8nxB1tP+nrZX2R+yKn/FG3rp/wA/VfHfxU2J8S9d+b/l6r64/Y7v4ptF1zSM/wCkWcgn/wB5Tx/SvWzqHPlMOQ6a3uUTqP2un/4tzZb/ALn9opX5x/8A2f8A6HX6uftJeGpvE3wmv/sQzJYSLcj5c7scH9Ca/KPfG/7z5vvf3a04TrQ+o+4aZbOE4cgV6B8K97/Ebwv5f3/7Rgrz/wC++yvoT9mTwPq3jX4y6HbabETBYTC5mcj5QsZz+pwPxr63Mp+ywk+c9KtyQh75+8FhbbGl+X5H2f8AAa/nb+J+xPiLr+z7v9oT/wDow1/RhdXKWGm3t+/3LWGWVj7RqWP8q/mz8Xakmo+LNV1XkLeXssi4O7iRyetfjvAnx1jyst+2fsZ/wTRXd8Kdc/7Cjf8AoqOo/wDgprM9t8LfDVrG37q61N9y1of8Ey4d3wm1nP8AHqjf+io6p/8ABT6HZ8N/CW99n/EzevN/5qc5p/7wfif/AAUUY+X7v9//ANDox/stX9DThA+nnAKKMf7LUb40T95u/wC+azhRhM5uQ90/ZsmdPjh4R8v/AJ+vmr9sNeuf9F1D+5tnr8a/2T9Avdb+Nehy2sZeKzZ5pG7BcEfzIr9ePEl5BbaDqupTtsiggnevw7jLknmNHkPAx/v1YH4H6x/yG7//AK+5/wD0Nq/RT9jN/wDi2+of9hFK/N/ULhJtRubrdxNcSOv0LE1+in7HU234dXmf+ggf/QBX1vEfuZYduM/hGf8AtjXj/wDCM6JB/A9077a/OtPuf+hV9+ftjfPoPh//AK718Bp8ifdr0uFuT6ia4Dk5OQkoox/stRX3R6QV7J+z87p8WtC2fxs9eN/u02fM27/dr6A/Zj0S61j4saZPAreVZb5WbbXk5xyQwk4HNW5OQ/VS7h/0G+T+/b3H/oBr8Mrr/j+vP+u83/oZr9zdcuodM8P6lqk5wtvbXEg/4ChI/UV+F9y+64mm+8ryuy/i1fmfBUPcmeTgIHoHwiTf8UPC6bf+XxK/fSGH5n+T+L/2Svwz/Z20O51/4x+HrazjZ0gkEkhA+6gOe9fvRCm+63ovybk/+N15HHGJh9YomWMhCdY/nf8AiQ/nfEPxLJJ999Rnri69k/aC8LXngr4veIdIvAzied54WKhfMSQk9j+H1rxv/rn92v2PAT5sJR5D24Q9wkTfv+T/AJ6wbf8Ax+v3Q/4JsW7v+z4PMb7mpXH/AKDHX4X7/JTf/HuTyl/vv/cr+ij9g3wXqHg39nnRrPU48T3kjXhyCp/eBcZz7AV8Lx3OEMu5Oc4cf7kD57/4KgQ7vh74OT7rfbbr/wBBjr8V9m2v18/4Kl+Jbby/BfhaFj54ea5kA7I20D9VNfkHvR/vu3/fNejwbRnSy6BrgP4Xvn15+xC+z4/6U/8A0wnr9aPjNc7/AIWeLY/+nN6/J/8AYes57n452l1ArPFa2s7s22v1I+M1yn/Cr/Fr7vk+xvX5xxN7+c0eQ4sTPnqwPxj/AGY32fGnw1/11ev2E8Z3H/FN6wn/AE53P/os1+Pf7Nn/ACWbw1J/01ev1s8YP/xINY+b/lzuP/RZru4m/wCRjRM8d/GgfhPN/wAfEv8AvPXrHwHfZ8WvDn/X0leTzf62X/ef/wBDr1T4Gvs+K/h3/r6Sv2Sf+6HtVfgOb+JPz/EDxC//AE+z/wDow1+mn/BOph/whPiz/sIRf+i0r8y/iM2fHev/APX7P/6MNfpp/wAE7cf8IT4s/wCwhF/6LSviOJv+RKZT+A/Qz76/8Cf/ANDqOpN/y/8AAn/9Dqu77a/kWBiDffqu9SP81RvWpUCN6jb79SVG336DqI6gm+9U9QTfeoAiooo30Af/0PtxKkqNKk37q/zfP6ELEP3akqOH7tSVmBYSpEqBPuU+gzLCVKn3KrJVhH20EzJK/Nf/AIKK/wDIH8E/9d7/AP8ARUVfpQnzV+a//BRX/kD+Cf8Arvf/APoqKvv+EP8AkZwIh8Z4f+wVL5XxqvH/AOoHcfn5S18ea5/yG9S/6+Zv/QzX1v8AsJvt+Mt5n/oDXH5+UtfJGuf8hvUv+vmb/wBDNf0zR/36Z0/8xImjag+k6rYar/z5zJJ9cHNfvx4H8a6R438F6X4l0i4Ro5YV3puy0b9x+Ffz5/xJ/sV7R8Jfjx4x+D9/s0qWO80yf71lJXk8TZFPM6PPD4zlxmDnM/QD40fsw+HviN4ifxLpV2dG1F/9Yu3crf7XUc18/t+xNrsLKt94ij2f7Mbc/rXYQftu6NNbj+0vDs0czfe8qT5f5VG/7Z/hl03/ANh3f/fyvjcH/bmEh7E4uSr8B7J8MfhXofwl0R9NsZY5ruf55Z2avF/2qfGVrY+E4/DUcgN1fybmQHlU/wDr1x/iT9sD7TZNHoGhtDL/AHp2r4317xPqfi/UJ9X1ubz52/8AHfavSyrIcXPF/WcYZYbDTnPnrGfauba/t7rb9yZG+ig1+uHhjVbXXtEstYtfnSeJH21+Q/z/ACfN/vV7x8MPjvq/w7thpl1bnUbD03bdv6GvpOJsnni4QnRO7GYadWfuH0Z8Qf2Z18aeJJ9b0y/SxFwcshXd835iuo+DXwC8UfC/xI2r/wBsx3FvKnlyR7du7v6muTtv2w/B23emg3f+181akH7ZHhNG/wCQFcD64P8AWvhZ0c59j9W+wcM4Yjk5JwPtz7DbXatbXMYkgbgj/Zr5P8efsV6R4n1OfVPCGqf2M8r7vs5QlMf72c/oay4v21/BkPXQL78Cn/xVbEP7dnglE+bw7esfQlP/AIqvEwGAzzBfwTmhCrD4Dh9J/YB1dr0JrfiaJYec7UZm/XbX6CfBf4KeD/g7ov8AZ/h5TLeOv766f7xb/Cvku2/b78BRf8y3e5/30/8Aiq2Iv+ChvgKPr4Zvz/uFP/iqMyo8Q433DWftpn6Ca74Xi8S+HNQ0PzDD/aFu9tuX5tvmAjd+FfmWf+CZniuad0svGFv5WcrmBv7zf9NPTFeiQ/8ABR/4fQlWHhS/b8Uz/wChf1rct/8Agpp8O7ZefCOp/g8f/wAVXNluDzzL4cmGgEPbQ+A+vP2W/gM37PPgK48L3GpJqk9zcm5aZV29VRcYyf7vrWH+1b8Apf2hfCdhoNnqiaXcWE3nqXXcrcEY6j1r5rl/4Kf/AA+k+54U1FT7mP8A+KrPm/4KZ+ApeB4Uv2X3Kf8AxVcP9j559b+ucnvnNCjPn5zwub/gmx4yi5bxXZr9Ym/+OVnt/wAE5/F//Q12OPo//wATXtjf8FHPAr/c8Laiv4x//FVj3P8AwUP8Eu3/ACLt/wDmn/xVfZQxnEP2/wD209Hnqnjc3/BPPxfE/wDyNNj+T/8AxNRj9gXxLBIPtPie3MQIzsRj9euK9Ul/4KAeCZW/5F2//wC+0/8Aiqy7j9vHwYzf8i3e5/30/wDiq1+s5+a89Y90+D/wN8K/BbS5U0qdrzUrpdjXbVufETS73xL4W1Hw1plwsEl5Ht3tu455r5bm/bn8HP8A8y9fVlv+2r4Sm+5od4n+9XyNbJ82q4j6zOHvniTw1aczz8/sV6/CA8viKHd1GI26fn/SvpD4TfDhfhV4ak0E3Yumebz2dRj5sAe/pXj7/tk+Fd+9NDu/++qz3/a98MP9zQ7uvpMfRznF0fYz+A6ZwrTgemfGb4an4n6PZ2VvdC0ktG3ZYZ3e1fMb/spa0nyprcP/AHx/9nXoD/tXeGZv+YLe1Tf9qLww7c6Nc1rg/wC2cJS9jRgFH20PgOHT9lXXXb/kMQ/l/wDZ1c/4ZH8QM3/IYh/74/8As67BP2pfCqN/yBbutBP2tPCK/wDMDu69L6xnn8h3e2xf2Dl7D9jzWPNRH16JP91a+tPg/wDBzQPhdYSwac7XN7P/AK2dq8HT9sPwcn/MBu/++q0Lb9s/wWn/ADA73/vqvEx/9uYuHJOBzT+tz+OB9UePvCep+LPCeo+HtImWBryPbvbtzzXxna/sI+JXVS3ieHn+5A3H/kSu4H7bPgnGH0S8/NP/AIqtSL9unwTtVP7Avm2+6f8AxVc2W4bOcFR9jRgaUYVoHvnwI/Z98NfBqOTUPO+26jL8punXbt+g5r6khtp9vkQbXuJPnWP/ANnr8y9Z/b+toYWTwn4WcTkcNdNuVfyA/nXx+/7RPxdk8dr8QU12VdRQ58vA8rbnO3Z0x/8Ar61lPhbM8y9/GTCGAnW98/Yj46/szeEfj3YRTu8mm6xaq6RXarXw3J/wTh+J5k22Wu2UsC8AvvVvy2n+dd54O/4KOQwWUcHjrwsZZ4sKZrV/vfgf8a9o0/8A4KOfBRYt66TqaP8A7qn/ANmrpo/6yZfD2MPfga/voTOT+DX/AATdttD8RW2vfE/VodUjs23La26uFYe7hgevbAr9WI7Kx0Wwt9NsIlgt4IxHGg/hUV+ccn/BTP4TWf8AqNC1OU/7qf8AxVc3c/8ABTf4dzHCeFtR/OP/AOKr5fMstz/M58+JPMrQrTn752n7Vv7J9z8fPGVn4v0/X49Lks7RbbY4ZuA7tnjp9/0NfJb/APBOrxCrBf8AhMrdV/iHlN/8VXsFx/wUf8CzNuTwzfr+Kf8AxVY95/wUN8Cyjf8A8I3qO72dP/iq+owH+sOHpexh8B3Q9ryHtnwU/Z/8L/AvSrlbO9+2395uEl1txtBVfl78ZFeb/tbfEHTPCfwzv9ENwDqWsr5EcQJzsPU8e3868f8AEf7fcN5ZFPD3hhxMej3T9PwGf518B+OfiD4l+I2vt4h8S3fnzD7qjhV+gruyvh7HYjF/XMeaQw0+fnmdx+zq/k/Fzw1/fRq/VzxhN5ega5833bWYf99IRX4x+AfFDeBPF2neJTbtPFZtyq98jFfYniP9r/Rdb0e/srLRJo57iNlBLjj3+5Xt59lWIxGOhOB1Yyjz1YHwm6b5Zfm+4z/+h16h8Fvk+Kvhz/rvXl6O/wB91+d/mr0z4LfP8UvD7/3J6/Q63uYfkO2r8Bz/AMQv+R88Qf8AX5PX6cf8E7cf8IT4s/7CEX/otK/Mf4i/8j54g/6/Hr9NP+CduP8AhCfFn/YQi/8ARaV8fxN/yJjmn8B+hjvs/wC+n/8AQ3qu/wA1SP8AP/4//wChvUdfyBAPsBUbffqSo3rUIEdRt9+h321G/wA1B1BVd33tUjvVegCN6KHooA//0ftxKkSo0qRK/wA3z+hCRH21Ij7qr1Yh+7WYFhH21InzVXqVPuUGZOlSVGlSJQTMkR9tfm3/AMFE8vo/gj/rtf8A/oqKv0gr83/+Ch//ACBfBH/Xe/8A/RUVfonCH/I2gRD4z5//AGHX2/GW5/7A1x/6KFfJmt/8h7Uv+vmb/wBDNfV/7EWxPi9cvu/5hFxhf+2Qr5P1tT/bmpf9fM3/AKGa/pSj/v0zo/5ezMuo3T/aapKK+k5DpI9iJ/CtS7I/7opKKAD5P7qpR/31/wACoooAKNqUUUAH/AVf/eoyn9xaKKDQX5P+eS/980j7H/5ZR/8AfNFFaQ9wOcNqf3F/75qN0/3f++akoo5zME+T+7/3zRRRRzmgfJ/y0VXo+5/q1Wiisw5wx/s1G6RvUlFac5mGzZ9yj/gKv/vLRRRzmgfJ/dX/AIDRlP7i0UUAGU/uLRlP7i0UUcgBlP7i0Y/2Vo31Gjo6/eo+APcJMp/cWjKf3FqNH3VJR/jAZsj/ALoo2R/3RT/n/u7/APdof5P7qf71Rz0f5w9wERE/hX/vmlz/ALCf980n+flo+5/rK054T+2HOH8Hlyf+O/JR+7T7m7/gTUb0dvkffRRPkH7OBG6RvQibF/hqSisuQQfw+X8v/fNRpDH/AHV/75qSigzDZGn8K/8AfNHyf3V/4CtFFac4Bj/ZWiiiuacOcOQP4KPn3eZuaiitQCvUPgn/AMlS0KP/AKa15fXqPwT/AOSpeH/+u9cWM+CczOt8Bz3xF+fx54g/6/Hr9NP+CduP+EJ8Wf8AYQi/9FpX5l/EVNnjzxAn/T49fpp/wTwx/wAIP4sk/wCohF/6LSviuJv+RMcM/gP0E/hX/gf/AKG9FH8B/wB9/wD0N6K/kWPwGkCN6jepHeo3egojb79R0P8ANUbvtoNBk33qiqR33VHQBG9G+h6joA//0vtlPuU9HqOpEr/Ns/oeZJViH7tV0qRH20EFipU+5VZH3VYR9tAElSI9Rp81SJQZklfnn/wUJ0i8uvB3hbW4kJttOu545z2Xz1RVb9DX6GJXF/EHwPpHxJ8HX/gnWgDBqS4DH+FwcqR9CK+t4cx8MLmMK0zCfuH4Z/Aj4iR/C34i2niXU4d+mxK9tcEH5grr1A9iAa9o8Z/s4WXjQXvjr4I6tDrlteM08lmuFlifJ3DJf9Dj8a8H+Kfwc8ZfB3XZNL8SwkWzSMkN8E/dSr/Cf9kkdjyK8/8AD/izxD4Qu49U8L3s2k3inDlH+VgexHf6V/V86PtZ/WcHM2n78+eBX1zRtS8O3bWOqWz2s6feWVdp/Ws/7n+s+SvrzTP2iNA8ZWg0z45eHU1G2bKreWqqswz+I/Qis/UvgP4S8YRPqPwg8RwXiP8AOtlct5Myf7H+so+v+y9zEihieT3JnynRXUeJfBXijwhMbbxFp0loV6MR8p+h6GuX/h8yvchWo1fgOmE4TCij/vr/AIFRXQdPIFFFFBmFFFFABRRRWYBRRRQAUUUUAFFH8dCJQAUUP8i/eX/d3fPXQaN4R8TeIjs0TS7i7b/YQlf0rmniYQ+My54Q+M5+jem/y91fQmhfsw/F3WiP+JWLQN3mO3/E/pXtGg/sXXUO2fxT4gVFxzFajdz9Tj+VeJic9wOH+OZzTxMInwnv2P8A+zLRCj3PyWiyTP8A3VWv1E039mb4UaJ893bS37/3p5K9EtPCXhfQgV0XSbe3KknIQbuffrXzeJ4ywkPgPOnmsITPyr0z4d+NtXRZLPRrgo5xuZdo/M4r0DTf2ePiTf8A+vs47b/ro1fo5Ncz7fkdtn91V2VXTe8qeZud3/2d9fN4njKtD4IGVbMpnxPpv7JmvXmw6hrEVr6qql/8K9E039kfw1CU/tHVriZ/SLES/rur6wS2RERHX5/9n+5/38rU8ywsFRr+5it1w23znCbtnXrXz9biPMef3Dm+uVj5/sP2UfhWmzz4ru5f+9JNXcWX7MPwfg2p/Zbv/vSyf417J59nbWx1K6uYorVF3eYzgJ+fSsvSfid8O9Tv49Os9ft5LmUgIu7lm9vWvJ/tXNqvvnNDE1p/GcfD+zD8Fw3z6AG/7aSf/FVqQ/sqfBOb7+g7P92SvTL/AMc+BNBv303XPENlYXafejkkrYsPiN8OroLJD4nsG+bb80yr/M04Zlm0zphOtyc55PN+xt8DL9PL/syeH/dmrm9T/YC+E19Hs0i91HT5/UOjJ/3yV/rX2RoGoaZr8a3WiXsN9Fu2s1u4dR+IzXcWEW/51KzfN95W3V5kOI82hzmf1msflfr/APwTb14FpPC3i6K6AX/VXUGxv++g5/lXzn4v/Yo/aA8KRGU6IuoRrzm3cN+nB/Sv6ALNIJmRHRXf/d2ba6izttmx0Zk/vr/BXpYPj7HYf3K3vmkMfOED+TvWdD1nw7dfYdesJtOlH3lmQofyOKy/+Wvl7fk/vLX9VHj74V/Dfx7YtZeLNEtbouP9aqbZB/wMc/rX5V/Hf/gnt9njn174N3W7YuTYuPzPmF/rxt/Gv03KuOMJjfcn7h6WGzL2vuTPyrorQ1fR9T0DUJ9I1q3e1vIjh0cYwPVT/EPes+v1GE4fY989uAUUUVoAUUfu9n+1Q+xF8yRv+A/x0BMKHruPDXw18b+LGT+z9LdYJM4mf5U4/n+FeuJ8Ovht4AX7X4/1mPUtQT5/sVp89eRWx9KE/cmc08TCB4X4e8K+IPFV19k0CxkvJf8AZWvojw/4Q0X4NyjxZ4z1GOXVEQtDYwtuf/gX+ce56Vy+r/HTUI4DpfgWyXw/ZjB8xeJWx7jp/P3rwe9vbm8upL3UZmkd+rudxrn/AH2I9yfwGXvzNDXNQfWdbutRnXa1/I0n0yc1+rn/AAT40y9tfhhrOryxgQalqBaEnqQsaD+YxX53/B74G+NvjRrsdl4atDHpcDobi+cFYlUn5lB6M23kDP5Dmv3g8E+E9F8C+GNO8L6DD5dnYR+WCOSx7sT6nvXwHHGb4fD4T6nCfMZ1p+/yQOodNjeXJVd6kd5Hb95UbvX8uQnzhAjeo2+/UlRt9+tTYjqCb71T1BN96g0IqjepKjegCN6KHeo99aAf/9P7UR961YSqaPVjfX+b5/RkywlFRo9SVmc5Yh+7UlV0fbUiPuoAsp9yn1Gj7akT5qDMkR6k+d/k/g/u1GlSJQBj6/4c0PxXpb6H4isotRs5PvRyqGX8jXwH8Vf2B9L1EPrPwivf7PuMs39nXGWifr0fkr+TfhX6MIm6jZ/z0+dP7v8ABX1mVcR5jl8/9mOSEOSfOfzn+NvhV8QfhfdtZeLNCmsZCeLjb+6df9luh/CuL0+e402ZbqxleGUNkOrFW/Sv6XNZ0jSdfsm07WrKG+tX4MVwgkQ/gcivjP4g/sL/AAw8VySXPhOSXwzeSjjb81vuA/ucfoQK/bcq47wmLhyYmHLM6p1v5z839E/aC8badaix15E1ywOQUuhltp/n+Oa6RH+APxFfy51k8ManJ/Evzw/+0qufEL9j34z+B5JZrfTRrthEeLizO58AZ+5jd+Qr5fvYLzT7p7HVYmtJ0+9HMpVvyNffwhhMR7+GmZexoz+CZ9Cal+zb4o8hr7wnf2+uWiDcGjf5/wDvnkf+PV4nrHhXxH4ed01zSruzeP8A56Q1X0XxJrXhy5EukX8lrI3A2Pxj3Xv+NfQGh/tPeNrZEsPEtpDr9sBjZcRLuK/7w4/MGumf1vD/AB/AEJzgfMaPvXenzp/s1J/1z2vX2Ani39mXxzLs8VaHP4SvX/itvuN/t1cuf2b/AAB4wTf8NfH9pNK/zrbXv7l/++/Mo/tLk+OBp7aZ8Z0V9IeIP2T/AI3aBGLldC/tCCXJV7F1uCce33v/AB2vD9c8I+KfDLvBr+k3Viw4xLEw/mBXdDGUZ/Ad0Jwmc/RUasXbyY/nl/55oNzfpXoHh/4VfEjxSQug+G76cMM7/KITGM53dP1rSeJpUv40zKc4HB1Js+X93tr7U8F/sCftB+LhHLeadHoto5+Z7iQZx/urk19WeEf+CZ3hfT0jl8beJ5b+Rfvx2sflRfqzGvm8ZxNl2H+OZzTxkIH49/J/H8j11nh3wF4z8Wyqnh3R7q+B/iSNiv5gV+9nhn9lL4B+CCkth4YjvJ4znfdEy8/Rsj9K9gjtbGwh8ixtIbZEXCrCioPyGK+JxPH2Hh/u3vTOKeP/AJD8N/Cn7F/xu8RASy2Eel8/euG/h/4Dur6U8N/sCeGrCNJfF/iKW6l3/vILVNq4/wB/cf8A0EV2n7Wvxq8e+E/FmjeAvhvqUkV5Lbtc3BwG+Riygcj1U16J+zP8TdQ+JPwrsNT165e71G1kMExf73GDnp6EVzZlmuZ/UfrkPdM54mtOHuGfoP7O/wACvDMy2dlpMd1eLubMjl2/U4r1i1tdN0mLy9KtIbSL+7CgUfkMV8B+Cb+6/wCGytbtJ5ZHt089VjZq++Lmb5fvV8TnX1ulOHPW+yeZW54fGcH8QviFo/gPQX8R+Jml+zo23ctcP4C+Kvh74pWtxqHh5JkjtpFjy+Afn+hPoa8r/bDudnwvij++j3ifLXlf7Mlwvhrxj4h8L3LlFlt0vIx/wHcPzBFe3gMlo4jLoVvtmf1bmo850nxF/aYvPDHjGfwnpmlw3C20xjaZnxlh142H+demfE34lW/gTwdHr06hr+4j/doOMtX53+JpP7WvL3xZIctPq8qD0IQI2f8Ax+vdP2jbx7z/AIQzTt37p4kdq+pnkWHhOHuHV7GEIQOXf4kfGzUrdPFVpFImn7v4Y96V9WfBb4lL8R9Aa5nUx3luWWQDjPy/ertNJ0O1h8LWvh2Jf9G+zqhHXLsuC35818p/s7SLofxW1/w0gbawlA3H/nm2P61y/wCz42E+SHJynRzwqnSfAfVdV1j4v+I7W+1C5mt7XfsVpP8AbrQ/bAufJtfCkCMyeezu3zVh/sxw+d8YvFH/AAOtj9seHZe+DkH8Qm/9CWn7H/hWhAzh78/fKf7TfibUNF8J+EPBOiSeSL+0U4ztyFUDFV/A/wCyZ8QdA8R+GPF97JayWsVxDPLGjEOqqVfpjGeMdaP2ttFurK28DeIol3RJaRRkkdG2k/4/lX2x8BvixovxW8NWws5QuqW8KxzW+ehVeT+NdOZYnEYTA/7N738xpz+57h8t/Hr9lz4mfED4j6j4v0G2tW05lQLl8NtQAdMY/WvjPwP8KfG3xE8SXPhPwvZJPf2aM7AMBwv1+tfvxsge1uJ/KX5ILr7v+5X5j/sIwC8+OniG5T5ZEgl5/wC2rVlk+fVp5dOfJ8Jpg8T7h9Mfs7eDfFHwS+A3i+48Xwiyv4DNcoCQc4iX0/3K+H/2bfit46g+N/hltY1e8bTtWu2BjaU7GMrYyR064NfpZ+2DrkXh/wDZ51mVT5cl/iPrndk8/pmvzT1XRH8B+GfgZ418jY9632iX+D/VT/365sq/2vCVq1aHxhDkmfr5+1F8QfEvwq+D+o+OvCciR39vPCo3jOVdwp/nXwH4T/4Kb/Euxmth4s8N2upwXDYEqObb/Z7pLX2Z+3SIL39lbVLlerGzkX/gShq5P9lbwh8JvFf7NHg5fFmnaTe36W8okaUIZVcTydTjOa+by2jhKWUzniaPNPmPOhD3Oc+rPFPxV8NeGfh7bfEjxRN9ksJ4YpDgFseZjHHXnIri/BXxh8BfE+2a88E6kL0RfeJBVh+BxXy3/wAFENXXTfhToHgnSIlgtdW1BYwgxnbGqk/qRXgf7IcMvw1+OHif4Z3JKRy28UkIbuSqv/I15tHhmlVy6eMo/GaQo+5zn0Z+078AtH+L+hXWsafAkGv2EYaORF5kWPcQh+pPBr8R9R0+70m/n07UU8m5tm2yIfvBhX9Il5Ns2bPk8v71fm/8cfg78EdO8cT+L/HviJ9IOpK0otYhl32AA44Pc+nU9a+k4Q4grQh9TxJ04PE8nxn5n/8AXRdldp4b+HXjjxVOkGh6NPco/wDEq19EXPxX+BHgmXyPhz4M/ti7j+7e3/3P++K4PxN+038S9ajays72PRYMYxZptPP+1kt+Rr9j+s4ur/BonpVq05+5A3LH9nNtKQ3PxI1uHRY4xv8AJDI0pXt0f+WakufGHwT8Bts8K6VJr17Gvyz3LfJv/wC/dfM97qF9qdwZ9VuWurh/m3SuxJ/E0aXp2razcjTtJspbu4f7sVqhlc/gATWc8BOfv4mYex/nmeseJvjT498Uw/ZprgafZqu0Q242qPr3/M14399nnnkZE/ikk+Te/wDv19YeAv2OPjd41aOa+03+w7NjgvcHEqjGd2zg/nivvT4a/sQfC3wcY9Q8UK/ibUV+8LgDyh/wDkfnmvIxmd5Zl8PjCE4Q+A/KfwH8IfiL8U7xbbwZokt3Hu2tMw8uIfVzgfrX6MfCj9gvw9pAXV/ilcHULyQKVtYsqkR46t1b8h+NfoRp+n6bo1olhpFsllbou1ViXaB+AqwfuJX47mniBiMX7mA92ATnzmXpWi6RoFjHpmg2sdlZxHARB8rE9296uOm2pHfbUbvX5JVrTqz9tMyhCBG9RvUjvUdcx1kbvtqN/mqRvv1HQaEbvtqN33Us33qioAKjeh6jeguBG9R76keo9laGvIf/1PsxKuJVNKkR6/zfP6MmXEqRKr76kR6zOckqxD92q9SI+2gCxUqfcqsj7qsI+2gCSpEeo0+apEoMyRHqwnzVXSpEfbQTMkqT7/8ADUafNUiUThz/ABmJJ99dm5v+AtXB+L/hR8O/iBbNbeKPDtndnr5/lATDjHDj5v1ruKkR69LB4zEYf/dpkT98/Pfxz/wT28G6rFPd+Bddl0O4x8sMi+bFn8wf1r478X/sX/HXwiJWg01NZtojw9i+SRj+4cN+lfuh/rP9irG+fzfM81t/96v0TLfEHM8P/vMOcIc8PgP5i9f0PXPDt19i17TprGX+5MjIfyIFZ8O+Fd8G6H/db/43X9NmueHdC8SQNBr+n298jcbZ4lkH5Mpr5n8WfsUfAPxRO95DpMmizsCCbGXyk3k53bMFfyFfoeD47wOI9zEw5ZnT7bkPxz8IfGL4l+Ciq+F/El1BGT9zexTrn7rZH6V9GaT+3N8VrUC28WWWmeIraMYxdQKz/wDfSlf5V7h4v/4J0hoZJ/CHjIuy5IttQg/LM8bfyi/xr5r8TfsUfHzw6JZ4dHh1mCE/fs5geP8Atr5R/SvqIY/KcX9sz9tD7Z9SfCL9rT9mm/1JLvx58PrLwxez/wDL3bQ+dD/3x+6r9TPh58Rfhb4v08XPgjWNOnjbpHEFicfUHkfiK/mX1z4V/EjwyI217wze28bDO94CQBjP3l4/HNc3o2u634evDcaLf3Wnzxdw5iI/EV52a8M0sw/3asc9bCUavwTP6zNSm2bPP8z7v/LSubvLn915e6v5/wD4d/tx/HnwQfsd3qya5YKeUuvnfpj7/wB78zX2R4P/AOCiXgzUxFbeNtEm0lwCWltz5ik9vlwD/OvyDH8D47Dz/mPM+rTgfohcumyubublEf8AeN8ib3Zq8v8AD/x3+E3jWNF8PeJoZ5JB9xvlf8jg/pWh47vtTtvBmr3OiwnVLp7dljS3JZt54HTmvm6OT4iGIhCtA4uSfOfl2Pin4Fu/2qdc8Z+Pb37PpdotxbRrzJyEMXGM+54+nvXQfse+L7Cy+IXifwhpd0JdLvJHntmPBwGwPlJ9CPyrsP2YfgEsWn+Idb+MPhtZ7q8kHkx3SfMMA9j9a5fxn8OtY+HX7R2ieJvB2iyJoU+zzVto/kVJXeP/ANkr91xOMwk4f2bznrTrQn7hh+G/9G/bK1OR/wDlozo1fejzSPF93/x6vzf+It/4x8DftE6x4/8AD+gz38W7fF+7+98le6fC748eJviL4l/sDxB4c/s35d/mMtfN59lVXEUoVqP8pzYmjzz5zD/bCff8OrBP+n0f+gNXi+pX6eDPi1o+qxvsi1TQoN3/AG1gr1z9ryZ/+EO0u0+9i939fRSP/Zq8b/aP0uWz0DwdrULDfb2iW7H/AHV//XX0nD8/ZYeFGZ04bk5OQ8v1LTPL+C8Op/xPqkx/8dSu8+NL77LwFqL/AHHtUSrnxC0h9E/Zz0e1ki2S+akrbf8AprXUfEXwrd+JPgV4c1mxgZ7vToN23+PZXtzrfBOZ0H154fUTWNlOn3Hgh2/98CvjP4UJJ/w07qqJ9z/Sv/QK9U+FXxu8Jr4HtU1u/FvqNhGIhE3322Dj9BXm/wCzJaTeKPjBrPjBEYQZlK57+Y2a+bweGrYedadb4DzqMJwNj9mSPy/jL4piHLRJKPTo4FaH7ZZH9seC4P4lEmf+Bsv+Fc38NNb034aftHeI7HxGy2dve79skjbEo/aG8R6V8RvjL4W8PeGpherb7Yyycrlnx/hXT9Tn9ehiYfBymkIH3Z40+F+n/FD4aweF9QwtylvEbeU/wt5Q/h/nX5f+Erzxf+zp8Y4IdQDQSRSeXIB8qzRfj+f1r9cNV+IfgnwXr1h4T8S6iljftCrgsdq4KnqTx/Ca/PP9uPxD4Q8Q+MfDdx4au4tQvLaE/aJIjlT83yrn25PXvXk5DWxE51sNWh7kh4ac4e4frQbiG60Oe7tcNFPYTSqw9HhLD9K/NP8A4J8xpJ8XvFl12SBsf9/Wr9EPClpcW/wpsJbpWjlTQ23BvaCvgf8A4JyW7Xfj3x5cgcLAuB9ZW/wFeJg6PJgcZCBpH4D0T/gpFrkdh4E8MeE45P315cSyMMfwqq9/xr5f/aG+N3ww8d/BzwB4M8GSv/a/hIRxyAx7FJ8tBJ9ckDGPSvTP22YH+Jv7Svhb4YWUxjjWOK2aVRuwZ5G3NtHoMfgBVz4+fsEaF8JvhNq/j3S9fur65sFXCGIIvKgf3z3r6zJPqmFwmGo4mfvyNYckIe+fVH7Qeur4v/YJsPEUJ2i8t7A44bmKVkbp/tKc1+Wfw1/Zw+PPjjwtYeLPBNk76QxOHNyq4w2CpBINfYln4nTXv+CcFxYyNvfS54Lf/cT/AFn/ALPX0h+xRPu/Zv8ADzTkeXm4Xr/dZhXFPE4jLMDPkhz+8csPcgfKf7buvL4fm+F2g62D52k2qz3caNu/eNgHP4ofwrzOP46eE/Ff7U3hP4g+E7Cays7yGKxnjuPlBkLEb+CR3X8q9E/aItbL4h/tk+HvCeoGO60+zWBJkfP3H/enp7PW5+1B8F9I8Oy+FtX+GHh1LSSwvV8xbWMDJ6hiAOxH616VHGYeFKFGt8conTCcIfGfdmpTJDcXEaNvRP4v+AV+Wf7dN/BceKvDdrFjzLa3Zps9lcsB/Kv0cuNYWPQrfU9QH2QxW6tMX/hJ7f0r8W/jL4sk+KXxUv8AULNvOjmuLeztEzjcu7A6nuT+tfN8LYOf16dbk9yJz4OHv855n4f8O+JvFEkdpoej3F9K5wFiiZsZ/wBoCvpzwT+xR8dfFMyzXenJ4ftmOHe6bceP9kZP6V+0ngrwzpnhTwxp2kafZRWpit4lcoirlwoBJ9z1NdZ8jr+8Xe9a5lx9WpVvY4Oiel7atM/PPwT/AME+PAWl+Vc+N9WuNcuMfMiHZFn9T+tfZnhP4Z/D7wJaCz8J6Fb6cFJJaFfnbPXLdT+JrvHfZ/t1Xf5q/JcZxNmON/jTNPY/bmSJM6fJu+So2+/RUbvXy3xz55kkb0UVG77aABvv1XepHeo3egqBG9Ru+2pKjb79B1Eb/NRRUbvtoAZN96oqkd91V3oAHeo3eh6jb79aFwI3ejfUb0UGp//V+zEoX79Ro9SJX+b5/RhcqRKro9Sb6DKZYSio0epKzILEP3akquj7akR91AFlPuU+o0fbUifNQZkiPUlV6kR6CZllPuU+q6PVhPmoMSSpEqvUiPQBZT7lPquj1JvrLkAsVIj7aro9SVryGZY++v3aPk/1jrvf+81Ro+2pE+agCOdEuovIu4kmj/uuilf1rw/4g/s1/Bv4mI7+IdAjS5Ygi4t/3bjHqR169817pRXt4bOMXhPfozI5D8r/AB7/AME6rqLzNR+G/iLeiKWNrdJ/F7Pu/wDZa+L/ABl+z18ZPA7u+veFpmiA/wBdar5ibfcrkCv6JN/yUffi8h/ni/iWv0jLfETHUof7ZDngac84H8t7PLp8vzSSQzp8uTmJ1/rXpHhb4xfEvwdIW0HxFdRxrj5C+5DjttPFfvh41+Bvwm8fRsviLwxayzspXz1QLNz/ALYw3618h+Kf+Cdnw+vFluvCet3WmS4+VHAkiz+h/Wv0TDcZZTiof7T7pt9Zh9uB8t6H+3B8RLVI49esLfUwu3DYKt/PH6V7JoP7aPgi+iMOvWFxpDsPvIPMXP6H9K8b8a/sG/GvwpIZtE+y+I7NhkNay7No9GWTb830zXy3r/wz8feFS/8AbXhm9tEH3mMbMB9SRgV639l5Njffwxy+xw9U/WTS/jV8NPEcYbT9dty7jOyUbG/XFdBDNps8y3VjLZyEj70LI5/MZr8Q9/zbE/1v3fm+R63LLX/EWj82moz2p/uiU4/75zivEnwb7k/YzkZzwf8AJM/YTWdP0fVolh1S2S4SM7lV1z8w/irm9b0fRtbsksdYsYLy3j+7Gy1+c+i/Hr4n6REYodR+0R5xiYb/AOfP613mm/tTeKIZFGr6XDcf7uV/xrxP9Vsdh/gmebPBzh8B9keIPBOg+LtLTRNXhYWY2bUjbao2dOmK6zQ/D+maTo8fh22jMlmoMe2Q7vlr5b0r9qnw1MwfUdLe3Pfym3L/AEr0zRv2kfhTfyKJtRNk3pLG/wDQEV4lbKsx+CcA/fQgY+v/ALJvgnXtTkvrW6m0/wA1tzImCn6g19EfDX4a+Hvhnov9ieHoyryHdJM33masfSfi18MNTJaz8SWpK9iwU/kcV6Zpuv8Ah3UFV7HVLecnoEkU/oK4sZWzacPY1vgM51sQeD/Gj9m3T/itqC61pV0ml3+MMWVmDfqKj+CX7Jtt8P8AX18Ua9qg1S5i/wBWqrtVf1NfWFm6TJ+7l+T/AGZK6i2tt/391cP9t5pCl9W+GAvbVfgmfHf7Rn7MPiH4w6/B4s8PajGtzHAIhDKv90s33t3+10xXmfwl/YN8T23im11f4iX9r9js5Fka3Ql/M29t3y8Gv0wtrb5Vj/8AZXroLaGPen3f8/8AAKzhxJjoYf6tCcTp+s1vgI73TpbrQLvTrLBeW1e3j3Hp+72L+VfLf7Gv7Ofjr4Ea14p1XxgLfZqyRpD5bk/dZ27geor7Qs7ZPnk2x7ZPk27XrqLC2k8r59v3k+7vr5+jnWLpUp0fd94z55nwXov7KfjnUv2oZvjl4lv7NtLjuzJDbhiz7MfL82BjHHftX2h8X/A8XxH+Hur+BZrgWo1KPaHIDbT1ztNekIkaW+9F+5/s1zepXjovnzyxJ/vNWU81x2InCt8U4/Ccs/fPhvwp+yHpnhz4K6p8G9X8QPdWerXCXJkiQp5ZQg/d3t/cFeufDP4e6R8JPBNn4J0SRp7azZmLP1Yucn+ddp4h8e+D9GVm1XXbG2I/heZEb8ia+Z/HH7WvwU8Jxsra2uoXOcCG1G9unr0/M19BP+1sw9yZ08k5wPSLrwR4MtPEjeM59LhfVJWXN0w+b5ABx+AFU/E3iDRdC0+TVPEN+ljYK2QSepPT5a+A/Hn7e884a3+H2ifZ227fPvDubPsm3/2Y18N+NfiX4z8fXbXvizVpJ06iPO2Jc/wgdK+ywHCeOxHJPGfAd31CtP35zPpD9oP9pu68fGfwv4QZ4NOB2lyeZuf4faoP2LvhDL8RPijb6/c27No3hJhNJIy5Rpeqrzx7/hXlXwX+BfjP4462lt4egaDTomHnXzp8sK/xbem4+2fyHNfup8NPhp4d+FXhCDwh4Xh8qBVHmSY+aZv7zY/z+FfUZ9j8JkmBnhsN8czp5IQhyUT0BKko3738yo3ev5Z+P35/aOmHuQI2+/UdDvUdaEg71HQ9FABUbffod9tRu9BUCN6jepHeo6DYjd9tRv8ANUjffqOg0I3fbUbvupZvvVFQAVG70PUb0FwB3qu77qkeq9aGoO9G+o3ooA//1vsVPuVOlU0fYtWEev8AN8/owkX79XKppVhHoAsJUiVX31Ij0GUySrEP3ar1Ij7azILFSI+2q6PuqSgCwnzVIlQJ9yn0GZYSpEfbVdHqSgmZYT5qKYn3KfQYkiPUlV6kR6ALCPtqRHqvUiPtoAsVIj7aro9SUGZYT5qKjR9tSJ81ABUm+o6KznCHxgSUf7e5kf8AvK1R1JvoAkd98vnvud/4W3VXuYI7yPybuKKaP+7Iiv8AzqSitIVq1H4JkThCZ4/4m/Z7+DHjGN217wpZySOMeZGvlv8AmuDXzf4g/wCCeHwf1GKRvDV7f6LIx5VZVkU8/wC2C3/j1feFH8dfUYPinM8J8FaQexPyL8T/APBObxnZOG8L+KYdRDfdS6i8pv8A0Jq+e/Ev7HX7QHhy5MT+HTelQW32b+auPTHDbvbFfv5v+Sh3d2+83/fVfb0fETHQh++hzHTCc4H8yerfD/x74fd4Nc0C+sWj+8ZYnUfmRXL/APHmnlv8j7v4lev6kJ7W1uYjDdwJMn911Vv51xesfC/4d64mzUfDdhL/ALTW8e788V9RR8ScPOH76iHtpn8z77Jv3+2N3+5ujkoW4u4ZP3N0/wAn8Su3/wBav6BNf/ZG/Z819JFufClvDKcfvoRsYY/3ceteP6t/wT1+Cl1G76Ve6tZTv0bz4mRf+A+VX0FHjjKav8xp9YPx/tvGPiqwVfseu3luP7sc7Kv5A11Fl8YfinpnyWfiu9Vd2eJmP9a/RzUP+CcPh5oR/Z/jS6hPfzbdXH5iRf5Vw93/AME5NeR2/s/xpbsv/TW2P/sstet/b2R1YfHH/t4z9tD7cD5DtP2kfjlpw223jK9I6/vCsn6sCa6Sy/a+/aKsk8uDxW7p6NErf0r3y7/4J1fEVQDZeLdKlJAyGEi/+yn+Zrn5P+CfPxk/5Y63pL/9tZv/AIzRDGZHL3/3Rnz0f5Dzf/htj9pdP+Zs2f8AbGq91+2h+0rdDB8ZSxD0RI1/9lr0j/h398a92X1HSP8Av7J/8aq5B/wT2+LrnL63o8f/AG0l/wDjVa+2yD7fKHPR/kPB779qf9orUY/Km8fajHGTnEchjH/juK4fUvi18UNVX/ia+L9QvH/6b3FfZlv/AME6fiDtzf8AivTI/wDZQSN/7LXcaH/wTjt3iH9teNXx/F9ltvl/8ekrL+28hpfy/wDbo+eH8h+Yd5qeq38u++u5blv+mjs/86pp8jeXAzbvv7Y13vX7OeGf+Cf/AMG9KPm6ve6nq8m7q8oVP++VUH9a+jPDPwE+EXgoq2g+FrOOZf8Alq6BpMj/AGjz+teJieOMpwvwF+2gfhf4L+CHxW+I1zHD4a8N3EsMjYEzARxdM/efAP4Gvvz4V/8ABPyztJoNZ+LN8L11YMLG3BVcf7Um8E89to+tfpZDDbwrsgiWJP4VRQo/SpN//PT/AMdr88zXj7F4j3MH7kAnzzMfRdH0jw5p8GkaDaxWVnEMBEGDt9W/vH3rUd9/36Puf6uo3fbX5LWrTqz56xlCEIfADvtqN3of5qjesiwd6N9RvRQAVG77aHfbUbvQVAHeo3eh3qOg2Co3fbQ77ajf5qAB/mqN321JUE33qDQR33VHRUb0ADvUe+h6jdKC4A71XoqN60NQd6j31G336N9AH//X+vEerKfcqts21Ij7Fr/N8/owsVIlRp81SJQBcSiq6PVigJkiPUlRpUiVmc5Yh+7UlV0fbUiPuoAsI+2pE+aq9SI+2gCSpEeo0+aigzLCPVhPmqmj1Ij0EzLFFR76kT5qDEkR6kqvUiPQBYR9tSI9V99CPQBc30I9V99SI9BmXE+aiq6PUm+gCSio99SJ81HIAVJvqOispgSb6KjoqAJKKN9G+gzCpN9R76N9aGhJvqOjfRvrMA30b3/vbP8Ado30b6uAB5zp/E3/AAGo/wAG/wC+qKK15IGZIjuv/wC1Q7/7K/8AAqjqN321lyGhJ86b9jbKr7Nn32Z6k31G/wA1HJACTfUb/NRRvrU0Co3eh3qu/wA1AEm+o3eio6AJN9Ru9FR0AFRu+2h321G/zUFQB3qOh6KDYjeo3fbUlRt9+gCN/mooqN320GgO+2o3fdQ77qjoAKjd6Heo3eguAO9V99Sb6rv8taGoVG70VXb79AA/zvUdDvUe+gD/0Prjzt38NSI9U99WEfbX+ckz+kCwj1YR6po9WU+5WRmTpVjfVOpEoAuI9SI9V0fbUiPQZTLFSI+2q6PUlZkFhH3VJVdH21Ij7qALCPtqRPmqvUiPtoAkqRHqNPmooMyxUiPtquj1JQTMsJ81FRo+2pE+agxJKKjqTfQBJUiPtquj1JvoAsI9Sb6po9Sb6ALFSI+2q6PUm+gzJN9G+o6KALCfNRUaPto30cgElFR76N9HIBJRUe+jfRyASUVHvo30cgElFR76N9AA77aN9Rv81FAEm+o3+aijfQAUVG77aj30GhI71HvqN/mooAH+aio99G+gAd6N9R0UAFRu+2h321G/zUFQB/mooqN3oNgd6joqN320ADvtqN/mof5qKDQjd9tRu+6lm+9UVABUb1JUbvQBG9RvUjvVd3rQuAb6jeio3eg1I3fbUb/O9DvUdEAI2+/UdDv89G+teQD/0fqyrFV6k31/nJM/pAsp9yp0fYtV0fbUiPWRmXE+apEqmj1YR6ALFSp9yqyPUiPQEy4lSJVdHqRHoOckqRH21HRWYFhH3VJVdH21Ij7qALCPtqRPmqvUiPtoMySpEeo0+aigCxUiPtquj1JvoJmWE+aiq6PUm+gxJKk31GnzUUASI9Sb6r1JQBIj1JvqvUm+gCTzqkR91V6kR9tAFjfRvqvvo30GZY30b6r76N9AFjfRvqvvo30AWN9G+q++jfQBY30b6r76N9BoWN9Ru+2o99Rv81AEm+jfUdG+gAf5qKN9Ru9AEm+o3ejfUdABRRUbvtoAHfbRvqN/mooKgDvRvqN3o30GwO9R0VG77aAB321G/wA1D/NRQaBUbvtod9tRu+6gAd91R0VG70ADvUbvQ71Xf5qC4A71G70PUb1oag71Xd6kb79V3oAHeo/O+Shvv1HWsAI3ejfUdFWaH//S+rE+aiq6P8lWEev85z+kCTfVhH21XqSomBYR6sp9yqafcqdH2LWRmWKkR6jT5qKALCPVhHqmj1Ij0GUy4j1JVdHqRHoIJKkR9tR0VmBYR91SVXR9tSI+6gCwj7akT5qr1Ij7aDMkqTfUafNRQBIj1JVepEegnkLCPto31HvooCZYT5qKjR9tG+gxLG+jfUafNRQBJvo31HRQBY30b6j30b6AJN9G+o99G+gCSio99G+gCSio99G+gCTfRvqPfRvoAk30b6j30b6AB3o31HRQBJvqOio3fbQBJUbvto31G/zUASb6jd6Kjd6CoEm+o3ejfUdBsFFRu+2jfQaA77ajf5qH+aigAqN320O+2o3fdQAO+6o6Kjd6AB3qOio3fbQXAG+/UdDvUbvWhqDvUbvQ71Xd6AB3qN3od6rv81EAB3qN3oeo3rQ0B3qPfQ336jrQD//T+oU+5VhPuVWR9tSI/wAlf5zn9KzLFSI9Rp81FBkWEerCPVNKsI+2omBYR6sJ81U0epEesjMuJRUaPUlAEiPVhHqulSI+2gOQsI9Sb6ro9SUGUySpEfbUaUVmQWEfdUlV0fbUnnf7NAFhH20b6ro+6pKALCfNRUaPto30GZY30I9Rp81FAFjfRUe+hHoJmWEfbRvqPfRvoMSwnzUVXR6k30ASUVHvo30ASUVHvo30ASUVHvo30ASUVHvo30ASUVHvo30ASUVHvo30ADvto31G/wA1FAEm+o3+ajfUe+gqBJUe+jfUdBpyEm+o6Kjd9tBRJUbvto31G/zUGgP81FFRu+2gAd9tHnf7NRu+6o6AJHfdUdFRu9AA71HRUbvtrQuAO+2o3eh3qN3oNQd6jd6Krt9+gAd6jd6Kjb79EAI3+aiio3etAB3qN3od6ru/z1oaA7/PUe+o3+aigD//1PpxPmqRH21TR/kqwnzV/nOf0rMsI/yVYT5qpo+2pEf5KDIuI+2pE+aq6fNUiUAWEfbUiPVepEfbUTAsI9WEeqaPUiPWRmXEepN9V0epN9AEiPVhHqmj1Ij0AXN9G+o0+aigymWKKjR6koIJEfbUiPuqvUiPtrMCxRUfnf7NCPuoAsI+2jfUdFBmWE+aio0fbRvoAsb6N9Rp81FBPISI9Sb6r1JvoDkJN9G+o99G+gOQk30VHvo30ByElFR76N9AchJRUe+jfQHISUb6j30b6A5CTfRvqPfRvoDkJN9Ru9G+o6A5CTfUdRu+2jfQUSVG77aN9Rv81BoSb6jf5qKjd9tAElRu+2jzv9mo3fdQBJ53+zUbvuqOigAoo31G70ADvUdDvUe+guAO+2o3eh3qN3rQ1B3qN3od6ru9AEm+o3+d6N9Ru9EAI3fbUbvQ71G71oAO9R0VG77a0NAb79V2+/Ujv89V3+agIEbvto31G336N9BryH//1fpFPuU9Hqmj1YR6/wA5z+mC4nzVIj7apo9WE+agiZYR/kqwj1TR9tSI/wAlBkXEepKro9SI9AFhH21Ij1XqRHqJgWEerCfNVNHqRHrIzLFSI9Rp81FAFhHqTfVdHqSgCwj1Ij1XSpN9BlMsb6Kj30I9ZkElSI+2o99FAFjzv9mhH3VXqRH20AWKKj87/Zo87/ZoAsI+2jfVdH3VJQBJvo31HRQBYT5qKjR9tG+gzJKKj30b6AJKKj30b6AJKKj30b6AJKKj30b6AB320b6jf5qKDQk30b6jooAH+aiio3fbQBJUbvto87/ZqN33UASed/s1G77qjooAKKKj30ASVG70b6jd60LgSb6j31HvqN3+eg15Ad/no31HRQAO9Ru9DvVd3oAHeo6Kjd9tAA77ajd6Heo3etYADvUdFRu+2rNAd9tRu/z0O/z1Xf5qAgD/ADVG77aHfbUcz0GhG7/PUe+o9+6ig0P/1voRHqRHquj1Ij1/nOf0wXEerKfcrOR6uJN8lAFipEfbVdH3VJQRMsI/yVYR6po+2pEf5KDIuUJUaPUlAFhHqRHqmlWEfbUTAsI9Sb6ro9Sb6yMywj1Ij1TR6sI9AElWU+5VbfRQBY31Ij1XqRKA5CxvoR6r76kR6DKZY30VHvoR6CCSijfRvrMCRH21J53+zVeigCx53+zR53+zVeigCwj7qkquj7ak87/ZoAkoqPzv9mjzv9mgCSio/O/2aPO/2aAJKKj87/Zo87/ZoAkoqPzv9mjzv9mgCSo3fbR53+zUbvuoAk87/Zo87/ZqvRQBY87/AGajd91R0b6ACijfUdAEm+jfUdG+tAB3qOh3qPfQXAHfbUb/ADUO/wA9G+g1Co3eh3qN3oAk31G71HvqN3oAHeo6Heo99EAB321G70O9Ru9a8gA71HRUbvtpGgO+2o3f56Hf56rv81aBAH+ao3fbQ77ajd6DQHeq7vUjvVd3oNAo31G70b6AP//X94R6sI9U0epEev8AOs/pguI9SI9V0+dKsJWYFxJvkqRH3VTR9tWEm+SgCxUqfcqsj7qsI+2giZYR9tSI9U99SI/yUGRc30b6jT5qKALCPUm+q6PUlRMCwj1Ij1XR6kR6yMyxvqRHqvvoR6ALm+jfUafNRQBYqRH21XR6k30ASb6kR6r76kR/koDkLG+jfVffRvoMplhHqTfVffUm+syCTfRUe+jfQBJRUe+pN9aAFFG+jfWYBRRvo30AFFG+jfQAUUb6N9ABRvqN3o31oBJvo31Hvo31mXAKKN9R760NeQk30b6j31HvoDkJN9G+q7v89R0ByEjv89R0Ub6ACjfUbvUe+gCR3qu70O9Ru9AEm+o3eo99Rv8ANRAAf5qKKjd60AHeo6Kjd9taGgO+2o3f56Hf56rv81AQB/mqN320O+2o3eg0B3qN3od6ru9BoDvUbvQ71G70ADvUe+o3f56j30Af/9D3BN/92rCI9aiW2xak8n/Zr/Oz3D+mDLT5asI7/wB2tBLbfVhIdi0gMvL/ANypId5X7taiW2+rCW1Zkc5lpvT+GpN7/wB2tRIak8mgyMtPMf8AgqRN9aiW1SfZtlRMftIGem/+7UmX/uVoJD8n3asJD/s1lzmXOZab/wC7RtetTZs/hqXYP7lAc5lIlSJWh9m30fZfegy5ynl/7lGX/uVsQw/LUnk/7NAc5lpv2fdqT560EtqsJbUBzmXl/wC5UeX/ALlbH2X3o8msw5zH3v8A3aky/wDcrU8mpfJjoDnMbL/3Kk+etnyY6ie2oDnKCfcp77/7tXPsvvUnk7KB+4Z6VJsq55O+pEhoMueBn7KK0PJo8mgOcz6K0PJo8mgOcz6K0HhoSGgOcz6K0HhoSGgOcz6K0PJo8mgOcz9lGytDyaPJoDnM/ZUeytR4ajeGgITM96rvv3fdrU+y+9SfZfeg05zDy/8Aco3un8Fbnk/7NR+TQHOYe9/7tSZf+5Wx5NR/ZfegOcx/norY+y+9RvbUBzmO/wA1Rvv/ALtbDw0eTWgc5h1G9bj2e+q72f8AtUBzmPRl/wC5Wo9ts/26PJ/2aDXnMd9/92o3d/7tbDp/s0eTv/ho5w54GHvf+7Ubu/8AdrYe2+ao3tqOcOcw3d9/3aj3v/drYe2o8n/ZrWBpAx3qu+/d92th7be1R/Zv9mrNecw33/3ajff/AHa3Hh/2aj+zf7NAc5h5f+5Vd9+77tdA9tUf2X3qoBA5t9/92jL/ANyuge2qP7L71fuFn//R+rEh/wBmpPJrYSFKPJ31/m+f0h7Yy0tqkS2rUS2qRLagz5zPhh+WpNmz+GtRIdi1YRKOcy5zH8nf/DUkMPy1sJCn92jyaOcOcz/svvUn2X3rQSGpNlHOHOZn2eOp0tquJDVhIazM+cy/JqXyY6v+TUnk0DM9IU/u1J5P+zWgkNHk0GZn+TUiJtrQ8mjyaDHnKfk76PJrQ8mpPJoJM/yaPJrQ8mpPJoAy/s2+h7bZWpsqRId9AGOkNHk/7NbiQ7Kk8n/ZoK5zn/J/2akSH/Zrc8n/AGaXZH/doDnMb7L70fZfetjyd9Hk0BzmO8NHk1sbNn8O+jyd/wDsUC9wy/JqN4a2PJqTyaA9wxNg/uUbB/crb8pP7lHlJ/coEYmwf3Kf5O+tjyk/uUPDQZmG8NL5L/3a2/Jo8pP7lAGJ5L/3aPJf+7W35Sf3KPKT+5Qa+4c/5MlSfZfetx0T+7UbpQHuGG8Oyo/J/wBmug8mjyf9mgfOYaQ1G8Pz1uPDUf2X3oDnMdLbfQ9tWw8Oyo9lBJj+TR5Nank0eT/tUAZfk1G8Pz1seTUbw0AY7w1G8NbHk1H5NBtzmP5NHlJ/crUeGo/JoD3Sh5MdRPDWp5NRvDQa85lvbb6Z9njrX8mo3hoDnMd7aOq723zVuPDUfk0GnOYbps/hqPyd/wDDXQeTUbw1pzhznPvD/s1G9tXQPDVd4aOcOcw3tqrvbfNW48NRvDRzmsJmG9tUf2X3roPJpdg/uUGnOf/S+2PJqRIasVIlf5tn9CFdIasbKkSigzI9lSbKlT7lPoJmRolSbKkSpU+5QYkSQ1J5NWEqRKAK/k0bKsUUGZHsqRIalT7lTpQBX2UbKsUUF8xGkO+pPJqxD92pKJkFfZQkNWKkSs+YCv5NHk1YqVPuUcxUyt5NSJD8lWKkSjmM7sr7KNlWKKOYkr7KEtt9WKsQ/do5gKf2X3qTyauUUcwFPyaPJq5RRzAU/Jo8mrlFHMZlPyaPJq5RRzAU/Jo8mrlFHMbXZT8mjyauUUcwXZT8mjyauUUcxJn/AGX3qN4dlalQTfeo5gKWyjZViijmAr7Kj2VcqN6OYCm8O+jyauUUcxUJGf5NRulaDffqu9HMUV9lRvDVyilACn5NRum2tCoJvvVqaFLZUbw1cqN6DMp+TQ8NXKjb79AFPyajeGrlRvQaFN4aj8mrj0UF8xT2VG6Vcb79V3oFAr7KjeGrlRt9+g2Kfk1G8NXKjeg0Kfk7KNlWHooA/9k=','0.00','active','2025-11-05 03:25:17','2025-11-11 18:25:33');

-- هيكل الجدول `vehicle_inventory`
DROP TABLE IF EXISTS `vehicle_inventory`;
CREATE TABLE `vehicle_inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_updated_by` int(11) DEFAULT NULL,
  `last_updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehicle_product_unique` (`vehicle_id`,`product_id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `vehicle_inventory_ibfk_4` (`last_updated_by`),
  CONSTRAINT `vehicle_inventory_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vehicle_inventory_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vehicle_inventory_ibfk_3` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vehicle_inventory_ibfk_4` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `vehicle_inventory`
-- لا توجد بيانات في الجدول `vehicle_inventory`

-- هيكل الجدول `vehicles`
DROP TABLE IF EXISTS `vehicles`;
CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_number` varchar(50) NOT NULL,
  `vehicle_type` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL COMMENT 'مندوب المبيعات صاحب السيارة',
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehicle_number` (`vehicle_number`),
  KEY `driver_id` (`driver_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vehicles_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `vehicles`
INSERT INTO `vehicles` (`id`, `vehicle_number`, `vehicle_type`, `model`, `year`, `driver_id`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('4','2020 س ط ل','نص نقل','شيفروليه','2025','3','active','','1','2025-11-08 02:45:38',NULL);

-- هيكل الجدول `warehouse_transfer_items`
DROP TABLE IF EXISTS `warehouse_transfer_items`;
CREATE TABLE `warehouse_transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_id` (`batch_id`),
  KEY `batch_number` (`batch_number`),
  CONSTRAINT `warehouse_transfer_items_ibfk_1` FOREIGN KEY (`transfer_id`) REFERENCES `warehouse_transfers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfer_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `warehouse_transfer_items`
-- لا توجد بيانات في الجدول `warehouse_transfer_items`

-- هيكل الجدول `warehouse_transfers`
DROP TABLE IF EXISTS `warehouse_transfers`;
CREATE TABLE `warehouse_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_number` varchar(50) NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `transfer_date` date NOT NULL,
  `transfer_type` enum('to_vehicle','from_vehicle','between_warehouses') DEFAULT 'to_vehicle',
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','completed','cancelled') DEFAULT 'pending',
  `requested_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transfer_number` (`transfer_number`),
  KEY `from_warehouse_id` (`from_warehouse_id`),
  KEY `to_warehouse_id` (`to_warehouse_id`),
  KEY `transfer_date` (`transfer_date`),
  KEY `status` (`status`),
  KEY `requested_by` (`requested_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `warehouse_transfers_ibfk_1` FOREIGN KEY (`from_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_2` FOREIGN KEY (`to_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_3` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `warehouse_transfers`
-- لا توجد بيانات في الجدول `warehouse_transfers`

-- هيكل الجدول `warehouses`
DROP TABLE IF EXISTS `warehouses`;
CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `warehouse_type` enum('main','vehicle') DEFAULT 'main',
  `vehicle_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `warehouse_type` (`warehouse_type`),
  KEY `vehicle_id` (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `warehouses`
INSERT INTO `warehouses` (`id`, `name`, `location`, `description`, `warehouse_type`, `vehicle_id`, `status`, `created_at`, `updated_at`) VALUES
('2','مخزن الشركة الرئيسي',NULL,NULL,'main',NULL,'active','2025-11-05 23:21:30',NULL),
('3','مخزن سيارة 2020 س ط ل','سيارة',NULL,'vehicle','4','active','2025-11-08 02:45:38',NULL);

-- هيكل الجدول `webauthn_credentials`
DROP TABLE IF EXISTS `webauthn_credentials`;
CREATE TABLE `webauthn_credentials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `credential_id` varchar(255) NOT NULL,
  `public_key` text NOT NULL,
  `counter` bigint(20) DEFAULT 0,
  `device_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_used` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_id` (`credential_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `webauthn_credentials_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `webauthn_credentials`
INSERT INTO `webauthn_credentials` (`id`, `user_id`, `credential_id`, `public_key`, `counter`, `device_name`, `created_at`, `last_used`) VALUES
('4','4','Dz0lHGOE2h8Mu2mmbXmpRs/yycs=','pQECAyYgASFYICbgjjt64U8dNfEA2tfMi3esqqMfM3Y1POlfZTwKHcIeIlggl3GjxHovDfhZnvrkvK50U9DjT0rBK+2qxkS3G3itoJc=','8','3','2025-11-06 18:35:34','2025-11-10 06:02:46'),
('6','6','yR2cPlbS+LYRPbVRc6e6fMl55us=','pQECAyYgASFYIMxIkVXhAvA9n5MDesj1kjyPAJgczuE9MfmDIQNAW4ViIlggLal4DBSeEs6NcYmOIu8Ay8zkrvmwMVYFMuelZ6SDn8s=','3','1st','2025-11-06 19:04:52','2025-11-11 20:40:35'),
('10','3','SQJkI1JNcz5S9pP1/3T4sBlIGFc=','pQECAyYgASFYINLPEJDM+nNvNmEm4enyCpmYxkH9o2tDNHOnCOfx0gdPIlggrjh3iL6pymmtkDA9iq+YaWNhmcB0Fs5uAwrLH3eF0cQ=','2','iPhone','2025-11-10 09:10:23','2025-11-10 10:04:26');

COMMIT;
SET FOREIGN_KEY_CHECKS=1;
SET AUTOCOMMIT=1;
