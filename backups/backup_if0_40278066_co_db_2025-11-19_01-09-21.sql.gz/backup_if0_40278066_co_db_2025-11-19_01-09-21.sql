-- نسخة احتياطية لقاعدة البيانات
-- التاريخ: 2025-11-19 01:09:21
-- نوع النسخة: daily
-- قاعدة البيانات: if0_40278066_co_db

SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET AUTOCOMMIT=0;
SET time_zone='+00:00';
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- هيكل الجدول `advance_requests`
DROP TABLE IF EXISTS `advance_requests`;
CREATE TABLE `advance_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `requested_month` int(2) NOT NULL,
  `requested_year` int(4) NOT NULL,
  `salary_id` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `salary_id` (`salary_id`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  KEY `requested_month_year` (`requested_month`,`requested_year`),
  CONSTRAINT `advance_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `advance_requests_ibfk_2` FOREIGN KEY (`salary_id`) REFERENCES `salaries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `advance_requests_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `advance_requests`
-- لا توجد بيانات في الجدول `advance_requests`

-- هيكل الجدول `approvals`
DROP TABLE IF EXISTS `approvals`;
CREATE TABLE `approvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('financial','sales','production','inventory','other') NOT NULL,
  `reference_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `requested_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approval_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`reference_id`),
  KEY `requested_by` (`requested_by`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  CONSTRAINT `approvals_ibfk_1` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `approvals_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `approvals`
-- لا توجد بيانات في الجدول `approvals`

-- هيكل الجدول `attendance`
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `check_in` time DEFAULT NULL,
  `check_out` time DEFAULT NULL,
  `status` enum('present','absent','late','half_day') DEFAULT 'present',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_date` (`user_id`,`date`),
  KEY `date` (`date`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `attendance`
-- لا توجد بيانات في الجدول `attendance`

-- هيكل الجدول `attendance_event_notification_logs`
DROP TABLE IF EXISTS `attendance_event_notification_logs`;
CREATE TABLE `attendance_event_notification_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `attendance_record_id` int(11) DEFAULT NULL,
  `event_type` enum('checkin','checkout') NOT NULL,
  `sent_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_event_date` (`user_id`,`event_type`,`sent_date`),
  KEY `attendance_record_idx` (`attendance_record_id`),
  CONSTRAINT `attendance_event_log_record_fk` FOREIGN KEY (`attendance_record_id`) REFERENCES `attendance_records` (`id`) ON DELETE SET NULL,
  CONSTRAINT `attendance_event_log_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `attendance_event_notification_logs`
INSERT INTO `attendance_event_notification_logs` (`id`, `user_id`, `attendance_record_id`, `event_type`, `sent_date`, `created_at`, `updated_at`) VALUES
('1','4','1','checkin','2025-11-13','2025-11-13 01:25:15',NULL),
('2','4','2','checkin','2025-11-14','2025-11-14 09:20:35',NULL),
('3','4','2','checkout','2025-11-14','2025-11-14 11:15:57',NULL),
('4','3','11','checkin','2025-11-14','2025-11-14 19:28:12','2025-11-14 19:35:48'),
('5','3','10','checkout','2025-11-14','2025-11-14 19:35:39',NULL),
('7','4','12','checkin','2025-11-15','2025-11-15 03:47:53',NULL);

-- هيكل الجدول `attendance_monthly_report_logs`
DROP TABLE IF EXISTS `attendance_monthly_report_logs`;
CREATE TABLE `attendance_monthly_report_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_key` char(7) NOT NULL COMMENT 'YYYY-MM',
  `month_number` tinyint(2) NOT NULL,
  `year_number` smallint(4) NOT NULL,
  `sent_via` varchar(32) NOT NULL COMMENT 'telegram_auto, telegram_manual, manual_export, ...',
  `triggered_by` int(11) DEFAULT NULL COMMENT 'المستخدم الذي أنشأ التقرير يدوياً (إن وجد)',
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `report_snapshot` longtext DEFAULT NULL COMMENT 'نسخة JSON من التقرير',
  PRIMARY KEY (`id`),
  KEY `month_key_idx` (`month_key`),
  KEY `sent_via_idx` (`sent_via`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `attendance_monthly_report_logs`
INSERT INTO `attendance_monthly_report_logs` (`id`, `month_key`, `month_number`, `year_number`, `sent_via`, `triggered_by`, `sent_at`, `report_snapshot`) VALUES
('1','2025-11','11','2025','telegram_manual','1','2025-11-14 14:45:37','{\"month\":11,\"year\":2025,\"month_key\":\"2025-11\",\"generated_at\":\"2025-11-14 14:45:37\",\"total_employees\":1,\"total_hours\":1.9199999999999999289457264239899814128875732421875,\"total_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"average_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"total_salary_amount\":38.39999999999999857891452847979962825775146484375,\"employees\":[{\"user_id\":4,\"name\":\"عامل الإنتاج الأول\",\"role\":\"production\",\"hourly_rate\":20,\"attendance_days\":2,\"delay_days\":1,\"total_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"average_delay_minutes\":10.28999999999999914734871708787977695465087890625,\"total_hours\":1.9199999999999999289457264239899814128875732421875,\"salary_amount\":38.39999999999999857891452847979962825775146484375,\"salary_status\":\"محسوب (غير محفوظ)\"}]}'),
('2','2025-11','11','2025','telegram_manual','1','2025-11-14 14:48:24','{\"month\":11,\"year\":2025,\"month_key\":\"2025-11\",\"generated_at\":\"2025-11-14 14:48:24\",\"total_employees\":1,\"total_hours\":1.9199999999999999289457264239899814128875732421875,\"total_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"average_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"total_salary_amount\":38.39999999999999857891452847979962825775146484375,\"employees\":[{\"user_id\":4,\"name\":\"عامل الإنتاج الأول\",\"role\":\"production\",\"hourly_rate\":20,\"attendance_days\":2,\"delay_days\":1,\"total_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"average_delay_minutes\":10.28999999999999914734871708787977695465087890625,\"total_hours\":1.9199999999999999289457264239899814128875732421875,\"salary_amount\":38.39999999999999857891452847979962825775146484375,\"salary_status\":\"محسوب (غير محفوظ)\"}]}'),
('3','2025-11','11','2025','telegram_manual','1','2025-11-14 14:48:28','{\"month\":11,\"year\":2025,\"month_key\":\"2025-11\",\"generated_at\":\"2025-11-14 14:48:27\",\"total_employees\":1,\"total_hours\":1.9199999999999999289457264239899814128875732421875,\"total_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"average_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"total_salary_amount\":38.39999999999999857891452847979962825775146484375,\"employees\":[{\"user_id\":4,\"name\":\"عامل الإنتاج الأول\",\"role\":\"production\",\"hourly_rate\":20,\"attendance_days\":2,\"delay_days\":1,\"total_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"average_delay_minutes\":10.28999999999999914734871708787977695465087890625,\"total_hours\":1.9199999999999999289457264239899814128875732421875,\"salary_amount\":38.39999999999999857891452847979962825775146484375,\"salary_status\":\"محسوب (غير محفوظ)\"}]}'),
('4','2025-11','11','2025','telegram_manual','1','2025-11-17 04:26:14','{\"month\":11,\"year\":2025,\"month_key\":\"2025-11\",\"generated_at\":\"2025-11-17 04:26:14\",\"total_employees\":2,\"total_hours\":9.949999999999999289457264239899814128875732421875,\"total_delay_minutes\":648.7800000000000864019966684281826019287109375,\"average_delay_minutes\":324.3899999999999863575794734060764312744140625,\"total_salary_amount\":197.5,\"employees\":[{\"user_id\":4,\"name\":\"عامل الإنتاج الأول\",\"role\":\"production\",\"hourly_rate\":20,\"attendance_days\":3,\"delay_days\":1,\"total_delay_minutes\":20.5799999999999982946974341757595539093017578125,\"average_delay_minutes\":6.86000000000000031974423109204508364200592041015625,\"total_hours\":9.8300000000000000710542735760100185871124267578125,\"salary_amount\":196.599999999999994315658113919198513031005859375,\"salary_status\":\"محسوب (غير محفوظ)\"},{\"user_id\":3,\"name\":\"مندوب اسامه\",\"role\":\"sales\",\"hourly_rate\":15,\"attendance_days\":1,\"delay_days\":1,\"total_delay_minutes\":628.200000000000045474735088646411895751953125,\"average_delay_minutes\":628.200000000000045474735088646411895751953125,\"total_hours\":0.11999999999999999555910790149937383830547332763671875,\"salary_amount\":0.90000000000000002220446049250313080847263336181640625,\"salary_status\":\"pending\"}]}');

-- هيكل الجدول `attendance_notification_logs`
DROP TABLE IF EXISTS `attendance_notification_logs`;
CREATE TABLE `attendance_notification_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `notification_kind` enum('checkin','checkout') NOT NULL,
  `sent_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_kind_date` (`user_id`,`notification_kind`,`sent_date`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `attendance_notification_logs`
INSERT INTO `attendance_notification_logs` (`id`, `user_id`, `notification_kind`, `sent_date`, `created_at`) VALUES
('1','3','checkin','2025-11-13','2025-11-13 08:59:24'),
('2','4','checkin','2025-11-14','2025-11-14 09:17:02'),
('3','4','checkout','2025-11-14','2025-11-14 19:01:52'),
('4','3','checkin','2025-11-14','2025-11-14 19:27:27'),
('5','2','checkin','2025-11-14','2025-11-14 19:44:20'),
('6','3','checkin','2025-11-15','2025-11-15 18:17:07'),
('7','3','checkin','2025-11-17','2025-11-17 08:50:12'),
('8','3','checkin','2025-11-18','2025-11-18 10:47:20'),
('9','4','checkin','2025-11-18','2025-11-18 12:06:35');

-- هيكل الجدول `attendance_records`
DROP TABLE IF EXISTS `attendance_records`;
CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `check_in_time` datetime NOT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `delay_minutes` int(11) DEFAULT 0,
  `work_hours` decimal(5,2) DEFAULT 0.00,
  `photo_path` varchar(255) DEFAULT NULL,
  `checkout_photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `date` (`date`),
  KEY `user_date` (`user_id`,`date`),
  KEY `check_in_time` (`check_in_time`),
  CONSTRAINT `attendance_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `attendance_records`
INSERT INTO `attendance_records` (`id`, `user_id`, `date`, `check_in_time`, `check_out_time`, `delay_minutes`, `work_hours`, `photo_path`, `checkout_photo_path`, `created_at`, `updated_at`) VALUES
('1','4','2025-11-13','2025-11-13 01:25:15',NULL,'0','0.00','deleted_after_send',NULL,'2025-11-13 01:25:15','2025-11-13 01:25:15'),
('2','4','2025-11-14','2025-11-14 09:20:35','2025-11-14 11:15:57','21','1.92','deleted_after_send','deleted_after_send','2025-11-14 09:20:35','2025-11-14 11:15:57'),
('3','4','2025-11-14','2025-11-14 11:16:16','2025-11-14 19:02:55','136','7.78','attendance/2025-11/checkin_4_20251114_111616_d257ace9.jpg','attendance/2025-11/checkout_4_20251114_190255_9f66152c.jpg','2025-11-14 11:16:16','2025-11-14 19:02:55'),
('4','4','2025-11-14','2025-11-14 19:03:40','2025-11-14 19:03:53','604','0.00','attendance/2025-11/checkin_4_20251114_190340_d1d2e9cb.jpg','attendance/2025-11/checkout_4_20251114_190353_6a78ffef.jpg','2025-11-14 19:03:39','2025-11-14 19:03:53'),
('5','4','2025-11-14','2025-11-14 19:06:54','2025-11-14 19:10:54','607','0.07','attendance/2025-11/checkin_4_20251114_190654_693766f3.jpg','attendance/2025-11/checkout_4_20251114_191054_9f381fcc.jpg','2025-11-14 19:06:53','2025-11-14 19:10:54'),
('6','4','2025-11-14','2025-11-14 19:18:16','2025-11-14 19:18:50','618','0.01','attendance/2025-11/checkin_4_20251114_191816_ab823455.jpg','attendance/2025-11/checkout_4_20251114_191850_7c49425f.jpg','2025-11-14 19:18:17','2025-11-14 19:18:50'),
('7','4','2025-11-14','2025-11-14 19:19:09','2025-11-14 19:19:18','619','0.00','attendance/2025-11/checkin_4_20251114_191909_585c4d26.jpg','attendance/2025-11/checkout_4_20251114_191918_8b69246a.jpg','2025-11-14 19:19:09','2025-11-14 19:19:18'),
('8','4','2025-11-14','2025-11-14 19:19:30','2025-11-14 19:19:39','620','0.00','attendance/2025-11/checkin_4_20251114_191930_4b1b99e3.jpg','attendance/2025-11/checkout_4_20251114_191939_9aafb700.jpg','2025-11-14 19:19:30','2025-11-14 19:19:39'),
('9','4','2025-11-14','2025-11-14 19:23:28','2025-11-14 19:26:11','623','0.05','attendance/2025-11/checkin_4_20251114_192328_9626c7b6.jpg','attendance/2025-11/checkout_4_20251114_192611_66302020.jpg','2025-11-14 19:23:28','2025-11-14 19:26:11'),
('10','3','2025-11-14','2025-11-14 19:28:12','2025-11-14 19:35:39','628','0.12','deleted_after_send','deleted_after_send','2025-11-14 19:28:12','2025-11-14 19:35:39'),
('11','3','2025-11-14','2025-11-14 19:35:48',NULL,'636','0.00','deleted_after_send',NULL,'2025-11-14 19:35:48','2025-11-14 19:35:48'),
('12','4','2025-11-15','2025-11-15 03:47:53',NULL,'0','0.00','deleted_after_send',NULL,'2025-11-15 03:47:53','2025-11-15 03:47:53');

-- هيكل الجدول `audit_logs`
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `old_data` text DEFAULT NULL,
  `new_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `entity_type` (`entity_type`,`entity_id`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `audit_logs`
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `old_value`, `new_value`, `old_data`, `new_data`, `ip_address`, `user_agent`, `created_at`) VALUES
('1','3','logout','user','3',NULL,NULL,NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 04:05:56'),
('2','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 04:06:02'),
('3','3','login','user','3',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'62.139.47.144','Mozilla/5.0 (iPhone; CPU iPhone OS 26_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.148 Mobile/15E148 Safari/604.1','2025-11-16 04:07:57'),
('5','1','logout','user','1',NULL,NULL,NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 05:00:12'),
('6','3','login','user','3',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 05:00:15'),
('7','3','logout','user','3',NULL,NULL,NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 05:00:36'),
('8','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 05:00:39'),
('9','1','inventory_movement','product','13','{\"quantity_before\":1}','{\"quantity_after\":0,\"type\":\"out\"}',NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 06:07:56'),
('10','1','execute_transfer_directly','warehouse_transfer','22','{\"old_status\":\"approved\"}','{\"new_status\":\"completed\"}',NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 06:07:56'),
('11','1','create_transfer','warehouse_transfer','22',NULL,'{\"transfer_number\":\"TRF-202511-0006\",\"transfer_type\":\"to_vehicle\"}',NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 06:07:56'),
('12','1','logout','user','1',NULL,NULL,NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 06:08:12'),
('13','3','login','user','3',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'62.139.47.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-16 06:08:16'),
('14','4','login','user','4',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:20:29'),
('15','4','create_transfer','warehouse_transfer','23',NULL,'{\"transfer_number\":\"TRF-202511-0007\",\"transfer_type\":\"to_vehicle\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:23:10'),
('16','3','logout','user','3',NULL,NULL,NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:23:23'),
('17','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:23:27'),
('18','1','inventory_movement','product','7','{\"quantity_before\":1}','{\"quantity_after\":0,\"type\":\"out\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:40:23'),
('19','1','approve_transfer','warehouse_transfer','23','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:40:23'),
('20','4','logout','user','4',NULL,NULL,NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:46:47'),
('21','3','login','user','3',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:46:51'),
('22','3','add_customer','customer','4',NULL,'{\"name\":\"\\u0627\\u062d\\u0645\\u062f\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 04:47:46'),
('31','1','update_customer_location','customer','4',NULL,'{\"latitude\":30.015488000000001278522177017293870449066162109375,\"longitude\":31.178751999999999355850377469323575496673583984375}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:14:51'),
('32','1','update_customer_location','customer','4',NULL,'{\"latitude\":30.015488000000001278522177017293870449066162109375,\"longitude\":31.178751999999999355850377469323575496673583984375}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:15:20'),
('33','6','login','user','6',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (iPhone; CPU iPhone OS 26_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.148 Mobile/15E148 Safari/604.1','2025-11-17 06:15:41'),
('34','6','login','user','6',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Mobile/15E148 Safari/604.1','2025-11-17 06:18:48'),
('35','6','update_customer_location','customer','1',NULL,'{\"latitude\":31.09891280000000080008248914964497089385986328125,\"longitude\":29.7728626600000012558666639961302280426025390625}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Mobile/15E148 Safari/604.1','2025-11-17 06:21:32'),
('36','6','update_customer_location','customer','4',NULL,'{\"latitude\":31.098971829999999982874214765615761280059814453125,\"longitude\":29.77282598000000035654011298902332782745361328125}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Mobile/15E148 Safari/604.1','2025-11-17 06:21:50'),
('37','3','create_invoice','invoice','10',NULL,'{\"invoice_number\":\"INV-202511-0001\",\"total_amount\":500}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:37:09'),
('38','3','inventory_movement','product','17','{\"quantity_before\":1}','{\"quantity_after\":0,\"type\":\"out\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:37:09'),
('39','3','create_pos_sale_multi','invoice','10',NULL,'{\"invoice_number\":\"INV-202511-0001\",\"items\":[{\"product_id\":17,\"name\":\"\\u063a\\u0630\\u0627\",\"category\":\"finished\",\"quantity\":1,\"available\":1,\"unit_price\":500,\"line_total\":500}],\"net_total\":500,\"paid_amount\":500,\"base_due_amount\":0,\"credit_used\":0,\"due_amount\":0,\"customer_id\":4}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:37:09'),
('40','1','logout','user','1',NULL,NULL,NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:44:14'),
('41','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:44:24'),
('42','2','logout','user','2',NULL,NULL,NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:48:06'),
('43','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 06:48:12'),
('44','3','create_invoice','invoice','11',NULL,'{\"invoice_number\":\"INV-202511-0002\",\"total_amount\":200}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 07:28:34'),
('45','3','inventory_movement','product','19','{\"quantity_before\":1}','{\"quantity_after\":0,\"type\":\"out\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 07:28:34'),
('46','3','create_pos_sale_multi','invoice','11',NULL,'{\"invoice_number\":\"INV-202511-0002\",\"items\":[{\"product_id\":19,\"name\":\"\\u0632\\u064a\\u062a \\u0632\\u064a\\u062a\\u0648\\u0646 \\u0643\\u064a\\u0644\\u0648\",\"category\":\"finished\",\"quantity\":1,\"available\":1,\"unit_price\":200,\"line_total\":200}],\"net_total\":200,\"paid_amount\":100,\"base_due_amount\":100,\"credit_used\":0,\"due_amount\":100,\"customer_id\":4}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 07:28:34'),
('47','1','logout','user','1',NULL,NULL,NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 07:48:17'),
('48','2','login','user','2',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 07:48:23'),
('49','3','create_payment_schedule_manual','payment_schedule','1',NULL,'{\"customer_id\":4,\"amount\":100,\"due_date\":\"2025-11-18\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 07:57:15'),
('50','3','update_payment_schedule','payment_schedule','1','{\"amount\":\"100.00\",\"due_date\":\"2025-11-18\",\"status\":\"pending\"}','{\"amount\":100,\"due_date\":\"2025-11-19\",\"status\":\"pending\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:01:32'),
('51','3','collect_customer_debt','customer','4',NULL,'{\"collected_amount\":50,\"previous_balance\":100,\"new_balance\":50}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:02:22'),
('52','3','update_payment_schedule','payment_schedule','1','{\"amount\":\"100.00\",\"due_date\":\"2025-11-19\",\"status\":\"pending\"}','{\"amount\":50,\"due_date\":\"2025-11-19\",\"status\":\"pending\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:02:43'),
('53','3','create_payment_schedule_manual','payment_schedule','2',NULL,'{\"customer_id\":4,\"amount\":50,\"due_date\":\"2025-11-20\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:15:31'),
('54','3','create_payment_schedule_manual','payment_schedule','3',NULL,'{\"customer_id\":4,\"amount\":50,\"due_date\":\"2025-11-20\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:15:35'),
('55','2','logout','user','2',NULL,NULL,NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:52:00'),
('56','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:52:04'),
('57','1','create_external_product','product','24',NULL,'{\"name\":\"\\u0635\\u0627\\u0628\\u0648\\u0646 \\u0648\\u0633\\u0637\",\"quantity\":10,\"unit_price\":10}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:55:05'),
('58','1','create_external_product','product','25',NULL,'{\"name\":\"\\u0635\\u0627\\u0628\\u0648\\u0646 \\u0648\\u0633\\u0637\",\"quantity\":10,\"unit_price\":10}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:55:17'),
('59','1','update_external_product','product','24',NULL,'{\"name\":\"\\u0635\\u0627\\u0628\\u0648\\u0646 \\u0643\\u0628\\u064a\\u0631\",\"quantity\":10,\"unit_price\":10}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:55:44'),
('60','1','update_external_product','product','24',NULL,'{\"name\":\"\\u0635\\u0627\\u0628\\u0648\\u0646 \\u0643\\u0628\\u064a\\u0631\",\"quantity\":10,\"unit_price\":20}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 08:55:54'),
('61','1','inventory_movement','product','24','{\"quantity_before\":10}','{\"quantity_after\":5,\"type\":\"out\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 09:01:58'),
('62','1','execute_transfer_directly','warehouse_transfer','26','{\"old_status\":\"approved\"}','{\"new_status\":\"completed\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 09:01:58'),
('63','1','create_transfer','warehouse_transfer','26',NULL,'{\"transfer_number\":\"TRF-202511-0010\",\"transfer_type\":\"to_vehicle\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 09:01:58'),
('64','3','create_transfer','warehouse_transfer','28',NULL,'{\"transfer_number\":\"TRF-202511-0012\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 09:36:40'),
('65','3','create_transfer','warehouse_transfer','29',NULL,'{\"transfer_number\":\"TRF-202511-0013\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 09:47:28'),
('66','3','create_transfer','warehouse_transfer','30',NULL,'{\"transfer_number\":\"TRF-202511-0014\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:32:23'),
('67','3','create_transfer','warehouse_transfer','31',NULL,'{\"transfer_number\":\"TRF-202511-0015\",\"transfer_type\":\"to_vehicle\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:47:10'),
('68','1','inventory_movement','product','24','{\"quantity_before\":5}','{\"quantity_after\":4,\"type\":\"out\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:47:36'),
('69','1','approve_transfer','warehouse_transfer','31','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:47:36'),
('70','3','create_transfer','warehouse_transfer','32',NULL,'{\"transfer_number\":\"TRF-202511-0016\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:48:22'),
('71','1','inventory_movement','product','24','{\"quantity_before\":6}','{\"quantity_after\":5,\"type\":\"out\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:48:41'),
('72','1','inventory_movement','product','24','{\"quantity_before\":5}','{\"quantity_after\":6,\"type\":\"in\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:48:41'),
('73','1','approve_transfer','warehouse_transfer','32','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:48:41'),
('74','3','create_transfer','warehouse_transfer','33',NULL,'{\"transfer_number\":\"TRF-202511-0017\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:49:41'),
('75','1','inventory_movement','product','24','{\"quantity_before\":5}','{\"quantity_after\":4,\"type\":\"out\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:49:49'),
('76','1','inventory_movement','product','24','{\"quantity_before\":7}','{\"quantity_after\":8,\"type\":\"in\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:49:49'),
('77','1','approve_transfer','warehouse_transfer','33','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-17 10:49:49'),
('78','1','login','user','1',NULL,'{\"method\":\"webauthn\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (iPhone; CPU iPhone OS 26_1_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/142.0.7444.148 Mobile/15E148 Safari/604.1','2025-11-17 11:04:28'),
('79','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'154.238.231.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0','2025-11-17 18:34:50'),
('80','3','login','user','3',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 10:47:20'),
('81','3','collect_customer_debt','customer','4',NULL,'{\"collected_amount\":10,\"previous_balance\":50,\"new_balance\":40}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 10:48:27'),
('82','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 10:49:54'),
('83','1','cleanup_login_attempts','login_attempts',NULL,NULL,'{\"deleted_count\":10,\"days\":1}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 10:50:16'),
('84','1','delete_all_login_attempts','login_attempts',NULL,NULL,'{\"deleted_count\":4}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 10:50:25'),
('87','3','collect_customer_debt','customer','4',NULL,'{\"collected_amount\":10,\"previous_balance\":40,\"new_balance\":30}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 11:08:49'),
('88','3','add_collection_from_customers_page','collection','1',NULL,'{\"collection_number\":\"COL-202511-0001\",\"customer_id\":4,\"amount\":10}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 11:08:49'),
('89','3','invoice_payment_from_collection','invoice','11','{\"old_paid\":\"100.00\",\"old_status\":\"partial\"}','{\"new_paid\":110,\"new_status\":\"partial\",\"payment\":10}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 11:08:49'),
('90','3','create_transfer','warehouse_transfer','36',NULL,'{\"transfer_number\":\"TRF-202511-0019\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 11:11:39'),
('91','3','create_transfer','warehouse_transfer','37',NULL,'{\"transfer_number\":\"TRF-202511-0020\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 11:40:08'),
('92','1','inventory_movement','product','22','{\"quantity_before\":1}','{\"quantity_after\":0,\"type\":\"out\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 11:40:14'),
('93','1','inventory_movement','product','22','{\"quantity_before\":1}','{\"quantity_after\":2,\"type\":\"in\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 11:40:14'),
('94','1','approve_transfer','warehouse_transfer','37','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 11:40:14'),
('95','1','logout','user','1',NULL,NULL,NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 12:06:31'),
('96','4','login','user','4',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 12:06:35'),
('97','4','logout','user','4',NULL,NULL,NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 12:13:42'),
('98','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 12:13:51'),
('99','3','collect_customer_debt','customer','4',NULL,'{\"collected_amount\":10,\"previous_balance\":30,\"new_balance\":20}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 13:06:00'),
('100','3','add_collection_from_customers_page','collection','2',NULL,'{\"collection_number\":\"COL-202511-0002\",\"customer_id\":4,\"amount\":10}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 13:06:00'),
('101','3','invoice_payment_from_collection','invoice','11','{\"old_paid\":\"110.00\",\"old_status\":\"partial\"}','{\"new_paid\":120,\"new_status\":\"partial\",\"payment\":10}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 13:06:00'),
('102','3','create_transfer','warehouse_transfer','38',NULL,'{\"transfer_number\":\"TRF-202511-0021\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 13:06:49'),
('103','1','inventory_movement','product','13','{\"quantity_before\":1}','{\"quantity_after\":0,\"type\":\"out\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 13:07:21'),
('104','1','inventory_movement','product','13','{\"quantity_before\":1}','{\"quantity_after\":2,\"type\":\"in\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 13:07:21'),
('105','1','approve_transfer','warehouse_transfer','38','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 13:07:21'),
('106','1','logout','user','1',NULL,NULL,NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:04:06'),
('107','4','login','user','4',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:04:11'),
('108','3','create_transfer','warehouse_transfer','39',NULL,'{\"transfer_number\":\"TRF-202511-0022\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:14:51'),
('109','4','logout','user','4',NULL,NULL,NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:18:00'),
('110','1','login','user','1',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:18:04'),
('111','1','inventory_movement','product','24','{\"quantity_before\":4}','{\"quantity_after\":3,\"type\":\"out\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:19:12'),
('112','1','inventory_movement','product','24','{\"quantity_before\":9}','{\"quantity_after\":10,\"type\":\"in\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:19:12'),
('113','1','approve_transfer','warehouse_transfer','39','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:19:12'),
('114','3','create_transfer','warehouse_transfer','40',NULL,'{\"transfer_number\":\"TRF-202511-0023\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:28:43'),
('115','1','inventory_movement','product','24','{\"quantity_before\":3}','{\"quantity_after\":2,\"type\":\"out\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:28:57'),
('116','1','inventory_movement','product','24','{\"quantity_before\":10}','{\"quantity_after\":11,\"type\":\"in\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:28:57'),
('117','1','approve_transfer','warehouse_transfer','40','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 14:28:57'),
('118','3','logout','user','3',NULL,NULL,NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:13:28'),
('119','4','login','user','4',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:13:31'),
('120','4','logout','user','4',NULL,NULL,NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:15:16'),
('121','3','login','user','3',NULL,'{\"method\":\"password\",\"remember_me\":\"no\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:15:22'),
('122','1','inventory_movement','product','24','{\"quantity_before\":11}','{\"quantity_after\":8,\"type\":\"out\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:34:26'),
('123','1','execute_transfer_directly','warehouse_transfer','41','{\"old_status\":\"approved\"}','{\"new_status\":\"completed\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:34:26'),
('124','1','create_transfer','warehouse_transfer','41',NULL,'{\"transfer_number\":\"TRF-202511-0024\",\"transfer_type\":\"to_vehicle\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:34:26'),
('125','1','inventory_movement','product','24','{\"quantity_before\":5}','{\"quantity_after\":3,\"type\":\"out\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:34:55'),
('126','1','inventory_movement','product','24','{\"quantity_before\":10}','{\"quantity_after\":12,\"type\":\"in\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:34:55'),
('127','1','execute_transfer_directly','warehouse_transfer','42','{\"old_status\":\"approved\"}','{\"new_status\":\"completed\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:34:55'),
('128','1','create_transfer','warehouse_transfer','42',NULL,'{\"transfer_number\":\"TRF-202511-0025\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:34:55'),
('129','3','create_transfer','warehouse_transfer','43',NULL,'{\"transfer_number\":\"TRF-202511-0026\",\"transfer_type\":\"from_vehicle\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:05'),
('130','1','inventory_movement','product','24','{\"quantity_before\":3}','{\"quantity_after\":1,\"type\":\"out\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:19'),
('131','1','inventory_movement','product','24','{\"quantity_before\":12}','{\"quantity_after\":14,\"type\":\"in\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:19'),
('132','1','inventory_movement','product','7','{\"quantity_before\":1}','{\"quantity_after\":0,\"type\":\"out\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:19'),
('133','1','inventory_movement','product','7','{\"quantity_before\":0}','{\"quantity_after\":1,\"type\":\"in\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:19'),
('134','1','approve_transfer','warehouse_transfer','43','{\"old_status\":\"pending\"}','{\"new_status\":\"approved\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:19'),
('135','1','inventory_movement','product','24','{\"quantity_before\":14}','{\"quantity_after\":4,\"type\":\"out\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:22'),
('136','1','execute_transfer_directly','warehouse_transfer','44','{\"old_status\":\"approved\"}','{\"new_status\":\"completed\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:22'),
('137','1','create_transfer','warehouse_transfer','44',NULL,'{\"transfer_number\":\"TRF-202511-0027\",\"transfer_type\":\"to_vehicle\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:22'),
('138','3','mark_payment_schedule_paid','payment_schedule','2','{\"status\":\"pending\",\"payment_date\":null}','{\"status\":\"paid\",\"payment_date\":\"2025-11-18\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:08:38'),
('139','3','add_customer','customer','8',NULL,'{\"name\":\"\\u0645\\u0627\\u064a\\u0643\\u0644\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:58:59'),
('140','3','add_customer','customer','9',NULL,'{\"name\":\"\\u0639\\u0645\\u0631\\u0648\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:04:42'),
('141','3','add_customer','customer','10',NULL,'{\"name\":\"\\u062e\\u0627\\u0644\\u062f\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:20:31'),
('142','3','create_invoice','invoice','12',NULL,'{\"invoice_number\":\"INV-202511-0003\",\"total_amount\":200}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:23:00'),
('143','3','inventory_movement','product','24','{\"quantity_before\":11}','{\"quantity_after\":1,\"type\":\"out\"}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:23:00'),
('144','3','create_pos_sale_multi','invoice','12',NULL,'{\"invoice_number\":\"INV-202511-0003\",\"items\":[{\"product_id\":24,\"name\":\"\\u0635\\u0627\\u0628\\u0648\\u0646 \\u0643\\u0628\\u064a\\u0631\",\"category\":\"\\u0645\\u0646\\u062a\\u062c\\u0627\\u062a \\u062e\\u0627\\u0631\\u062c\\u064a\\u0629\",\"quantity\":10,\"available\":11,\"unit_price\":20,\"line_total\":200}],\"net_total\":200,\"paid_amount\":20,\"base_due_amount\":180,\"credit_used\":0,\"due_amount\":180,\"customer_id\":10}',NULL,NULL,'41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:23:00');

-- هيكل الجدول `backups`
DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `backup_type` enum('full','incremental','manual') DEFAULT 'full',
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  CONSTRAINT `backups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `backups`
INSERT INTO `backups` (`id`, `filename`, `file_path`, `file_size`, `backup_type`, `status`, `created_by`, `created_at`) VALUES
('1','backup_if0_40278066_co_db_2025-11-14_18-42-53.sql.gz','/home/vol15_8/infinityfree.com/if0_40239608/htdocs/v1/backups/backup_if0_40278066_co_db_2025-11-14_18-42-53.sql.gz','58118','manual','completed','1','2025-11-14 18:42:53'),
('2','backup_if0_40278066_co_db_2025-11-15_02-14-51.sql.gz','/home/vol15_8/infinityfree.com/if0_40239608/htdocs/v1/backups/backup_if0_40278066_co_db_2025-11-15_02-14-51.sql.gz','60773','','completed',NULL,'2025-11-15 02:14:51'),
('3','backup_if0_40278066_co_db_2025-11-16_01-29-35.sql.gz','/home/vol15_8/infinityfree.com/if0_40239608/htdocs/v1/backups/backup_if0_40278066_co_db_2025-11-16_01-29-35.sql.gz','61997','','completed',NULL,'2025-11-16 01:29:35'),
('4','backup_if0_40278066_co_db_2025-11-17_04-20-23.sql.gz','/home/vol15_8/infinityfree.com/if0_40239608/htdocs/v1/backups/backup_if0_40278066_co_db_2025-11-17_04-20-23.sql.gz','62021','','completed',NULL,'2025-11-17 04:20:23'),
('5','backup_if0_40278066_co_db_2025-11-18_00-25-43.sql.gz','/home/vol15_8/infinityfree.com/if0_40239608/htdocs/v1/backups/backup_if0_40278066_co_db_2025-11-18_00-25-43.sql.gz','66778','','completed',NULL,'2025-11-18 00:25:43');

-- هيكل الجدول `barcode_scans`
DROP TABLE IF EXISTS `barcode_scans`;
CREATE TABLE `barcode_scans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_number_id` int(11) NOT NULL,
  `scanned_by` int(11) DEFAULT NULL,
  `scan_location` varchar(255) DEFAULT NULL,
  `scan_type` enum('in','out','verification','sale','return') DEFAULT 'verification',
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_number_id` (`batch_number_id`),
  KEY `scanned_by` (`scanned_by`),
  KEY `scan_type` (`scan_type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `barcode_scans_ibfk_1` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `barcode_scans_ibfk_2` FOREIGN KEY (`scanned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `barcode_scans`
-- لا توجد بيانات في الجدول `barcode_scans`

-- هيكل الجدول `batch_numbers`
DROP TABLE IF EXISTS `batch_numbers`;
CREATE TABLE `batch_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `production_id` int(11) DEFAULT NULL,
  `production_date` date NOT NULL,
  `honey_supplier_id` int(11) DEFAULT NULL,
  `honey_variety` varchar(50) DEFAULT NULL COMMENT 'نوع العسل المستخدم',
  `packaging_materials` text DEFAULT NULL COMMENT 'JSON array of packaging material IDs',
  `packaging_supplier_id` int(11) DEFAULT NULL,
  `all_suppliers` text DEFAULT NULL COMMENT 'JSON array of all suppliers with their materials',
  `workers` text DEFAULT NULL COMMENT 'JSON array of worker IDs',
  `quantity` int(11) NOT NULL DEFAULT 1,
  `status` enum('in_production','completed','in_stock','sold','expired') DEFAULT 'in_production',
  `expiry_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_number` (`batch_number`),
  KEY `product_id` (`product_id`),
  KEY `production_id` (`production_id`),
  KEY `production_date` (`production_date`),
  KEY `honey_supplier_id` (`honey_supplier_id`),
  KEY `packaging_supplier_id` (`packaging_supplier_id`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `batch_numbers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `batch_numbers_ibfk_2` FOREIGN KEY (`production_id`) REFERENCES `production` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_3` FOREIGN KEY (`honey_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_4` FOREIGN KEY (`packaging_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_numbers`
INSERT INTO `batch_numbers` (`id`, `batch_number`, `product_id`, `production_id`, `production_date`, `honey_supplier_id`, `honey_variety`, `packaging_materials`, `packaging_supplier_id`, `all_suppliers`, `workers`, `quantity`, `status`, `expiry_date`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1','251115-936155','6','2','2025-11-15','2','سدر','[38]','4','[{\"id\":4,\"name\":\"تعبئه\",\"type\":\"packaging\",\"material\":\"ملصق صغير\"},{\"id\":2,\"name\":\"عمرو\",\"type\":\"honey\",\"material\":\"عسل - سدر\",\"honey_variety\":\"سدر\"}]','[4]','1','completed','2026-11-15','تم إنشاؤه من قالب:  | الموردون: تعبئه (ملصق صغير), عمرو (عسل - سدر)','4','2025-11-15 05:58:14',NULL),
('2','251115-238486','7','3','2025-11-15','2','سدر','[38]','4','[{\"id\":4,\"name\":\"تعبئه\",\"type\":\"packaging\",\"material\":\"ملصق صغير\"},{\"id\":2,\"name\":\"عمرو\",\"type\":\"honey\",\"material\":\"عسل - سدر\",\"honey_variety\":\"سدر\"}]','[4]','1','completed','2026-11-15','تم إنشاؤه من قالب:  | الموردون: تعبئه (ملصق صغير), عمرو (عسل - سدر)','4','2025-11-15 05:58:32',NULL),
('3','251115-058200','13','5','2025-11-15','3','حبة البركة','[38]','4','[{\"id\":4,\"name\":\"تعبئه\",\"type\":\"packaging\",\"material\":\"ملصق صغير\"},{\"id\":8,\"name\":\"شمع\",\"type\":\"beeswax\",\"material\":\"شمع\",\"honey_variety\":null},{\"id\":3,\"name\":\"مايكل\",\"type\":\"honey\",\"material\":\"عسل - حبة البركة\",\"honey_variety\":\"حبة البركة\"}]','[4]','1','completed','2026-11-15','تم إنشاؤه من قالب:  | الموردون: تعبئه (ملصق صغير), شمع (شمع), مايكل (عسل - حبة البركة)','4','2025-11-15 06:27:38',NULL),
('4','251115-185290','17','6','2025-11-15',NULL,NULL,'[40]','4','[{\"id\":4,\"name\":\"تعبئه\",\"type\":\"packaging\",\"material\":\"ملصق كبير\"},{\"id\":7,\"name\":\"مشتقات\",\"type\":\"derivatives\",\"material\":\"مشتقات - غذاء ملكات\",\"honey_variety\":null}]','[4]','1','completed','2026-11-15','تم إنشاؤه من قالب:  | الموردون: تعبئه (ملصق كبير), مشتقات (مشتقات - غذاء ملكات)','4','2025-11-15 07:44:33',NULL),
('5','251115-765452','19','7','2025-11-15',NULL,NULL,'[40]','4','[{\"id\":4,\"name\":\"تعبئه\",\"type\":\"packaging\",\"material\":\"ملصق كبير\"},{\"id\":6,\"name\":\"زيت زيتون\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]','[4]','1','completed','2026-11-15','تم إنشاؤه من قالب:  | الموردون: تعبئه (ملصق كبير), زيت زيتون (زيت زيتون)','4','2025-11-15 07:44:53',NULL),
('6','251115-102778','22','8','2025-11-15','3','حبة البركة','[39]','4','[{\"id\":4,\"name\":\"تعبئه\",\"type\":\"packaging\",\"material\":\"ملصق وسط\"},{\"id\":3,\"name\":\"مايكل\",\"type\":\"honey\",\"material\":\"عسل - حبة البركة\",\"honey_variety\":\"حبة البركة\"},{\"id\":5,\"name\":\"مكسرات\",\"type\":\"nuts\",\"material\":\"مكسرات - تشكيله 2\",\"honey_variety\":null}]','[4]','1','completed','2026-11-15','تم إنشاؤه من قالب:  | الموردون: تعبئه (ملصق وسط), مايكل (عسل - حبة البركة), مكسرات (مكسرات - تشكيله 2)','4','2025-11-15 09:26:08',NULL);

-- هيكل الجدول `batch_packaging`
DROP TABLE IF EXISTS `batch_packaging`;
CREATE TABLE `batch_packaging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `packaging_material_id` int(11) DEFAULT NULL,
  `packaging_name` varchar(255) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `quantity_used` decimal(12,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `packaging_material_id` (`packaging_material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_packaging`
INSERT INTO `batch_packaging` (`id`, `batch_id`, `packaging_material_id`, `packaging_name`, `unit`, `supplier_id`, `quantity_used`, `created_at`) VALUES
('1','4','17','أغطية - غطاء 43م','قطعة','4','1.000','2025-11-13 08:19:27'),
('2','1','38','ملصق صغير','قطعة','4','1.000','2025-11-15 05:58:14'),
('3','2','38','ملصق صغير','قطعة','4','1.000','2025-11-15 05:58:32'),
('4','3','38','ملصق صغير','قطعة','4','1.000','2025-11-15 06:27:38'),
('5','4','40','ملصق كبير','قطعة','4','1.000','2025-11-15 07:44:33'),
('6','5','40','ملصق كبير','قطعة','4','1.000','2025-11-15 07:44:53'),
('7','6','39','ملصق وسط','قطعة','4','1.000','2025-11-15 09:26:08');

-- هيكل الجدول `batch_raw_materials`
DROP TABLE IF EXISTS `batch_raw_materials`;
CREATE TABLE `batch_raw_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `raw_material_id` int(11) DEFAULT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `quantity_used` decimal(12,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `raw_material_id` (`raw_material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_raw_materials`
INSERT INTO `batch_raw_materials` (`id`, `batch_id`, `raw_material_id`, `material_name`, `unit`, `supplier_id`, `quantity_used`, `created_at`) VALUES
('1','1',NULL,'عسل - سدر','كيلوجرام','2','1.000','2025-11-15 05:58:14'),
('2','2',NULL,'عسل - سدر','كيلوجرام','2','1.000','2025-11-15 05:58:32'),
('3','3',NULL,'شمع','كيلوجرام','8','1.000','2025-11-15 06:27:38'),
('4','3',NULL,'عسل - حبة البركة','كيلوجرام','3','0.200','2025-11-15 06:27:38'),
('5','4',NULL,'مشتقات - غذاء ملكات','كيلوجرام','7','1.000','2025-11-15 07:44:33'),
('6','5',NULL,'زيت زيتون','كيلوجرام','6','1.000','2025-11-15 07:44:53'),
('7','6',NULL,'عسل - حبة البركة','كيلوجرام','3','0.200','2025-11-15 09:26:08'),
('8','6',NULL,'مكسرات - تشكيله 2','كيلوجرام','5','0.800','2025-11-15 09:26:08');

-- هيكل الجدول `batch_suppliers`
DROP TABLE IF EXISTS `batch_suppliers`;
CREATE TABLE `batch_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(255) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_suppliers`
INSERT INTO `batch_suppliers` (`id`, `batch_id`, `supplier_id`, `supplier_name`, `role`, `created_at`) VALUES
('1','1','2','عسل - سدر','raw_material','2025-11-15 05:58:14'),
('2','1','4','تعبئه','packaging','2025-11-15 05:58:14'),
('3','2','2','عسل - سدر','raw_material','2025-11-15 05:58:32'),
('4','2','4','تعبئه','packaging','2025-11-15 05:58:32'),
('5','3','8','شمع','raw_material','2025-11-15 06:27:38'),
('6','3','3','عسل - حبة البركة','raw_material','2025-11-15 06:27:38'),
('7','3','4','تعبئه','packaging','2025-11-15 06:27:38'),
('8','4','7','مشتقات - غذاء ملكات','raw_material','2025-11-15 07:44:33'),
('9','4','4','تعبئه','packaging','2025-11-15 07:44:33'),
('10','5','6','زيت زيتون','raw_material','2025-11-15 07:44:53'),
('11','5','4','تعبئه','packaging','2025-11-15 07:44:53'),
('12','6','3','عسل - حبة البركة','raw_material','2025-11-15 09:26:08'),
('13','6','5','مكسرات - تشكيله 2','raw_material','2025-11-15 09:26:08'),
('14','6','4','تعبئه','packaging','2025-11-15 09:26:08');

-- هيكل الجدول `batch_workers`
DROP TABLE IF EXISTS `batch_workers`;
CREATE TABLE `batch_workers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `worker_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batch_workers`
INSERT INTO `batch_workers` (`id`, `batch_id`, `employee_id`, `worker_name`, `created_at`) VALUES
('1','1','4','عامل الإنتاج الأول','2025-11-15 05:58:14'),
('2','2','4','عامل الإنتاج الأول','2025-11-15 05:58:32'),
('3','3','4','عامل الإنتاج الأول','2025-11-15 06:27:38'),
('4','4','4','عامل الإنتاج الأول','2025-11-15 07:44:33'),
('5','5','4','عامل الإنتاج الأول','2025-11-15 07:44:53'),
('6','6','4','عامل الإنتاج الأول','2025-11-15 09:26:08');

-- هيكل الجدول `batches`
DROP TABLE IF EXISTS `batches`;
CREATE TABLE `batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `batch_number` varchar(100) NOT NULL,
  `production_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `status` enum('in_production','completed','cancelled') DEFAULT 'in_production',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_batch_number` (`batch_number`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `batches`
INSERT INTO `batches` (`id`, `product_id`, `batch_number`, `production_date`, `expiry_date`, `quantity`, `status`, `created_at`, `updated_at`) VALUES
('1',NULL,'251115-936155','2025-11-15','2026-11-15','1','in_production','2025-11-15 05:58:14','2025-11-15 05:58:14'),
('2',NULL,'251115-238486','2025-11-15','2026-11-15','1','in_production','2025-11-15 05:58:32','2025-11-15 05:58:32'),
('3',NULL,'251115-058200','2025-11-15','2026-11-15','1','in_production','2025-11-15 06:27:38','2025-11-15 06:27:38'),
('4',NULL,'251115-185290','2025-11-15','2026-11-15','1','in_production','2025-11-15 07:44:33','2025-11-15 07:44:33'),
('5',NULL,'251115-765452','2025-11-15','2026-11-15','1','in_production','2025-11-15 07:44:53','2025-11-15 07:44:53'),
('6',NULL,'251115-102778','2025-11-15','2026-11-15','1','in_production','2025-11-15 09:26:08','2025-11-15 09:26:08');

-- هيكل الجدول `beeswax_product_templates`
DROP TABLE IF EXISTS `beeswax_product_templates`;
CREATE TABLE `beeswax_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `beeswax_weight` decimal(10,2) NOT NULL COMMENT 'وزن شمع العسل (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `beeswax_product_templates`
-- لا توجد بيانات في الجدول `beeswax_product_templates`

-- هيكل الجدول `beeswax_stock`
DROP TABLE IF EXISTS `beeswax_stock`;
CREATE TABLE `beeswax_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الوزن (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `beeswax_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `beeswax_stock`
INSERT INTO `beeswax_stock` (`id`, `supplier_id`, `weight`, `created_at`, `updated_at`) VALUES
('1','8','95.00','2025-11-08 04:38:53','2025-11-15 06:27:38');

-- هيكل الجدول `blocked_ips`
DROP TABLE IF EXISTS `blocked_ips`;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `blocked_until` timestamp NULL DEFAULT NULL,
  `blocked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `blocked_until` (`blocked_until`),
  KEY `blocked_by` (`blocked_by`),
  CONSTRAINT `blocked_ips_ibfk_1` FOREIGN KEY (`blocked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `blocked_ips`
-- لا توجد بيانات في الجدول `blocked_ips`

-- هيكل الجدول `collections`
DROP TABLE IF EXISTS `collections`;
CREATE TABLE `collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_number` varchar(50) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer','check','other') DEFAULT 'cash',
  `reference_number` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `collected_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `collected_by` (`collected_by`),
  KEY `date` (`date`),
  CONSTRAINT `collections_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `collections_ibfk_2` FOREIGN KEY (`collected_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `collections`
INSERT INTO `collections` (`id`, `collection_number`, `customer_id`, `amount`, `date`, `payment_method`, `reference_number`, `notes`, `collected_by`, `created_at`) VALUES
('1','COL-202511-0001','4','10.00','2025-11-18','cash',NULL,'تحصيل من صفحة العملاء','3','2025-11-18 11:08:49'),
('2','COL-202511-0002','4','10.00','2025-11-18','cash',NULL,'تحصيل من صفحة العملاء','3','2025-11-18 13:06:00');

-- هيكل الجدول `customer_order_items`
DROP TABLE IF EXISTS `customer_order_items`;
CREATE TABLE `customer_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `customer_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `customer_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `customer_order_items`
-- لا توجد بيانات في الجدول `customer_order_items`

-- هيكل الجدول `customer_orders`
DROP TABLE IF EXISTS `customer_orders`;
CREATE TABLE `customer_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `order_date` date NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `status` enum('pending','confirmed','in_production','ready','delivered','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `order_date` (`order_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `customer_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_orders_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customer_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `customer_orders`
-- لا توجد بيانات في الجدول `customer_orders`

-- هيكل الجدول `customer_purchase_history`
DROP TABLE IF EXISTS `customer_purchase_history`;
CREATE TABLE `customer_purchase_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `invoice_date` date NOT NULL,
  `invoice_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `invoice_status` varchar(32) DEFAULT NULL,
  `return_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `return_count` int(11) NOT NULL DEFAULT 0,
  `exchange_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `exchange_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_invoice_unique` (`customer_id`,`invoice_id`),
  KEY `customer_invoice_date_idx` (`customer_id`,`invoice_date`),
  KEY `invoice_date_idx` (`invoice_date`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `customer_purchase_history`
INSERT INTO `customer_purchase_history` (`id`, `customer_id`, `invoice_id`, `invoice_number`, `invoice_date`, `invoice_total`, `paid_amount`, `invoice_status`, `return_total`, `return_count`, `exchange_total`, `exchange_count`, `created_at`, `updated_at`) VALUES
('1','4','10','INV-202511-0001','2025-11-17','500.00','500.00','paid','0.00','0','0.00','0','2025-11-17 06:39:23','2025-11-18 19:08:03'),
('4','4','11','INV-202511-0002','2025-11-17','200.00','120.00','partial','0.00','0','0.00','0','2025-11-17 07:38:46','2025-11-18 19:08:03');

-- هيكل الجدول `customers`
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `location_captured_at` datetime DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_customers_created_by` (`created_by`),
  CONSTRAINT `fk_customers_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `customers`
INSERT INTO `customers` (`id`, `name`, `phone`, `email`, `address`, `latitude`, `longitude`, `location_captured_at`, `balance`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
('1','1','01000000001',NULL,NULL,'31.09891280','29.77286266','2025-11-17 06:21:32','0.00','active','1','2025-11-08 19:37:41','2025-11-17 06:21:32'),
('2','2',NULL,NULL,NULL,'30.46599290','31.18483070','2025-11-14 14:53:29','0.00','active','1','2025-11-08 19:38:00','2025-11-14 14:55:20'),
('4','احمد','01000000004',NULL,'64 ش عيد','31.09897183','29.77282598','2025-11-17 06:21:50','20.00','active','3','2025-11-17 04:47:46','2025-11-18 13:06:00'),
('8','مايكل',NULL,NULL,NULL,NULL,NULL,NULL,'1000.00','active','3','2025-11-18 18:58:59',NULL),
('9','عمرو',NULL,NULL,NULL,NULL,NULL,NULL,'0.00','active','3','2025-11-18 19:04:42',NULL),
('10','خالد','0100000001',NULL,NULL,NULL,NULL,NULL,'180.00','active','3','2025-11-18 19:20:31','2025-11-18 19:23:00');

-- هيكل الجدول `derivatives_product_templates`
DROP TABLE IF EXISTS `derivatives_product_templates`;
CREATE TABLE `derivatives_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `derivative_type` varchar(100) NOT NULL COMMENT 'نوع المشتق المستخدم',
  `derivative_weight` decimal(10,2) NOT NULL COMMENT 'وزن المشتق (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `derivative_type` (`derivative_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `derivatives_product_templates`
-- لا توجد بيانات في الجدول `derivatives_product_templates`

-- هيكل الجدول `derivatives_stock`
DROP TABLE IF EXISTS `derivatives_stock`;
CREATE TABLE `derivatives_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `derivative_type` varchar(100) NOT NULL COMMENT 'نوع المشتق',
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الوزن (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_derivative` (`supplier_id`,`derivative_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `derivative_type` (`derivative_type`),
  CONSTRAINT `derivatives_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `derivatives_stock`
INSERT INTO `derivatives_stock` (`id`, `supplier_id`, `derivative_type`, `weight`, `created_at`, `updated_at`) VALUES
('1','7','غذاء ملكات','9.50','2025-11-09 09:21:20','2025-11-15 07:44:33');

-- هيكل الجدول `exchange_new_items`
DROP TABLE IF EXISTS `exchange_new_items`;
CREATE TABLE `exchange_new_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `batch_number_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `exchange_new_items_ibfk_1` FOREIGN KEY (`exchange_id`) REFERENCES `product_exchanges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_new_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_new_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `exchange_new_items`
-- لا توجد بيانات في الجدول `exchange_new_items`

-- هيكل الجدول `exchange_return_items`
DROP TABLE IF EXISTS `exchange_return_items`;
CREATE TABLE `exchange_return_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `batch_number_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `exchange_return_items_ibfk_1` FOREIGN KEY (`exchange_id`) REFERENCES `product_exchanges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_return_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_return_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `exchange_return_items`
-- لا توجد بيانات في الجدول `exchange_return_items`

-- هيكل الجدول `exchanges`
DROP TABLE IF EXISTS `exchanges`;
CREATE TABLE `exchanges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_number` varchar(50) NOT NULL,
  `return_id` int(11) DEFAULT NULL,
  `original_sale_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `exchange_date` date NOT NULL,
  `exchange_type` enum('same_product','different_product','upgrade','downgrade') DEFAULT 'same_product',
  `reason` text DEFAULT NULL,
  `original_total` decimal(15,2) NOT NULL,
  `new_total` decimal(15,2) NOT NULL,
  `difference_amount` decimal(15,2) DEFAULT 0.00,
  `difference_paid` tinyint(1) DEFAULT 0,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `exchange_number` (`exchange_number`),
  KEY `return_id` (`return_id`),
  KEY `original_sale_id` (`original_sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `exchange_date` (`exchange_date`),
  KEY `status` (`status`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `exchanges_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `returns` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_2` FOREIGN KEY (`original_sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchanges_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchanges_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `exchanges`
-- لا توجد بيانات في الجدول `exchanges`

-- هيكل الجدول `financial_transactions`
DROP TABLE IF EXISTS `financial_transactions`;
CREATE TABLE `financial_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('expense','income','transfer','payment') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `financial_transactions_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_transactions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `financial_transactions_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `financial_transactions`
-- لا توجد بيانات في الجدول `financial_transactions`

-- هيكل الجدول `finished_products`
DROP TABLE IF EXISTS `finished_products`;
CREATE TABLE `finished_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `batch_number` varchar(100) NOT NULL,
  `production_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity_produced` int(11) NOT NULL DEFAULT 0,
  `unit_price` decimal(12,2) DEFAULT NULL COMMENT 'سعر الوحدة من القالب',
  `total_price` decimal(12,2) DEFAULT NULL COMMENT 'السعر الإجمالي (unit_price × quantity_produced)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number` (`batch_number`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `finished_products`
INSERT INTO `finished_products` (`id`, `batch_id`, `product_id`, `product_name`, `batch_number`, `production_date`, `expiry_date`, `quantity_produced`, `unit_price`, `total_price`, `created_at`) VALUES
('1','1','6','عسل سدر ك','251115-936155','2025-11-15','2026-11-15','1','120.00','120.00','2025-11-15 05:58:14'),
('2','2','7','عسل سدر ك','251115-238486','2025-11-15','2026-11-15','1','120.00','120.00','2025-11-15 05:58:32'),
('3','3','13','شمع عسل 1 ك','251115-058200','2025-11-15','2026-11-15','1','300.00','300.00','2025-11-15 06:27:38'),
('4','4','17','غذا','251115-185290','2025-11-15','2026-11-15','0','500.00','500.00','2025-11-15 07:44:33'),
('5','5','19','زيت زيتون كيلو','251115-765452','2025-11-15','2026-11-15','0','200.00','200.00','2025-11-15 07:44:53'),
('6','6','22','عسل مكسرات ك','251115-102778','2025-11-15','2026-11-15','0','500.00','500.00','2025-11-15 09:26:08');

-- هيكل الجدول `group_chat_messages`
DROP TABLE IF EXISTS `group_chat_messages`;
CREATE TABLE `group_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group_chat_user` (`user_id`),
  KEY `idx_group_chat_parent` (`parent_id`),
  KEY `idx_group_chat_created` (`created_at`),
  CONSTRAINT `fk_group_chat_parent` FOREIGN KEY (`parent_id`) REFERENCES `group_chat_messages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_group_chat_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `group_chat_messages`
-- لا توجد بيانات في الجدول `group_chat_messages`

-- هيكل الجدول `honey_filtration`
DROP TABLE IF EXISTS `honey_filtration`;
CREATE TABLE `honey_filtration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `raw_honey_quantity` decimal(10,2) NOT NULL,
  `filtered_honey_quantity` decimal(10,2) NOT NULL,
  `filtration_loss` decimal(10,2) NOT NULL COMMENT 'الكمية المفقودة (0.5%)',
  `filtration_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `filtration_date` (`filtration_date`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `honey_filtration_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `honey_filtration_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `honey_filtration`
-- لا توجد بيانات في الجدول `honey_filtration`

-- هيكل الجدول `honey_stock`
DROP TABLE IF EXISTS `honey_stock`;
CREATE TABLE `honey_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `honey_variety` enum('سدر','جبلي','حبة البركة','موالح','نوارة برسيم','أخرى') DEFAULT 'أخرى' COMMENT 'نوع العسل',
  `raw_honey_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `filtered_honey_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`),
  KEY `honey_variety` (`honey_variety`),
  KEY `supplier_variety` (`supplier_id`,`honey_variety`),
  CONSTRAINT `honey_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `honey_stock`
INSERT INTO `honey_stock` (`id`, `supplier_id`, `honey_variety`, `raw_honey_quantity`, `filtered_honey_quantity`, `created_at`, `updated_at`) VALUES
('2','2','سدر','1000.00','997.00','2025-11-06 19:30:18','2025-11-15 06:31:42'),
('3','3','حبة البركة','1000.00','999.60','2025-11-07 08:01:18','2025-11-15 09:26:08'),
('4','2','موالح','1000.00','1000.00','2025-11-12 03:00:39','2025-11-14 02:19:50');

-- هيكل الجدول `inventory_movements`
DROP TABLE IF EXISTS `inventory_movements`;
CREATE TABLE `inventory_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `type` enum('in','out','adjustment','transfer') NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `quantity_before` decimal(10,2) NOT NULL,
  `quantity_after` decimal(10,2) NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL COMMENT 'production, sales, purchase, etc.',
  `reference_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `reference` (`reference_type`,`reference_id`),
  KEY `type` (`type`),
  KEY `created_at` (`created_at`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `inventory_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_movements_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_movements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `inventory_movements`
INSERT INTO `inventory_movements` (`id`, `product_id`, `warehouse_id`, `type`, `quantity`, `quantity_before`, `quantity_after`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES
('2','22','2','out','1.00','1.00','0.00','warehouse_transfer','15','نقل إلى مخزن آخر - تشغيلة 251115-102778','1','2025-11-16 03:09:21'),
('3','22','3','in','1.00','0.00','0.00','warehouse_transfer','15','نقل إلى مخزن سيارة - تشغيلة 251115-102778','1','2025-11-16 03:09:21'),
('4','19','2','out','1.00','1.00','0.00','warehouse_transfer','14','نقل إلى مخزن آخر - تشغيلة 251115-765452','1','2025-11-16 03:13:46'),
('5','19','3','in','1.00','0.00','0.00','warehouse_transfer','14','نقل إلى مخزن سيارة - تشغيلة 251115-765452','1','2025-11-16 03:13:46'),
('6','17','2','out','1.00','1.00','0.00','warehouse_transfer','16','نقل إلى مخزن آخر - تشغيلة 251115-185290','1','2025-11-16 03:25:08'),
('7','17','3','in','1.00','0.00','0.00','warehouse_transfer','16','نقل إلى مخزن سيارة - تشغيلة 251115-185290','1','2025-11-16 03:25:08'),
('8','13','2','out','1.00','1.00','0.00','warehouse_transfer','22','نقل إلى مخزن آخر - تشغيلة 251115-058200','1','2025-11-16 06:07:56'),
('9','13','3','in','1.00','0.00','0.00','warehouse_transfer','22','نقل إلى مخزن سيارة - تشغيلة 251115-058200','1','2025-11-16 06:07:56'),
('10','7','2','out','1.00','1.00','0.00','warehouse_transfer','23','نقل إلى مخزن آخر - تشغيلة 251115-238486','1','2025-11-17 04:40:23'),
('11','7','3','in','1.00','0.00','0.00','warehouse_transfer','23','نقل إلى مخزن سيارة - تشغيلة 251115-238486','1','2025-11-17 04:40:23'),
('12','17','3','out','1.00','1.00','0.00','sales','10','بيع من نقطة بيع المندوب - فاتورة INV-202511-0001','3','2025-11-17 06:37:09'),
('13','19','3','out','1.00','1.00','0.00','sales','11','بيع من نقطة بيع المندوب - فاتورة INV-202511-0002','3','2025-11-17 07:28:34'),
('14','24','2','out','5.00','10.00','5.00','warehouse_transfer','26','نقل إلى مخزن آخر','1','2025-11-17 09:01:58'),
('15','24','3','in','5.00','5.00','5.00','warehouse_transfer','26','نقل إلى مخزن سيارة','1','2025-11-17 09:01:58'),
('16','24','2','out','1.00','5.00','4.00','warehouse_transfer','31','نقل إلى مخزن آخر','1','2025-11-17 10:47:36'),
('17','24','3','in','1.00','4.00','4.00','warehouse_transfer','31','نقل إلى مخزن سيارة','1','2025-11-17 10:47:36'),
('18','24','3','out','1.00','6.00','5.00','warehouse_transfer','32','نقل إلى مخزن آخر','1','2025-11-17 10:48:41'),
('19','24','2','in','1.00','5.00','6.00','warehouse_transfer','32','نقل من مخزن آخر','1','2025-11-17 10:48:41'),
('20','24','3','out','1.00','5.00','4.00','warehouse_transfer','33','نقل إلى مخزن آخر','1','2025-11-17 10:49:49'),
('21','24','2','in','1.00','7.00','8.00','warehouse_transfer','33','نقل من مخزن آخر','1','2025-11-17 10:49:49'),
('22','22','3','out','1.00','1.00','0.00','warehouse_transfer','37','نقل إلى مخزن آخر - تشغيلة 251115-102778','1','2025-11-18 11:40:14'),
('23','22','2','in','1.00','1.00','2.00','warehouse_transfer','37','نقل من مخزن آخر - تشغيلة 251115-102778','1','2025-11-18 11:40:14'),
('24','13','3','out','1.00','1.00','0.00','warehouse_transfer','38','نقل إلى مخزن آخر - تشغيلة 251115-058200','1','2025-11-18 13:07:21'),
('25','13','2','in','1.00','1.00','2.00','warehouse_transfer','38','نقل من مخزن آخر - تشغيلة 251115-058200','1','2025-11-18 13:07:21'),
('26','24','3','out','1.00','4.00','3.00','warehouse_transfer','39','نقل إلى مخزن آخر','1','2025-11-18 14:19:12'),
('27','24','2','in','1.00','9.00','10.00','warehouse_transfer','39','نقل من مخزن آخر','1','2025-11-18 14:19:12'),
('28','24','3','out','1.00','3.00','2.00','warehouse_transfer','40','نقل إلى مخزن آخر','1','2025-11-18 14:28:57'),
('29','24','2','in','1.00','10.00','11.00','warehouse_transfer','40','نقل من مخزن آخر','1','2025-11-18 14:28:57'),
('30','24','2','out','3.00','11.00','8.00','warehouse_transfer','41','نقل إلى مخزن آخر','1','2025-11-18 16:34:26'),
('31','24','3','in','3.00','8.00','8.00','warehouse_transfer','41','نقل إلى مخزن سيارة','1','2025-11-18 16:34:26'),
('32','24','3','out','2.00','5.00','3.00','warehouse_transfer','42','نقل إلى مخزن آخر','1','2025-11-18 16:34:55'),
('33','24','2','in','2.00','10.00','12.00','warehouse_transfer','42','نقل من مخزن آخر','1','2025-11-18 16:34:55'),
('34','24','3','out','2.00','3.00','1.00','warehouse_transfer','43','نقل إلى مخزن آخر','1','2025-11-18 16:36:19'),
('35','24','2','in','2.00','12.00','14.00','warehouse_transfer','43','نقل من مخزن آخر','1','2025-11-18 16:36:19'),
('36','7','3','out','1.00','1.00','0.00','warehouse_transfer','43','نقل إلى مخزن آخر - تشغيلة 251115-238486','1','2025-11-18 16:36:19'),
('37','7','2','in','1.00','0.00','1.00','warehouse_transfer','43','نقل من مخزن آخر - تشغيلة 251115-238486','1','2025-11-18 16:36:19'),
('38','24','2','out','10.00','14.00','4.00','warehouse_transfer','44','نقل إلى مخزن آخر','1','2025-11-18 16:49:22'),
('39','24','3','in','10.00','4.00','4.00','warehouse_transfer','44','نقل إلى مخزن سيارة','1','2025-11-18 16:49:22'),
('40','24','3','out','10.00','11.00','1.00','sales','12','بيع من نقطة بيع المندوب - فاتورة INV-202511-0003','3','2025-11-18 19:23:00');

-- هيكل الجدول `invoice_items`
DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `invoice_items`
INSERT INTO `invoice_items` (`id`, `invoice_id`, `product_id`, `description`, `quantity`, `unit_price`, `total_price`, `created_at`) VALUES
('10','10','17','غذا','1.00','500.00','500.00','2025-11-17 06:37:09'),
('11','11','19','زيت زيتون كيلو','1.00','200.00','200.00','2025-11-17 07:28:34'),
('12','12','24','صابون كبير','10.00','20.00','200.00','2025-11-18 19:23:00');

-- هيكل الجدول `invoices`
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `tax_amount` decimal(15,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(15,2) DEFAULT 0.00,
  `remaining_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('draft','sent','paid','partial','overdue','cancelled') DEFAULT 'draft',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `date` (`date`),
  KEY `due_date` (`due_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `invoices`
INSERT INTO `invoices` (`id`, `invoice_number`, `customer_id`, `sales_rep_id`, `date`, `due_date`, `subtotal`, `tax_rate`, `tax_amount`, `discount_amount`, `total_amount`, `paid_amount`, `remaining_amount`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('10','INV-202511-0001','4','3','2025-11-17','2025-12-17','500.00','0.00','0.00','0.00','500.00','500.00','0.00','paid','','3','2025-11-17 06:37:09','2025-11-17 06:37:09'),
('11','INV-202511-0002','4','3','2025-11-17','2025-12-17','200.00','0.00','0.00','0.00','200.00','120.00','80.00','partial','','3','2025-11-17 07:28:34','2025-11-18 13:06:00'),
('12','INV-202511-0003','10','3','2025-11-18',NULL,'200.00','0.00','0.00','0.00','200.00','20.00','180.00','partial','','3','2025-11-18 19:23:00','2025-11-18 19:23:00');

-- هيكل الجدول `login_attempts`
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `success` tinyint(1) DEFAULT 0,
  `failure_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `username` (`username`),
  KEY `created_at` (`created_at`),
  KEY `success` (`success`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `login_attempts`
INSERT INTO `login_attempts` (`id`, `username`, `ip_address`, `user_agent`, `success`, `failure_reason`, `created_at`) VALUES
('15','p','41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','1',NULL,'2025-11-18 12:06:35'),
('16','admin','41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','1',NULL,'2025-11-18 12:13:51'),
('17','p','41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','1',NULL,'2025-11-18 14:04:11'),
('18','admin','41.199.182.205','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','1',NULL,'2025-11-18 14:18:04'),
('19','p','41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','1',NULL,'2025-11-18 16:13:31'),
('20','s','41.199.14.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','1',NULL,'2025-11-18 16:15:22');

-- هيكل الجدول `message_reads`
DROP TABLE IF EXISTS `message_reads`;
CREATE TABLE `message_reads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `read_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `message_reads_unique` (`message_id`,`user_id`),
  KEY `message_reads_user_idx` (`user_id`),
  CONSTRAINT `message_reads_message_fk` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_reads_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `message_reads`
INSERT INTO `message_reads` (`id`, `message_id`, `user_id`, `read_at`) VALUES
('1','1','1','2025-11-14 18:51:02'),
('2','1','4','2025-11-14 18:52:31'),
('3','2','4','2025-11-14 18:51:27'),
('4','2','1','2025-11-14 18:51:36'),
('8','3','3','2025-11-16 06:23:36'),
('9','3','4','2025-11-17 04:22:18'),
('10','3','1','2025-11-18 14:18:23');

-- هيكل الجدول `messages`
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message_text` longtext NOT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `edited` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `read_by_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `messages_user_id_idx` (`user_id`),
  KEY `messages_reply_to_idx` (`reply_to`),
  CONSTRAINT `messages_reply_fk` FOREIGN KEY (`reply_to`) REFERENCES `messages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `messages_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `messages`
INSERT INTO `messages` (`id`, `user_id`, `message_text`, `reply_to`, `edited`, `deleted`, `created_at`, `updated_at`, `read_by_count`) VALUES
('1','1','',NULL,'1','1','2025-11-14 18:51:02','2025-11-14 18:53:10','2'),
('2','4','','1','1','1','2025-11-14 18:51:27','2025-11-14 18:52:13','2'),
('3','3','السلام عليكم',NULL,'0','0','2025-11-16 06:23:36','2025-11-18 14:18:19','3');

-- هيكل الجدول `mixed_nuts`
DROP TABLE IF EXISTS `mixed_nuts`;
CREATE TABLE `mixed_nuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(255) NOT NULL COMMENT 'اسم الخلطة',
  `supplier_id` int(11) NOT NULL COMMENT 'المورد الخاص بالخلطة',
  `total_quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'إجمالي الوزن',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `mixed_nuts_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mixed_nuts_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `mixed_nuts`
INSERT INTO `mixed_nuts` (`id`, `batch_name`, `supplier_id`, `total_quantity`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1','1','5','10.000',NULL,'4','2025-11-08 05:35:28',NULL),
('2','تشكيله 2','5','7.000',NULL,'4','2025-11-09 09:22:21',NULL);

-- هيكل الجدول `mixed_nuts_ingredients`
DROP TABLE IF EXISTS `mixed_nuts_ingredients`;
CREATE TABLE `mixed_nuts_ingredients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mixed_nuts_id` int(11) NOT NULL COMMENT 'رقم الخلطة',
  `nuts_stock_id` int(11) NOT NULL COMMENT 'رقم المكسرات المنفردة',
  `quantity` decimal(10,3) NOT NULL COMMENT 'الكمية المستخدمة',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mixed_nuts_id` (`mixed_nuts_id`),
  KEY `nuts_stock_id` (`nuts_stock_id`),
  CONSTRAINT `mixed_nuts_ingredients_ibfk_1` FOREIGN KEY (`mixed_nuts_id`) REFERENCES `mixed_nuts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mixed_nuts_ingredients_ibfk_2` FOREIGN KEY (`nuts_stock_id`) REFERENCES `nuts_stock` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `mixed_nuts_ingredients`
INSERT INTO `mixed_nuts_ingredients` (`id`, `mixed_nuts_id`, `nuts_stock_id`, `quantity`, `created_at`) VALUES
('1','1','1','10.000','2025-11-08 05:35:28'),
('2','2','2','5.000','2025-11-09 09:22:21'),
('3','2','3','2.000','2025-11-09 09:22:21');

-- هيكل الجدول `notification_settings`
DROP TABLE IF EXISTS `notification_settings`;
CREATE TABLE `notification_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role` enum('manager','accountant','sales','production','all') DEFAULT NULL,
  `notification_type` varchar(50) NOT NULL,
  `telegram_enabled` tinyint(1) DEFAULT 0,
  `telegram_chat_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `role` (`role`),
  KEY `notification_type` (`notification_type`),
  CONSTRAINT `notification_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `notification_settings`
-- لا توجد بيانات في الجدول `notification_settings`

-- هيكل الجدول `notifications`
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role` enum('manager','accountant','sales','production','all') DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `link` varchar(255) DEFAULT NULL,
  `read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `role` (`role`),
  KEY `read` (`read`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `notifications`
INSERT INTO `notifications` (`id`, `user_id`, `role`, `title`, `message`, `type`, `link`, `read`, `created_at`) VALUES
('3','6',NULL,'تقرير المخازن اليومي','تم إرسال تقرير المخازن منخفضة الكمية إلى شات Telegram.','info',NULL,'0','2025-11-16 01:29:35'),
('5','6',NULL,'النسخة الاحتياطية اليومية','تم إنشاء النسخة الاحتياطية اليومية وإرسالها إلى شات Telegram بنجاح.','success',NULL,'0','2025-11-16 01:29:35'),
('7','6',NULL,'تقرير المخازن اليومي','تم إرسال تقرير أدوات التعبئة منخفضة الكمية إلى قناة Telegram.','info','/v1/reports/view.php?type=packaging&token=af4f36457f23e42165182b6eb6e6df9c','0','2025-11-16 01:29:36'),
('9','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-16 01:29:37'),
('11','6',NULL,'تقرير المخازن اليومي','تم إرسال تقرير المخازن منخفضة الكمية إلى شات Telegram.','info',NULL,'0','2025-11-17 04:20:23'),
('13','6',NULL,'النسخة الاحتياطية اليومية','تم إنشاء النسخة الاحتياطية اليومية وإرسالها إلى شات Telegram بنجاح.','success',NULL,'0','2025-11-17 04:20:24'),
('15','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-17 04:20:24'),
('17','6',NULL,'تقرير المخازن اليومي','تم إرسال تقرير أدوات التعبئة منخفضة الكمية إلى قناة Telegram.','info','/v1/reports/view.php?type=packaging&token=1a4cc89b7efbe037430343f8a9f77809','0','2025-11-17 04:20:29'),
('21','6',NULL,'تقرير المخازن اليومي','تم إرسال تقرير المخازن منخفضة الكمية إلى شات Telegram.','info',NULL,'0','2025-11-18 00:25:43'),
('23','6',NULL,'النسخة الاحتياطية اليومية','تم إنشاء النسخة الاحتياطية اليومية وإرسالها إلى شات Telegram بنجاح.','success',NULL,'0','2025-11-18 00:25:43'),
('25','6',NULL,'النسخة الاحتياطية اليومية','تم إرسال النسخة الاحتياطية للبيانات إلى شات Telegram مسبقاً اليوم.','info',NULL,'0','2025-11-18 00:25:43'),
('27','6',NULL,'تقرير المخازن اليومي','تم إرسال تقرير أدوات التعبئة منخفضة الكمية إلى قناة Telegram.','info','/v1/reports/view.php?type=packaging&token=5131ec6aa4f7251c111e84c816e56bf6','0','2025-11-18 00:26:36'),
('31','1',NULL,'تقرير المخازن اليومي','تم إرسال تقرير المخازن منخفضة الكمية إلى شات Telegram.','info',NULL,'0','2025-11-19 01:09:20'),
('32','6',NULL,'تقرير المخازن اليومي','تم إرسال تقرير المخازن منخفضة الكمية إلى شات Telegram.','info',NULL,'0','2025-11-19 01:09:20');

-- هيكل الجدول `nuts_stock`
DROP TABLE IF EXISTS `nuts_stock`;
CREATE TABLE `nuts_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `nut_type` varchar(100) NOT NULL COMMENT 'نوع المكسرات (لوز، جوز، فستق، إلخ)',
  `quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالكيلوجرام',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT 'سعر الكيلو',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`),
  KEY `nut_type` (`nut_type`),
  KEY `supplier_nut` (`supplier_id`,`nut_type`),
  CONSTRAINT `nuts_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `nuts_stock`
INSERT INTO `nuts_stock` (`id`, `supplier_id`, `nut_type`, `quantity`, `unit_price`, `notes`, `created_at`, `updated_at`) VALUES
('1','5','عين جمل','0.000',NULL,NULL,'2025-11-08 05:35:00','2025-11-13 06:22:11'),
('2','5','بندق','2.200',NULL,NULL,'2025-11-08 05:36:51','2025-11-15 09:26:08'),
('3','5','لوز','2.000',NULL,NULL,'2025-11-08 05:39:18','2025-11-13 06:22:11');

-- هيكل الجدول `olive_oil_product_templates`
DROP TABLE IF EXISTS `olive_oil_product_templates`;
CREATE TABLE `olive_oil_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `olive_oil_quantity` decimal(10,2) NOT NULL COMMENT 'كمية زيت الزيتون (لتر)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `olive_oil_product_templates`
-- لا توجد بيانات في الجدول `olive_oil_product_templates`

-- هيكل الجدول `olive_oil_stock`
DROP TABLE IF EXISTS `olive_oil_stock`;
CREATE TABLE `olive_oil_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية (لتر)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `olive_oil_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `olive_oil_stock`
INSERT INTO `olive_oil_stock` (`id`, `supplier_id`, `quantity`, `created_at`, `updated_at`) VALUES
('1','6','109.00','2025-11-09 09:20:46','2025-11-15 07:44:53');

-- هيكل الجدول `packaging_damage_logs`
DROP TABLE IF EXISTS `packaging_damage_logs`;
CREATE TABLE `packaging_damage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `source_table` enum('packaging_materials','products') NOT NULL DEFAULT 'packaging_materials',
  `quantity_before` decimal(15,4) DEFAULT 0.0000,
  `damaged_quantity` decimal(15,4) NOT NULL,
  `quantity_after` decimal(15,4) DEFAULT 0.0000,
  `unit` varchar(50) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `recorded_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `recorded_by` (`recorded_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `packaging_damage_logs`
-- لا توجد بيانات في الجدول `packaging_damage_logs`

-- هيكل الجدول `packaging_materials`
DROP TABLE IF EXISTS `packaging_materials`;
CREATE TABLE `packaging_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` varchar(50) NOT NULL COMMENT 'معرف فريد مثل PKG-001',
  `name` varchar(255) NOT NULL COMMENT 'اسم مأخوذ من type + specifications',
  `alias` varchar(255) DEFAULT NULL,
  `type` varchar(100) NOT NULL COMMENT 'نوع الأداة مثل: عبوات زجاجية',
  `specifications` varchar(255) DEFAULT NULL COMMENT 'المواصفات مثل: برطمان 720م دائري',
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(50) DEFAULT 'قطعة',
  `unit_price` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_id` (`material_id`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `packaging_materials`
INSERT INTO `packaging_materials` (`id`, `material_id`, `name`, `alias`, `type`, `specifications`, `quantity`, `unit`, `unit_price`, `status`, `created_at`, `updated_at`) VALUES
('1','PKG-001','صناديق كرتون - كراتين كيلو',NULL,'صناديق كرتون','كراتين كيلو','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('2','PKG-002','صناديق كرتون - كراتين نصف',NULL,'صناديق كرتون','كراتين نصف','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('3','PKG-003','عبوات زجاجية - برطمان 720م دائري',NULL,'عبوات زجاجية','برطمان 720م دائري','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('4','PKG-004','عبوات زجاجية - برطمان 370م دائري',NULL,'عبوات زجاجية','برطمان 370م دائري','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('5','PKG-005','عبوات زجاجية - برطمان 290م سداسي',NULL,'عبوات زجاجية','برطمان 290م سداسي','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('6','PKG-006','عبوات زجاجية - برطمان 285م فازه',NULL,'عبوات زجاجية','برطمان 285م فازه','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('7','PKG-007','عبوات زجاجية - برطمان 212 ملل',NULL,'عبوات زجاجية','برطمان 212 ملل','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('8','PKG-008','عبوات زجاجية - برطمان 100 ملل',NULL,'عبوات زجاجية','برطمان 100 ملل','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('9','PKG-009','عبوات زجاجية - برطمان 1ك مشرشر',NULL,'عبوات زجاجية','برطمان 1ك مشرشر','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('10','PKG-010','عبوات زجاجية - برطمان نص ك مشرشر',NULL,'عبوات زجاجية','برطمان نص ك مشرشر','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('11','PKG-011','عبوات بلاستيكية - سكويز 400م',NULL,'عبوات بلاستيكية','سكويز 400م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('12','PKG-012','عبوات بلاستيكية - سكويز 200م',NULL,'عبوات بلاستيكية','سكويز 200م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('13','PKG-013','أغطية - غطاء 63م متعدد',NULL,'أغطية','غطاء 63م متعدد','2.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-12 04:47:20'),
('14','PKG-014','أغطية - غطاء سنبله',NULL,'أغطية','غطاء سنبله','90.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-09 01:13:04'),
('15','PKG-015','أغطية - غطاء 82م',NULL,'أغطية','غطاء 82م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('16','PKG-016','أغطية - غطاء زيت زيتون متعدد',NULL,'أغطية','غطاء زيت زيتون متعدد','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('17','PKG-017','أغطية - غطاء 43م','2000','أغطية','غطاء 43م','7.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-13 08:19:27'),
('18','PKG-018','أغطية - غطاء سكويز 400م',NULL,'أغطية','غطاء سكويز 400م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('19','PKG-019','أغطية - غطاء فليبتوب 200م ذهبي',NULL,'أغطية','غطاء فليبتوب 200م ذهبي','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('20','PKG-020','أغطية - غطاء فليبتوب 200م اسود',NULL,'أغطية','غطاء فليبتوب 200م اسود','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('21','PKG-021','أغطية - غطاء دبدوب',NULL,'أغطية','غطاء دبدوب','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('22','PKG-022','طبات - طبه دبدوب',NULL,'طبات','طبه دبدوب','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('23','PKG-023','طبات - طبه سنبله',NULL,'طبات','طبه سنبله','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('24','PKG-024','طبات - طبه سكويز 200م',NULL,'طبات','طبه سكويز 200م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('25','PKG-025','طبات - طبه سكويز 400م',NULL,'طبات','طبه سكويز 400م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('26','PKG-026','طبات - طبه فليبتوب 200م',NULL,'طبات','طبه فليبتوب 200م','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('27','PKG-027','عبوات بلاستيكية - علبة شمع نص ك',NULL,'عبوات بلاستيكية','علبة شمع نص ك','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('28','PKG-028','عبوات بلاستيكية - علبة شمع ك',NULL,'عبوات بلاستيكية','علبة شمع ك','10.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-08 04:42:43'),
('29','PKG-029','عبوات بلاستيكية - جركن 20 ل',NULL,'عبوات بلاستيكية','جركن 20 ل','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('30','PKG-030','أكياس - أكياس',NULL,'أكياس','أكياس','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('31','PKG-031','لوازم التعبئة - شريط لاصق',NULL,'لوازم التعبئة','شريط لاصق','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('32','PKG-032','عبوات زجاجية - برطمان دبدوب',NULL,'عبوات زجاجية','برطمان دبدوب','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('33','PKG-033','عبوات زجاجية - برطمان دبله',NULL,'عبوات زجاجية','برطمان دبله','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('34','PKG-034','عبوات بلاستيكية - برطمان سكويز 200',NULL,'عبوات بلاستيكية','برطمان سكويز 200','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('35','PKG-035','عبوات بلاستيكية - برطمان سكويز 400',NULL,'عبوات بلاستيكية','برطمان سكويز 400','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('36','PKG-036','عبوات زجاجية - برطمان سنبله ك',NULL,'عبوات زجاجية','برطمان سنبله ك','0.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-06 04:17:32'),
('37','PKG-037','عبوات بلاستيكية - بابلز',NULL,'عبوات بلاستيكية','بابلز','8.00','قطعة','0.00','active','2025-11-06 04:16:07','2025-11-10 06:31:06'),
('38','PKG-038','ملصق صغير',NULL,'لوازم التعبئة',NULL,'7.00','قطعة','0.00','active','2025-11-12 03:59:08','2025-11-15 06:27:38'),
('39','PKG-039','ملصق وسط',NULL,'لوازم التعبئة',NULL,'6.00','قطعة','0.00','active','2025-11-12 04:00:11','2025-11-15 09:26:08'),
('40','PKG-040','ملصق كبير',NULL,'ملصقات',NULL,'7.00','قطعة','0.00','active','2025-11-12 04:00:54','2025-11-15 07:44:53');

-- هيكل الجدول `packaging_usage_logs`
DROP TABLE IF EXISTS `packaging_usage_logs`;
CREATE TABLE `packaging_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `material_code` varchar(100) DEFAULT NULL,
  `source_table` enum('packaging_materials','products') NOT NULL DEFAULT 'packaging_materials',
  `quantity_before` decimal(15,4) DEFAULT 0.0000,
  `quantity_used` decimal(15,4) NOT NULL,
  `quantity_after` decimal(15,4) DEFAULT 0.0000,
  `unit` varchar(50) DEFAULT NULL,
  `used_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `used_by` (`used_by`),
  KEY `source_table` (`source_table`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `packaging_usage_logs`
INSERT INTO `packaging_usage_logs` (`id`, `material_id`, `material_name`, `material_code`, `source_table`, `quantity_before`, `quantity_used`, `quantity_after`, `unit`, `used_by`, `created_at`) VALUES
('1','17','أغطية - غطاء 43م',NULL,'packaging_materials','10.0000','1.0000','9.0000','قطعة','4','2025-11-13 07:20:54'),
('2','17','أغطية - غطاء 43م',NULL,'packaging_materials','9.0000','1.0000','8.0000','قطعة','4','2025-11-13 07:27:44');

-- هيكل الجدول `payment_reminders`
DROP TABLE IF EXISTS `payment_reminders`;
CREATE TABLE `payment_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_schedule_id` int(11) NOT NULL,
  `reminder_type` enum('before_due','on_due','after_due','custom') DEFAULT 'before_due',
  `reminder_date` date NOT NULL,
  `days_before_due` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `sent_to` enum('sales_rep','customer','both') DEFAULT 'sales_rep',
  `sent_status` enum('pending','sent','failed') DEFAULT 'pending',
  `sent_at` timestamp NULL DEFAULT NULL,
  `sent_method` enum('notification','telegram','sms','email') DEFAULT 'notification',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `payment_schedule_id` (`payment_schedule_id`),
  KEY `reminder_date` (`reminder_date`),
  KEY `sent_status` (`sent_status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_reminders_ibfk_1` FOREIGN KEY (`payment_schedule_id`) REFERENCES `payment_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_reminders_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `payment_reminders`
INSERT INTO `payment_reminders` (`id`, `payment_schedule_id`, `reminder_type`, `reminder_date`, `days_before_due`, `message`, `sent_to`, `sent_status`, `sent_at`, `sent_method`, `created_by`, `created_at`) VALUES
('1','1','before_due','2025-11-17','1',NULL,'sales_rep','sent','2025-11-17 07:57:24','notification','3','2025-11-17 07:57:24'),
('2','2','before_due','2025-11-18','2',NULL,'sales_rep','sent','2025-11-18 17:00:54','notification','3','2025-11-18 17:00:54');

-- هيكل الجدول `payment_schedules`
DROP TABLE IF EXISTS `payment_schedules`;
CREATE TABLE `payment_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `due_date` date NOT NULL,
  `payment_date` date DEFAULT NULL,
  `status` enum('pending','paid','overdue','cancelled') DEFAULT 'pending',
  `installment_number` int(11) DEFAULT 1,
  `total_installments` int(11) DEFAULT 1,
  `notes` text DEFAULT NULL,
  `reminder_sent` tinyint(1) DEFAULT 0,
  `reminder_sent_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `due_date` (`due_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_schedules_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `payment_schedules`
INSERT INTO `payment_schedules` (`id`, `sale_id`, `invoice_id`, `customer_id`, `sales_rep_id`, `amount`, `due_date`, `payment_date`, `status`, `installment_number`, `total_installments`, `notes`, `reminder_sent`, `reminder_sent_at`, `created_by`, `created_at`, `updated_at`) VALUES
('1',NULL,NULL,'4','3','50.00','2025-11-19','2025-11-17','paid','1','1',NULL,'0',NULL,'3','2025-11-17 07:57:15','2025-11-17 08:10:16'),
('2',NULL,NULL,'4','3','50.00','2025-11-20','2025-11-18','paid','1','1',NULL,'1','2025-11-18 17:00:54','3','2025-11-17 08:15:31','2025-11-18 17:08:38'),
('3',NULL,NULL,'4','3','50.00','2025-11-20',NULL,'pending','1','1',NULL,'0',NULL,'3','2025-11-17 08:15:35',NULL);

-- هيكل الجدول `permissions`
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `permissions`
INSERT INTO `permissions` (`id`, `name`, `description`, `category`, `created_at`) VALUES
('1','view_financial','عرض البيانات المالية','financial','2025-11-04 08:14:12'),
('2','create_financial','إنشاء معاملات مالية','financial','2025-11-04 08:14:12'),
('3','approve_financial','الموافقة على المعاملات المالية','financial','2025-11-04 08:14:12'),
('4','view_sales','عرض المبيعات','sales','2025-11-04 08:14:12'),
('5','create_sales','إنشاء مبيعات','sales','2025-11-04 08:14:12'),
('6','approve_sales','الموافقة على المبيعات','sales','2025-11-04 08:14:12'),
('7','view_inventory','عرض المخزون','inventory','2025-11-04 08:14:12'),
('8','manage_inventory','إدارة المخزون','inventory','2025-11-04 08:14:12'),
('9','view_production','عرض الإنتاج','production','2025-11-04 08:14:12'),
('10','manage_production','إدارة الإنتاج','production','2025-11-04 08:14:12'),
('11','view_reports','عرض التقارير','reports','2025-11-04 08:14:12'),
('12','generate_reports','توليد التقارير','reports','2025-11-04 08:14:12'),
('13','manage_users','إدارة المستخدمين','users','2025-11-04 08:14:12'),
('14','manage_permissions','إدارة الصلاحيات','users','2025-11-04 08:14:12'),
('15','view_audit_logs','عرض سجل التدقيق','system','2025-11-04 08:14:12'),
('16','manage_settings','إدارة إعدادات النظام','system','2025-11-04 08:14:12');

-- هيكل الجدول `product_exchanges`
DROP TABLE IF EXISTS `product_exchanges`;
CREATE TABLE `product_exchanges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `original_invoice_id` int(11) DEFAULT NULL,
  `original_sale_id` int(11) DEFAULT NULL,
  `return_id` int(11) DEFAULT NULL,
  `exchange_date` date NOT NULL,
  `exchange_type` enum('same_product','different_product','upgrade','downgrade') DEFAULT 'same_product',
  `reason` text DEFAULT NULL,
  `original_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `new_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `difference_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `exchange_number` (`exchange_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `original_invoice_id` (`original_invoice_id`),
  KEY `original_sale_id` (`original_sale_id`),
  KEY `return_id` (`return_id`),
  KEY `status` (`status`),
  KEY `product_exchanges_ibfk_6` (`approved_by`),
  KEY `product_exchanges_ibfk_7` (`processed_by`),
  KEY `product_exchanges_ibfk_8` (`created_by`),
  CONSTRAINT `product_exchanges_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_exchanges_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_exchanges_ibfk_3` FOREIGN KEY (`original_invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_4` FOREIGN KEY (`original_sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_5` FOREIGN KEY (`return_id`) REFERENCES `sales_returns` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_7` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_exchanges`
-- لا توجد بيانات في الجدول `product_exchanges`

-- هيكل الجدول `product_specifications`
DROP TABLE IF EXISTS `product_specifications`;
CREATE TABLE `product_specifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `raw_materials` longtext DEFAULT NULL,
  `packaging` longtext DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `product_specifications_created_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_specifications_updated_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_specifications`
INSERT INTO `product_specifications` (`id`, `product_name`, `raw_materials`, `packaging`, `notes`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
('1','جركن عسل 29ك','- 29 كيلو عسل','- جركن\r\n- ستيكر',NULL,'1',NULL,'2025-11-14 02:29:14',NULL);

-- هيكل الجدول `product_template_materials`
DROP TABLE IF EXISTS `product_template_materials`;
CREATE TABLE `product_template_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL COMMENT 'القالب',
  `material_type` enum('honey','other','ingredient') NOT NULL DEFAULT 'other' COMMENT 'نوع المادة',
  `material_name` varchar(255) NOT NULL COMMENT 'اسم المادة',
  `material_id` int(11) DEFAULT NULL COMMENT 'معرف المادة (supplier_id للعسل أو product_id للمواد الأخرى)',
  `quantity_per_unit` decimal(10,3) NOT NULL COMMENT 'الكمية لكل وحدة منتج',
  `unit` varchar(50) DEFAULT 'كجم' COMMENT 'وحدة القياس',
  `is_required` tinyint(1) DEFAULT 1 COMMENT 'هل المادة مطلوبة',
  `notes` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0 COMMENT 'ترتيب العرض',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `material_type` (`material_type`),
  CONSTRAINT `product_template_materials_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `product_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_template_materials`
-- لا توجد بيانات في الجدول `product_template_materials`

-- هيكل الجدول `product_template_packaging`
DROP TABLE IF EXISTS `product_template_packaging`;
CREATE TABLE `product_template_packaging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL COMMENT 'القالب',
  `packaging_material_id` int(11) DEFAULT NULL COMMENT 'مادة التعبئة',
  `packaging_name` varchar(255) DEFAULT NULL COMMENT 'اسم أداة التعبئة',
  `quantity_per_unit` decimal(10,3) NOT NULL DEFAULT 1.000 COMMENT 'الكمية لكل وحدة منتج',
  `unit` varchar(50) DEFAULT 'قطعة' COMMENT 'الوحدة',
  `is_required` tinyint(1) DEFAULT 1 COMMENT 'هل أداة التعبئة مطلوبة',
  `notes` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0 COMMENT 'ترتيب العرض',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `packaging_material_id` (`packaging_material_id`),
  CONSTRAINT `product_template_packaging_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `product_templates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_template_packaging_ibfk_2` FOREIGN KEY (`packaging_material_id`) REFERENCES `packaging_materials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_template_packaging`
INSERT INTO `product_template_packaging` (`id`, `template_id`, `packaging_material_id`, `packaging_name`, `quantity_per_unit`, `unit`, `is_required`, `notes`, `sort_order`, `created_at`, `updated_at`) VALUES
('13','7','40','ملصق كبير','1.000','قطعة','1',NULL,'0','2025-11-15 08:30:18',NULL),
('14','6','40','ملصق كبير','1.000','قطعة','1',NULL,'0','2025-11-15 08:31:57',NULL),
('15','4','38','ملصق صغير','1.000','قطعة','1',NULL,'0','2025-11-15 08:32:21',NULL),
('16','3','38','ملصق صغير','1.000','قطعة','1',NULL,'0','2025-11-15 08:32:41',NULL),
('17','8','39','ملصق وسط','1.000','قطعة','1',NULL,'0','2025-11-15 08:36:46',NULL);

-- هيكل الجدول `product_template_raw_materials`
DROP TABLE IF EXISTS `product_template_raw_materials`;
CREATE TABLE `product_template_raw_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `material_name` varchar(255) NOT NULL COMMENT 'اسم المادة (مثل: مكسرات، لوز، إلخ)',
  `material_type` varchar(100) DEFAULT NULL COMMENT 'نوع المادة (مثل: honey_raw, honey_filtered)',
  `quantity_per_unit` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالجرام',
  `unit` varchar(50) DEFAULT 'جرام',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_template_raw_materials`
INSERT INTO `product_template_raw_materials` (`id`, `template_id`, `material_name`, `material_type`, `quantity_per_unit`, `unit`, `created_at`) VALUES
('3','1','عسل مصفى',NULL,'0.100','كجم','2025-11-14 15:29:21'),
('4','1','شمع عسل',NULL,'0.500','كجم','2025-11-14 15:29:21'),
('8','2','عسل - سدر','honey_filtered','1.000','كيلوجرام','2025-11-15 03:10:45'),
('15','7','مشتقات - غذاء ملكات','','1.000','كيلوجرام','2025-11-15 08:30:18'),
('16','6','زيت زيتون','','1.000','كيلوجرام','2025-11-15 08:31:57'),
('17','4','شمع','','1.000','كيلوجرام','2025-11-15 08:32:21'),
('18','4','عسل - حبة البركة','','0.200','كيلوجرام','2025-11-15 08:32:21'),
('19','3','عسل - سدر','','1.000','كيلوجرام','2025-11-15 08:32:41'),
('20','8','عسل - حبة البركة','honey_filtered','0.200','كيلوجرام','2025-11-15 08:36:46'),
('21','8','مكسرات - تشكيله 2','تشكيله 2','0.800','كيلوجرام','2025-11-15 08:36:46');

-- هيكل الجدول `product_templates`
DROP TABLE IF EXISTS `product_templates`;
CREATE TABLE `product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(255) NOT NULL COMMENT 'اسم القالب',
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL COMMENT 'اسم المنتج',
  `honey_quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'كمية العسل بالجرام',
  `template_type` varchar(50) DEFAULT 'general',
  `source_template_id` int(11) DEFAULT NULL,
  `main_supplier_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `details_json` longtext DEFAULT NULL,
  `unit_price` decimal(12,2) DEFAULT NULL COMMENT 'سعر الوحدة بالجنيه',
  `target_quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية المستهدفة',
  `unit` varchar(50) DEFAULT 'قطعة' COMMENT 'الوحدة',
  `description` text DEFAULT NULL COMMENT 'الوصف',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) NOT NULL COMMENT 'منشئ القالب',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `source_template_id` (`source_template_id`),
  KEY `main_supplier_id` (`main_supplier_id`),
  CONSTRAINT `product_templates_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `product_templates`
INSERT INTO `product_templates` (`id`, `template_name`, `product_id`, `product_name`, `honey_quantity`, `template_type`, `source_template_id`, `main_supplier_id`, `notes`, `details_json`, `unit_price`, `target_quantity`, `unit`, `description`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
('3','',NULL,'عسل سدر ك','0.000','legacy',NULL,NULL,NULL,'{\"product_name\":\"عسل سدر ك\",\"status\":\"active\",\"template_type\":\"legacy\",\"raw_materials\":[{\"type\":\"ingredient\",\"name\":\"عسل - سدر\",\"material_name\":\"عسل - سدر\",\"material_type\":\"\",\"quantity\":1,\"quantity_per_unit\":1,\"unit\":\"كيلوجرام\"}],\"packaging\":[{\"id\":38,\"packaging_material_id\":38,\"name\":\"ملصق صغير\",\"packaging_name\":\"ملصق صغير\",\"quantity_per_unit\":1,\"unit\":\"قطعة\"}],\"submitted_at\":\"2025-11-15T08:32:41+02:00\",\"submitted_by\":1}','120.00','0.00','قطعة',NULL,'active','1','2025-11-15 03:35:11','2025-11-15 08:32:41'),
('4','',NULL,'شمع عسل 1 ك','0.000','legacy',NULL,NULL,NULL,'{\"product_name\":\"شمع عسل 1 ك\",\"status\":\"active\",\"template_type\":\"legacy\",\"raw_materials\":[{\"type\":\"ingredient\",\"name\":\"شمع\",\"material_name\":\"شمع\",\"material_type\":\"\",\"quantity\":1,\"quantity_per_unit\":1,\"unit\":\"كيلوجرام\"},{\"type\":\"ingredient\",\"name\":\"عسل - حبة البركة\",\"material_name\":\"عسل - حبة البركة\",\"material_type\":\"\",\"quantity\":0.200000000000000011102230246251565404236316680908203125,\"quantity_per_unit\":0.200000000000000011102230246251565404236316680908203125,\"unit\":\"كيلوجرام\"}],\"packaging\":[{\"id\":38,\"packaging_material_id\":38,\"name\":\"ملصق صغير\",\"packaging_name\":\"ملصق صغير\",\"quantity_per_unit\":1,\"unit\":\"قطعة\"}],\"submitted_at\":\"2025-11-15T08:32:21+02:00\",\"submitted_by\":1}','300.00','0.00','قطعة',NULL,'active','1','2025-11-15 06:13:45','2025-11-15 08:32:21'),
('6','',NULL,'زيت زيتون كيلو','0.000','legacy',NULL,NULL,NULL,'{\"product_name\":\"زيت زيتون كيلو\",\"status\":\"active\",\"template_type\":\"legacy\",\"raw_materials\":[{\"type\":\"ingredient\",\"name\":\"زيت زيتون\",\"material_name\":\"زيت زيتون\",\"material_type\":\"\",\"quantity\":1,\"quantity_per_unit\":1,\"unit\":\"كيلوجرام\"}],\"packaging\":[{\"id\":40,\"packaging_material_id\":40,\"name\":\"ملصق كبير\",\"packaging_name\":\"ملصق كبير\",\"quantity_per_unit\":1,\"unit\":\"قطعة\"}],\"submitted_at\":\"2025-11-15T08:31:57+02:00\",\"submitted_by\":1}','200.00','0.00','قطعة',NULL,'active','1','2025-11-15 07:40:38','2025-11-15 08:31:57'),
('7','',NULL,'غذا','0.000','legacy',NULL,NULL,NULL,'{\"product_name\":\"غذا\",\"status\":\"active\",\"template_type\":\"legacy\",\"raw_materials\":[{\"type\":\"ingredient\",\"name\":\"مشتقات - غذاء ملكات\",\"material_name\":\"مشتقات - غذاء ملكات\",\"material_type\":\"\",\"quantity\":1,\"quantity_per_unit\":1,\"unit\":\"كيلوجرام\"}],\"packaging\":[{\"id\":40,\"packaging_material_id\":40,\"name\":\"ملصق كبير\",\"packaging_name\":\"ملصق كبير\",\"quantity_per_unit\":1,\"unit\":\"قطعة\"}],\"submitted_at\":\"2025-11-15T08:30:18+02:00\",\"submitted_by\":1}','500.00','0.00','قطعة',NULL,'active','1','2025-11-15 07:41:10','2025-11-15 08:30:18'),
('8','',NULL,'عسل مكسرات ك','0.000','legacy',NULL,NULL,NULL,'{\"product_name\":\"عسل مكسرات ك\",\"status\":\"active\",\"template_type\":\"legacy\",\"raw_materials\":[{\"type\":\"ingredient\",\"name\":\"عسل - حبة البركة\",\"material_name\":\"عسل\",\"material_type\":\"honey_filtered\",\"quantity\":0.200000000000000011102230246251565404236316680908203125,\"quantity_per_unit\":0.200000000000000011102230246251565404236316680908203125,\"unit\":\"كيلوجرام\"},{\"type\":\"ingredient\",\"name\":\"مكسرات - تشكيله 2\",\"material_name\":\"مكسرات\",\"material_type\":\"تشكيله 2\",\"quantity\":0.8000000000000000444089209850062616169452667236328125,\"quantity_per_unit\":0.8000000000000000444089209850062616169452667236328125,\"unit\":\"كيلوجرام\"}],\"packaging\":[{\"id\":39,\"packaging_material_id\":39,\"name\":\"ملصق وسط\",\"packaging_name\":\"ملصق وسط\",\"quantity_per_unit\":1,\"unit\":\"قطعة\"}],\"submitted_at\":\"2025-11-15T08:36:46+02:00\",\"submitted_by\":1}','500.00','0.00','قطعة',NULL,'active','1','2025-11-15 08:36:46',NULL);

-- هيكل الجدول `production`
DROP TABLE IF EXISTS `production`;
CREATE TABLE `production` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `customer_order_item_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `production_date` date NOT NULL,
  `worker_id` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `production_line_id` int(11) DEFAULT NULL COMMENT 'خط الإنتاج',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `worker_id` (`worker_id`),
  KEY `production_date` (`production_date`),
  KEY `customer_order_item_id` (`customer_order_item_id`),
  KEY `production_line_id` (`production_line_id`),
  CONSTRAINT `production_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_ibfk_line` FOREIGN KEY (`production_line_id`) REFERENCES `production_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_ibfk_order_item` FOREIGN KEY (`customer_order_item_id`) REFERENCES `customer_order_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production`
INSERT INTO `production` (`id`, `product_id`, `customer_order_item_id`, `quantity`, `production_date`, `worker_id`, `notes`, `status`, `created_at`, `production_line_id`) VALUES
('2','6',NULL,'1.00','2025-11-15','4',NULL,'completed','2025-11-15 05:58:14',NULL),
('3','7',NULL,'1.00','2025-11-15','4',NULL,'completed','2025-11-15 05:58:32',NULL),
('5','13',NULL,'1.00','2025-11-15','4',NULL,'completed','2025-11-15 06:27:38',NULL),
('6','17',NULL,'1.00','2025-11-15','4',NULL,'completed','2025-11-15 07:44:33',NULL),
('7','19',NULL,'1.00','2025-11-15','4',NULL,'completed','2025-11-15 07:44:53',NULL),
('8','22',NULL,'1.00','2025-11-15','4',NULL,'completed','2025-11-15 09:26:08',NULL);

-- هيكل الجدول `production_lines`
DROP TABLE IF EXISTS `production_lines`;
CREATE TABLE `production_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_name` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `target_quantity` decimal(10,2) DEFAULT 0.00,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `worker_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','active','completed','paused','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `worker_id` (`worker_id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  CONSTRAINT `production_lines_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_lines_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_lines_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production_lines`
-- لا توجد بيانات في الجدول `production_lines`

-- هيكل الجدول `production_materials`
DROP TABLE IF EXISTS `production_materials`;
CREATE TABLE `production_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `production_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_used` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `production_id` (`production_id`),
  KEY `product_id` (`product_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `production_materials_ibfk_1` FOREIGN KEY (`production_id`) REFERENCES `production` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_materials_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_materials_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production_materials`
INSERT INTO `production_materials` (`id`, `production_id`, `product_id`, `quantity_used`, `created_at`, `supplier_id`) VALUES
('1','2','4','1.00','2025-11-15 05:58:14','4'),
('2','2','5','1.00','2025-11-15 05:58:14','2'),
('3','3','4','1.00','2025-11-15 05:58:32','4'),
('4','3','5','1.00','2025-11-15 05:58:32','2'),
('5','5','4','1.00','2025-11-15 06:27:38','4'),
('6','5','11','1.00','2025-11-15 06:27:38','8'),
('7','5','12','0.20','2025-11-15 06:27:38','3'),
('8','6','15','1.00','2025-11-15 07:44:33','4'),
('9','6','16','1.00','2025-11-15 07:44:33','7'),
('10','7','15','1.00','2025-11-15 07:44:53','4'),
('11','7','18','1.00','2025-11-15 07:44:53','6'),
('12','8','20','1.00','2025-11-15 09:26:08','4'),
('13','8','12','0.20','2025-11-15 09:26:08','3'),
('14','8','21','0.80','2025-11-15 09:26:08','5');

-- هيكل الجدول `production_monthly_report_logs`
DROP TABLE IF EXISTS `production_monthly_report_logs`;
CREATE TABLE `production_monthly_report_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_key` varchar(7) NOT NULL,
  `month_number` tinyint(2) NOT NULL,
  `year_number` smallint(4) NOT NULL,
  `sent_via` varchar(40) NOT NULL DEFAULT 'telegram_auto',
  `triggered_by` int(11) DEFAULT NULL,
  `report_snapshot` longtext DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `production_monthly_report_logs_unique` (`month_key`,`sent_via`),
  KEY `production_monthly_report_logs_month_idx` (`month_number`,`year_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production_monthly_report_logs`
-- لا توجد بيانات في الجدول `production_monthly_report_logs`

-- هيكل الجدول `production_supply_logs`
DROP TABLE IF EXISTS `production_supply_logs`;
CREATE TABLE `production_supply_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_category` varchar(50) NOT NULL,
  `material_label` varchar(190) DEFAULT NULL,
  `stock_source` varchar(80) DEFAULT NULL,
  `stock_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `supplier_name` varchar(190) DEFAULT NULL,
  `quantity` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unit` varchar(20) DEFAULT 'كجم',
  `details` text DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `production_supply_logs_category_date_idx` (`material_category`,`recorded_at`),
  KEY `production_supply_logs_supplier_idx` (`supplier_id`),
  KEY `production_supply_logs_recorded_at_idx` (`recorded_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `production_supply_logs`
INSERT INTO `production_supply_logs` (`id`, `material_category`, `material_label`, `stock_source`, `stock_id`, `supplier_id`, `supplier_name`, `quantity`, `unit`, `details`, `recorded_by`, `recorded_at`) VALUES
('1','honey','سدر - KI002','honey_stock','2','2','عمرو','2.000','كجم','إضافة سدر (سدر - KI002) - الحالة: عسل مصفى','4','2025-11-13 17:15:48'),
('2','honey','موالح - KI004','honey_stock','4','2','عمرو','1.000','كجم','إضافة موالح (موالح - KI004) - الحالة: عسل مصفى','4','2025-11-14 02:19:50');

-- هيكل الجدول `products`
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `product_type` enum('internal','external') DEFAULT 'internal',
  `external_channel` enum('company','delegate','other') DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(20) DEFAULT 'piece',
  `min_stock` decimal(10,2) DEFAULT 0.00,
  `min_stock_level` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `category` (`category`),
  KEY `warehouse_id` (`warehouse_id`),
  CONSTRAINT `products_ibfk_warehouse` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `products`
INSERT INTO `products` (`id`, `name`, `description`, `category`, `product_type`, `external_channel`, `warehouse_id`, `unit_price`, `quantity`, `unit`, `min_stock`, `min_stock_level`, `status`, `created_at`, `updated_at`) VALUES
('4','ملصق صغير',NULL,'packaging','internal',NULL,'2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-15 05:58:14','2025-11-15 06:06:34'),
('5','عسل - سدر',NULL,'raw_material','internal',NULL,'2','0.00','0.00','كيلوجرام','0.00','0.00','active','2025-11-15 05:58:14','2025-11-15 06:06:34'),
('6','منتج رقم 3',NULL,'finished','internal',NULL,'2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-15 05:58:14','2025-11-15 06:06:34'),
('7','منتج رقم 3',NULL,'finished','internal',NULL,'2','0.00','1.00','قطعة','0.00','0.00','active','2025-11-15 05:58:32','2025-11-18 16:36:19'),
('11','شمع',NULL,'raw_material','internal',NULL,'2','0.00','0.00','كيلوجرام','0.00','0.00','active','2025-11-15 06:27:38','2025-11-15 06:50:00'),
('12','عسل - حبة البركة',NULL,'raw_material','internal',NULL,'2','0.00','0.00','كيلوجرام','0.00','0.00','active','2025-11-15 06:27:38','2025-11-15 06:50:00'),
('13','منتج رقم 4',NULL,'finished','internal',NULL,'2','0.00','2.00','قطعة','0.00','0.00','active','2025-11-15 06:27:38','2025-11-18 13:07:21'),
('14','شمع عسل 1 ك','تم إنشاؤه تلقائياً من تشغيلات الإنتاج','منتجات نهائية','internal',NULL,'2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-15 07:37:55','2025-11-15 07:37:57'),
('15','ملصق كبير',NULL,'packaging','internal',NULL,'2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-15 07:44:33','2025-11-15 07:51:06'),
('16','مشتقات - غذاء ملكات',NULL,'raw_material','internal',NULL,'2','0.00','0.00','كيلوجرام','0.00','0.00','active','2025-11-15 07:44:33','2025-11-15 07:51:06'),
('17','منتج رقم 7',NULL,'finished','internal',NULL,'2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-15 07:44:33','2025-11-15 07:51:06'),
('18','زيت زيتون',NULL,'raw_material','internal',NULL,'2','0.00','0.00','كيلوجرام','0.00','0.00','active','2025-11-15 07:44:53','2025-11-15 07:51:06'),
('19','منتج رقم 6',NULL,'finished','internal',NULL,'2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-15 07:44:53','2025-11-15 07:51:06'),
('20','ملصق وسط',NULL,'packaging','internal',NULL,'2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-15 09:26:08','2025-11-15 09:26:32'),
('21','مكسرات - تشكيله 2',NULL,'raw_material','internal',NULL,'2','0.00','0.00','كيلوجرام','0.00','0.00','active','2025-11-15 09:26:08','2025-11-15 09:26:32'),
('22','منتج رقم 8',NULL,'finished','internal',NULL,'2','0.00','2.00','قطعة','0.00','0.00','active','2025-11-15 09:26:08','2025-11-18 11:40:14'),
('23','زيت زيتون كيلو','تم إنشاؤه تلقائياً من تشغيلات الإنتاج','منتجات نهائية','internal',NULL,'2','0.00','0.00','قطعة','0.00','0.00','active','2025-11-15 18:18:39','2025-11-15 18:18:40'),
('24','صابون كبير',NULL,'منتجات خارجية','external',NULL,'2','20.00','4.00','قطعة','0.00','0.00','active','2025-11-17 08:55:05','2025-11-18 16:49:22'),
('25','صابون وسط',NULL,'منتجات خارجية','external',NULL,NULL,'10.00','10.00','قطعة','0.00','0.00','active','2025-11-17 08:55:17',NULL);

-- هيكل الجدول `raw_material_damage_logs`
DROP TABLE IF EXISTS `raw_material_damage_logs`;
CREATE TABLE `raw_material_damage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_category` varchar(50) NOT NULL COMMENT 'نوع الخام (honey, olive_oil, beeswax, derivatives, nuts)',
  `stock_id` int(11) DEFAULT NULL COMMENT 'معرف السجل في جدول المخزون',
  `supplier_id` int(11) DEFAULT NULL COMMENT 'المورد المرتبط',
  `item_label` varchar(255) NOT NULL COMMENT 'اسم المادة التالفة',
  `variety` varchar(255) DEFAULT NULL COMMENT 'النوع/الصنف (اختياري)',
  `quantity` decimal(12,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية التالفة',
  `unit` varchar(20) NOT NULL DEFAULT 'كجم' COMMENT 'وحدة القياس',
  `reason` text DEFAULT NULL COMMENT 'سبب التلف',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `material_category` (`material_category`),
  KEY `created_by` (`created_by`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `raw_material_damage_logs`
INSERT INTO `raw_material_damage_logs` (`id`, `material_category`, `stock_id`, `supplier_id`, `item_label`, `variety`, `quantity`, `unit`, `reason`, `created_by`, `created_at`) VALUES
('1','honey','2','2','عسل مصفى','سدر','1.000','كجم','1','4','2025-11-15 06:31:42');

-- هيكل الجدول `reader_access_log`
DROP TABLE IF EXISTS `reader_access_log`;
CREATE TABLE `reader_access_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `status` enum('success','not_found','error','rate_limited','invalid') NOT NULL DEFAULT 'success',
  `message` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `reader_access_log`
INSERT INTO `reader_access_log` (`id`, `session_id`, `ip_address`, `batch_number`, `status`, `message`, `created_at`) VALUES
('1','bedc31d0c650d1dd5bf240b4837909e3','154.237.71.93','251115','not_found','رقم التشغيلة غير موجود.','2025-11-15 06:02:28'),
('2','bedc31d0c650d1dd5bf240b4837909e3','154.237.71.93','LLLRILEL','not_found','رقم التشغيلة غير موجود.','2025-11-15 06:02:37'),
('3','bedc31d0c650d1dd5bf240b4837909e3','154.237.71.93','LLLRILEL','not_found','رقم التشغيلة غير موجود.','2025-11-15 06:02:39'),
('4','bedc31d0c650d1dd5bf240b4837909e3','154.237.71.93','251115-238486','success','نجاح الاستعلام.','2025-11-15 06:02:43'),
('5','bedc31d0c650d1dd5bf240b4837909e3','154.237.71.93','251115-238486','success','نجاح الاستعلام.','2025-11-15 06:02:46'),
('6','bedc31d0c650d1dd5bf240b4837909e3','154.237.71.93','251115-238486','success','نجاح الاستعلام.','2025-11-15 06:03:10'),
('7','f4e9f71e9654af7eec00c7ca22a2be2a','154.237.71.93','LLLLLLLLLL','not_found','رقم التشغيلة غير موجود.','2025-11-15 06:51:33'),
('8','f4e9f71e9654af7eec00c7ca22a2be2a','154.237.71.93','251115-058200','success','نجاح الاستعلام.','2025-11-15 06:51:39'),
('9','f4e9f71e9654af7eec00c7ca22a2be2a','154.237.71.93','251115-058200','success','نجاح الاستعلام.','2025-11-15 06:51:44'),
('10','a6d6663e7f3b13eb01fc12160453a00a','41.199.182.205','251115-936155','success','نجاح الاستعلام.','2025-11-18 14:29:47');

-- هيكل الجدول `remember_tokens`
DROP TABLE IF EXISTS `remember_tokens`;
CREATE TABLE `remember_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_used` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_token` (`user_id`,`token`),
  KEY `token` (`token`),
  KEY `expires_at` (`expires_at`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `remember_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `remember_tokens`
-- لا توجد بيانات في الجدول `remember_tokens`

-- هيكل الجدول `reports`
DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `filters` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_type` enum('pdf','excel','csv') DEFAULT 'pdf',
  `telegram_sent` tinyint(1) DEFAULT 0,
  `status` enum('pending','generated','sent','deleted') DEFAULT 'pending',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `reports`
-- لا توجد بيانات في الجدول `reports`

-- هيكل الجدول `request_usage`
DROP TABLE IF EXISTS `request_usage`;
CREATE TABLE `request_usage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `method` varchar(10) NOT NULL,
  `path` text DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`,`created_at`),
  KEY `idx_ip_date` (`ip_address`,`created_at`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=812 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `request_usage`
INSERT INTO `request_usage` (`id`, `user_id`, `ip_address`, `method`, `path`, `user_agent`, `created_at`) VALUES
('712','1','41.199.14.46','GET','/v1/dashboard/manager.php?page=warehouse_transfers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:19'),
('713','1','41.199.14.46','GET','/v1/dashboard/manager.php?page=warehouse_transfers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:23'),
('714','1','41.199.14.46','GET','/v1/dashboard/manager.php?page=company_products','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:23'),
('715','1','41.199.14.46','GET','/v1/dashboard/manager.php?page=company_products','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:36:25'),
('716','1','41.199.14.46','GET','/v1/print_transfer_invoice.php?id=43&i=1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0','2025-11-18 16:41:13'),
('717','1','41.199.14.46','GET','/v1/print_transfer_invoice.php?id=43&print=1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0','2025-11-18 16:41:33'),
('718','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:43:44'),
('719','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=batch_reader&i=1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:47:12'),
('720','3','41.199.14.46','GET','/v1/reader/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:47:13'),
('721','3','41.199.14.46','GET','/v1/reader/','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:47:13'),
('722','3','41.199.14.46','GET','/v1/reader/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:47:13'),
('723','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=my_salary','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:47:15'),
('724','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:48:23'),
('725','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&section=company&action=purchase_history&ajax=purchase_history&customer_id=4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:48:37'),
('726','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=vehicle_inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:48:46'),
('727','1','41.199.14.46','GET','/v1/dashboard/manager.php?page=warehouse_transfers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:09'),
('728','1','41.199.14.46','POST','/v1/dashboard/manager.php?page=warehouse_transfers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:22'),
('729','1','41.199.14.46','GET','/v1/dashboard/manager.php?page=warehouse_transfers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:22'),
('730','1','41.199.14.46','GET','/v1/dashboard/manager.php?page=warehouse_transfers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:26'),
('731','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=vehicle_inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:26'),
('732','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:39'),
('733','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=attendance','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:41'),
('734','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:43'),
('735','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:43'),
('736','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=attendance','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:49'),
('737','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:52'),
('738','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=attendance','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:49:57'),
('739','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:50:01'),
('740','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=attendance','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:50:07'),
('741','3','41.199.14.46','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:50:28'),
('742','3','41.199.14.46','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:57:55'),
('743','3','41.199.14.46','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:58:05'),
('744','3','41.199.14.46','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:58:28'),
('745','3','41.199.14.46','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:58:39'),
('746','3','41.199.14.46','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:58:43'),
('747','3','41.199.14.46','GET','/v1/attendance.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 16:59:26'),
('748','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=my_salary','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:00:11'),
('749','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:00:22'),
('750','3','41.199.14.46','POST','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:00:54'),
('751','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:00:57'),
('752','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:07:59'),
('753','3','41.199.14.46','POST','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:08:38'),
('754','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:08:42'),
('755','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:08:58'),
('756','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:08:59'),
('757','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:09:00'),
('758','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:09:00'),
('759','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:09:00'),
('760','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:09:00'),
('761','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:13:23'),
('762','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:38:31'),
('763','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:41:22'),
('764','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=sales_collections','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 17:41:32'),
('765','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=sales_collections','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:12:06'),
('766','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:12:11'),
('767','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:12:13'),
('768','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:12:14'),
('769','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:12:16'),
('770','1','41.199.14.46','GET','/v1/print_transfer_invoice.php?id=44','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0','2025-11-18 18:12:36'),
('771','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:29:11'),
('772','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:34:38'),
('773','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:35:29'),
('774','3','41.199.14.46','GET','/v1/dashboard/sales.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:35:42'),
('775','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:52:41'),
('776','3','41.199.14.46','POST','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:58:59'),
('777','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&amp;section=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:59:00'),
('778','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&amp%3Bsection=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:59:03'),
('779','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=cash_register','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:59:05'),
('780','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=cash_register','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:59:21'),
('781','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=cash_register','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 18:59:24'),
('782','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=sales_collections','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:01:46'),
('783','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=sales_collections&id=2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:01:51'),
('784','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:03:52'),
('785','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:03:57'),
('786','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:04:10'),
('787','3','41.199.14.46','POST','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:04:42'),
('788','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&amp;section=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:04:42'),
('789','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&amp%3Bsection=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:04:47'),
('790','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&amp%3Bsection=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:07:26'),
('791','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=sales_collections','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:07:33'),
('792','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:07:50'),
('793','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&section=company&action=purchase_history&ajax=purchase_history&customer_id=8','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:07:59'),
('794','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&section=company&action=purchase_history&ajax=purchase_history&customer_id=4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:08:03'),
('795','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=sales_collections','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:08:23'),
('796','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=orders','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:08:38'),
('797','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=payment_schedules','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:09:20'),
('798','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=vehicle_inventory','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:09:25'),
('799','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:09:29'),
('800','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:17:21'),
('801','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:17:41'),
('802','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:19:56'),
('803','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:20:07'),
('804','3','41.199.14.46','POST','/v1/dashboard/sales.php?page=customers','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:20:30'),
('805','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&amp;section=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:20:31'),
('806','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&amp%3Bsection=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:20:35'),
('807','3','41.199.14.46','POST','/v1/dashboard/sales.php?page=customers&amp%3Bsection=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:21:48'),
('808','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=customers&amp%3Bsection=company','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:21:52'),
('809','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:22:28'),
('810','3','41.199.14.46','POST','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:23:00'),
('811','3','41.199.14.46','GET','/v1/dashboard/sales.php?page=pos','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-18 19:23:05');

-- هيكل الجدول `request_usage_alerts`
DROP TABLE IF EXISTS `request_usage_alerts`;
CREATE TABLE `request_usage_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier_type` enum('user','ip') NOT NULL,
  `identifier_value` varchar(255) NOT NULL,
  `window_start` datetime NOT NULL,
  `window_end` datetime NOT NULL,
  `request_count` int(11) NOT NULL,
  `threshold` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_identifier_window` (`identifier_type`,`identifier_value`,`window_start`,`window_end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `request_usage_alerts`
-- لا توجد بيانات في الجدول `request_usage_alerts`

-- هيكل الجدول `return_items`
DROP TABLE IF EXISTS `return_items`;
CREATE TABLE `return_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `condition` enum('new','used','damaged','defective') DEFAULT 'new',
  `batch_number_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `return_id` (`return_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `return_items_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `sales_returns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `return_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `return_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `return_items`
-- لا توجد بيانات في الجدول `return_items`

-- هيكل الجدول `returns`
DROP TABLE IF EXISTS `returns`;
CREATE TABLE `returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_number` varchar(50) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `return_date` date NOT NULL,
  `return_type` enum('full','partial') DEFAULT 'full',
  `reason` enum('defective','wrong_item','customer_request','other') DEFAULT 'customer_request',
  `reason_description` text DEFAULT NULL,
  `refund_amount` decimal(15,2) DEFAULT 0.00,
  `refund_method` enum('cash','credit','exchange') DEFAULT 'cash',
  `status` enum('pending','approved','rejected','processed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `return_date` (`return_date`),
  KEY `status` (`status`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `returns`
-- لا توجد بيانات في الجدول `returns`

-- هيكل الجدول `role_permissions`
DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` enum('manager','accountant','sales','production') NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_permission` (`role`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `role_permissions`
-- لا توجد بيانات في الجدول `role_permissions`

-- هيكل الجدول `salaries`
DROP TABLE IF EXISTS `salaries`;
CREATE TABLE `salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `month` date NOT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `base_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `bonuses` decimal(15,2) DEFAULT 0.00,
  `deductions` decimal(15,2) DEFAULT 0.00,
  `advances_deduction` decimal(10,2) DEFAULT 0.00 COMMENT 'خصم السلف',
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','approved','paid') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `month` (`month`),
  KEY `status` (`status`),
  KEY `salaries_ibfk_2` (`approved_by`),
  KEY `salaries_ibfk_3` (`created_by`),
  CONSTRAINT `salaries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salaries_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salaries_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `salaries`
INSERT INTO `salaries` (`id`, `user_id`, `month`, `hourly_rate`, `total_hours`, `base_amount`, `bonuses`, `deductions`, `advances_deduction`, `total_amount`, `status`, `approved_by`, `paid_at`, `created_by`, `created_at`) VALUES
('13','3','2025-11-01','15.00','0.12','1.80','0.00','0.90','0.90','0.90','pending',NULL,NULL,'1','2025-11-14 20:03:57');

-- هيكل الجدول `salary_advances`
DROP TABLE IF EXISTS `salary_advances`;
CREATE TABLE `salary_advances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'الموظف',
  `amount` decimal(10,2) NOT NULL COMMENT 'مبلغ السلفة',
  `reason` text DEFAULT NULL COMMENT 'سبب السلفة',
  `request_date` date NOT NULL COMMENT 'تاريخ الطلب',
  `status` enum('pending','accountant_approved','manager_approved','rejected') DEFAULT 'pending' COMMENT 'حالة الطلب',
  `accountant_approved_by` int(11) DEFAULT NULL,
  `accountant_approved_at` timestamp NULL DEFAULT NULL,
  `manager_approved_by` int(11) DEFAULT NULL,
  `manager_approved_at` timestamp NULL DEFAULT NULL,
  `deducted_from_salary_id` int(11) DEFAULT NULL COMMENT 'الراتب الذي تم خصم السلفة منه',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `request_date` (`request_date`),
  KEY `accountant_approved_by` (`accountant_approved_by`),
  KEY `manager_approved_by` (`manager_approved_by`),
  KEY `deducted_from_salary_id` (`deducted_from_salary_id`),
  CONSTRAINT `salary_advances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_advances_ibfk_2` FOREIGN KEY (`accountant_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salary_advances_ibfk_3` FOREIGN KEY (`manager_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salary_advances_ibfk_4` FOREIGN KEY (`deducted_from_salary_id`) REFERENCES `salaries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `salary_advances`
INSERT INTO `salary_advances` (`id`, `user_id`, `amount`, `reason`, `request_date`, `status`, `accountant_approved_by`, `accountant_approved_at`, `manager_approved_by`, `manager_approved_at`, `deducted_from_salary_id`, `notes`, `created_at`) VALUES
('2','3','0.90',NULL,'2025-11-14','manager_approved','2','2025-11-14 19:44:41','1','2025-11-14 20:03:57','13',NULL,'2025-11-14 19:43:50');

-- هيكل الجدول `sales`
DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `date` date NOT NULL,
  `salesperson_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `product_id` (`product_id`),
  KEY `salesperson_id` (`salesperson_id`),
  KEY `approved_by` (`approved_by`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`salesperson_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `sales`
INSERT INTO `sales` (`id`, `customer_id`, `product_id`, `quantity`, `price`, `total`, `date`, `salesperson_id`, `status`, `approved_by`, `approved_at`, `created_at`) VALUES
('1','4','17','1.00','500.00','500.00','2025-11-17','3','completed',NULL,NULL,'2025-11-17 06:37:09'),
('2','4','19','1.00','200.00','200.00','2025-11-17','3','completed',NULL,NULL,'2025-11-17 07:28:34'),
('3','10','24','10.00','20.00','200.00','2025-11-18','3','completed',NULL,NULL,'2025-11-18 19:23:00');

-- هيكل الجدول `sales_batch_numbers`
DROP TABLE IF EXISTS `sales_batch_numbers`;
CREATE TABLE `sales_batch_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `invoice_item_id` int(11) DEFAULT NULL,
  `batch_number_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_item_id` (`invoice_item_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `sales_batch_numbers_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_batch_numbers_ibfk_2` FOREIGN KEY (`invoice_item_id`) REFERENCES `invoice_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_batch_numbers_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `sales_batch_numbers`
-- لا توجد بيانات في الجدول `sales_batch_numbers`

-- هيكل الجدول `sales_returns`
DROP TABLE IF EXISTS `sales_returns`;
CREATE TABLE `sales_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_number` varchar(50) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `return_type` enum('full','partial') DEFAULT 'full',
  `reason` enum('defective','wrong_item','customer_request','other') DEFAULT 'customer_request',
  `reason_description` text DEFAULT NULL,
  `refund_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `refund_method` enum('cash','credit','exchange') DEFAULT 'cash',
  `status` enum('pending','approved','rejected','processed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `invoice_id` (`invoice_id`),
  KEY `sale_id` (`sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `status` (`status`),
  KEY `sales_returns_ibfk_5` (`approved_by`),
  KEY `sales_returns_ibfk_6` (`processed_by`),
  KEY `sales_returns_ibfk_7` (`created_by`),
  CONSTRAINT `sales_returns_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_returns_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_returns_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_6` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `sales_returns`
-- لا توجد بيانات في الجدول `sales_returns`

-- هيكل الجدول `sesame_stock`
DROP TABLE IF EXISTS `sesame_stock`;
CREATE TABLE `sesame_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالكيلوجرام',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT 'سعر الكيلو',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`),
  CONSTRAINT `sesame_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `sesame_stock`
-- لا توجد بيانات في الجدول `sesame_stock`

-- هيكل الجدول `supplier_balance_history`
DROP TABLE IF EXISTS `supplier_balance_history`;
CREATE TABLE `supplier_balance_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `change_amount` decimal(15,2) NOT NULL,
  `previous_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `new_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `type` enum('topup','payment') NOT NULL,
  `notes` text DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL COMMENT 'ID of related record (financial transaction, etc)',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  KEY `type` (`type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `supplier_balance_history_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_balance_history_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `supplier_balance_history`
-- لا توجد بيانات في الجدول `supplier_balance_history`

-- هيكل الجدول `suppliers`
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(20) DEFAULT NULL,
  `type` enum('honey','packaging','nuts','olive_oil','derivatives','beeswax','sesame') DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `suppliers`
INSERT INTO `suppliers` (`id`, `supplier_code`, `type`, `name`, `contact_person`, `phone`, `email`, `address`, `balance`, `status`, `created_at`, `updated_at`) VALUES
('2','HNY001','honey','عمرو',NULL,NULL,NULL,NULL,'0.00','active','2025-11-06 09:28:16',NULL),
('3','HNY002','honey','مايكل',NULL,NULL,NULL,NULL,'0.00','active','2025-11-06 09:32:03',NULL),
('4','PKG001','packaging','تعبئه',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:56:26',NULL),
('5','NUT001','nuts','مكسرات',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:56:43',NULL),
('6','OIL001','olive_oil','زيت زيتون',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:57:15',NULL),
('7','DRV001','derivatives','مشتقات',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:57:25',NULL),
('8','WAX001','beeswax','شمع',NULL,NULL,NULL,NULL,'0.00','active','2025-11-08 01:57:35',NULL);

-- هيكل الجدول `system_daily_jobs`
DROP TABLE IF EXISTS `system_daily_jobs`;
CREATE TABLE `system_daily_jobs` (
  `job_key` varchar(120) NOT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `last_notified_at` datetime DEFAULT NULL,
  `last_notification_hash` varchar(128) DEFAULT NULL,
  `last_file_path` varchar(512) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`job_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `system_daily_jobs`
INSERT INTO `system_daily_jobs` (`job_key`, `last_sent_at`, `last_notified_at`, `last_notification_hash`, `last_file_path`, `updated_at`) VALUES
('daily_backup_telegram','2025-11-18 00:25:43',NULL,NULL,'backup_if0_40278066_co_db_2025-11-18_00-25-43.sql.gz','2025-11-19 01:09:20'),
('daily_consumption_report','2025-11-09 05:02:41',NULL,NULL,'','2025-11-09 07:10:49'),
('low_stock_report','2025-11-19 01:09:20',NULL,NULL,'low_stock/low-stock-report-20251119-010921.html','2025-11-19 01:09:20'),
('packaging_low_stock_alert','2025-11-18 00:26:36',NULL,NULL,NULL,'2025-11-18 00:26:36');

-- هيكل الجدول `system_scheduled_jobs`
DROP TABLE IF EXISTS `system_scheduled_jobs`;
CREATE TABLE `system_scheduled_jobs` (
  `job_key` varchar(120) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`job_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `system_scheduled_jobs`
INSERT INTO `system_scheduled_jobs` (`job_key`, `scheduled_at`, `executed_at`, `updated_at`) VALUES
('daily_backup_delivery','2025-11-09 05:31:37',NULL,'2025-11-09 07:30:07'),
('daily_consumption_report','2025-11-09 05:30:47',NULL,'2025-11-09 07:30:07'),
('daily_low_stock_report','2025-11-09 05:30:12',NULL,'2025-11-09 07:30:07'),
('daily_packaging_alert','2025-11-09 05:30:27',NULL,'2025-11-09 07:30:07');

-- هيكل الجدول `system_settings`
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=66885 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `system_settings`
INSERT INTO `system_settings` (`id`, `key`, `value`, `description`, `updated_at`) VALUES
('1','currency','جنيه',NULL,NULL),
('2','currency_symbol','ج.م',NULL,NULL),
('3','timezone','Africa/Cairo',NULL,NULL),
('4','company_name','شركة البركه',NULL,NULL),
('5','company_address','',NULL,NULL),
('6','company_phone','',NULL,NULL),
('7','company_email','',NULL,NULL),
('8','telegram_bot_token','',NULL,NULL),
('9','telegram_chat_id','',NULL,NULL),
('11','low_stock_report_status','{\"date\":\"2025-11-19\",\"status\":\"completed\",\"completed_at\":\"2025-11-19 01:09:21\",\"counts\":{\"honey\":0,\"olive_oil\":0,\"beeswax\":0,\"derivatives\":0,\"nuts\":3},\"file_deleted\":false,\"report_path\":\"low_stock/low-stock-report-20251119-010921.html\",\"viewer_path\":\"reports/view.php?type=low_stock&token=d661276f5d6dde6c9993193d7c67967d\",\"access_token\":\"d661276f5d6dde6c9993193d7c67967d\",\"report_url\":\"/v1/reports/view.php?type=low_stock&token=d661276f5d6dde6c9993193d7c67967d\",\"print_url\":\"/v1/reports/view.php?type=low_stock&token=d661276f5d6dde6c9993193d7c67967d&print=1\",\"absolute_report_url\":\"https://demo-system.rf.gd/v1/reports/view.php?type=low_stock&token=d661276f5d6dde6c9993193d7c67967d\",\"absolute_print_url\":\"https://demo-system.rf.gd/v1/reports/view.php?type=low_stock&token=d661276f5d6dde6c9993193d7c67967d&print=1\"}',NULL,'2025-11-19 01:09:20'),
('12','daily_backup_status','{\"date\":\"2025-11-19\",\"status\":\"running\",\"checked_at\":\"2025-11-19 01:09:21\",\"started_at\":\"2025-11-19 01:09:21\"}',NULL,'2025-11-19 01:09:20'),
('180','daily_consumption_report_status','{\"date\":\"2025-11-09\",\"target_date\":\"2025-11-08\",\"status\":\"already_sent\",\"checked_at\":\"2025-11-09 05:45:53\",\"last_sent_at\":\"2025-11-09 05:02:41\"}',NULL,'2025-11-09 07:45:53'),
('661','packaging_alert_status','{\"date\":\"2025-11-18\",\"status\":\"already_sent\",\"completed_at\":\"2025-11-18 00:26:36\",\"counts\":{\"total_items\":39,\"by_type\":{\"أغطية\":8,\"أكياس\":1,\"صناديق كرتون\":2,\"طبات\":5,\"عبوات بلاستيكية\":8,\"عبوات زجاجية\":11,\"لوازم التعبئة\":3,\"ملصقات\":1}},\"preview\":[],\"report_path\":\"alerts/packaging-low-stock-20251118-002636.html\",\"viewer_path\":\"reports/view.php?type=packaging&token=5131ec6aa4f7251c111e84c816e56bf6\",\"access_token\":\"5131ec6aa4f7251c111e84c816e56bf6\",\"report_url\":\"/v1/reports/view.php?type=packaging&token=5131ec6aa4f7251c111e84c816e56bf6\",\"print_url\":\"/v1/reports/view.php?type=packaging&token=5131ec6aa4f7251c111e84c816e56bf6&print=1\",\"absolute_report_url\":\"https://demo-system.rf.gd/v1/reports/view.php?type=packaging&token=5131ec6aa4f7251c111e84c816e56bf6\",\"absolute_print_url\":\"https://demo-system.rf.gd/v1/reports/view.php?type=packaging&token=5131ec6aa4f7251c111e84c816e56bf6&print=1\",\"file_deleted\":false,\"checked_at\":\"2025-11-18 19:23:05\",\"last_sent_at\":\"2025-11-18 00:26:36\"}',NULL,'2025-11-18 19:23:05');

-- هيكل الجدول `tasks`
DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `status` enum('pending','received','in_progress','completed','cancelled') DEFAULT 'pending',
  `due_date` date DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `received_at` timestamp NULL DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `related_type` varchar(50) DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `due_date` (`due_date`),
  KEY `tasks_ibfk_3` (`product_id`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `tasks`
INSERT INTO `tasks` (`id`, `title`, `description`, `assigned_to`, `created_by`, `priority`, `status`, `due_date`, `completed_at`, `received_at`, `started_at`, `related_type`, `related_id`, `product_id`, `quantity`, `notes`, `created_at`, `updated_at`) VALUES
('6','0','00','4','1','urgent','completed','2025-11-14','2025-11-14 18:48:38','2025-11-14 18:47:20','2025-11-14 18:48:08','manager_production',NULL,NULL,NULL,NULL,'2025-11-14 18:46:22','2025-11-14 18:48:38'),
('7','0','00','4','1','urgent','cancelled','2025-11-14',NULL,NULL,NULL,'manager_production',NULL,NULL,NULL,NULL,'2025-11-14 18:47:30','2025-11-14 18:47:48');

-- هيكل الجدول `unified_product_templates`
DROP TABLE IF EXISTS `unified_product_templates`;
CREATE TABLE `unified_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL COMMENT 'اسم المنتج',
  `created_by` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `main_supplier_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `form_payload` longtext DEFAULT NULL COMMENT 'JSON يحتوي جميع مدخلات النموذج',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `main_supplier_id` (`main_supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `unified_product_templates`
-- لا توجد بيانات في الجدول `unified_product_templates`

-- هيكل الجدول `user_permissions`
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `granted` tinyint(1) DEFAULT 1,
  `granted_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permission` (`user_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  KEY `granted_by` (`granted_by`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_3` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `user_permissions`
INSERT INTO `user_permissions` (`id`, `user_id`, `permission_id`, `granted`, `granted_by`, `created_at`) VALUES
('1','2','3','0','1','2025-11-05 18:42:02'),
('2','2','2','0','1','2025-11-05 23:17:09'),
('3','2','1','0','1','2025-11-05 23:17:10'),
('4','3','3','0','1','2025-11-06 07:39:42'),
('5','3','2','1','1','2025-11-06 07:39:52'),
('6','3','12','1','1','2025-11-06 07:40:09'),
('7','3','6','1','1','2025-11-06 07:40:13'),
('8','3','5','1','1','2025-11-06 07:40:18'),
('9','3','4','1','1','2025-11-06 07:40:24');

-- هيكل الجدول `user_status`
DROP TABLE IF EXISTS `user_status`;
CREATE TABLE `user_status` (
  `user_id` int(11) NOT NULL,
  `last_seen` datetime NOT NULL DEFAULT current_timestamp(),
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_status_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `user_status`
INSERT INTO `user_status` (`user_id`, `last_seen`, `is_online`) VALUES
('1','2025-11-18 14:18:41','1'),
('3','2025-11-18 10:48:16','1'),
('4','2025-11-17 04:22:26','1');

-- هيكل الجدول `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `role` enum('accountant','sales','production','manager') NOT NULL,
  `webauthn_enabled` tinyint(1) DEFAULT 0,
  `full_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `profile_photo` longtext DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `warning_count` int(11) DEFAULT 0,
  `delay_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `users`
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `webauthn_enabled`, `full_name`, `phone`, `profile_photo`, `hourly_rate`, `status`, `warning_count`, `delay_count`, `created_at`, `updated_at`) VALUES
('1','admin','admin@company.com','$2y$10$cIXyIRjYeF.YHoKQfUIgluq8mWJ.qNlvr7iz0c1QcWbRrdI0yqNHS','manager','1','المدير العام','01000000004',NULL,'0.00','active','0','0','2025-11-04 08:14:12','2025-11-14 18:35:24'),
('2','a','accountant@company.com','$2y$10$uX9v.mRKgvVCXWEDfnPwHebLdTviE/T6xUChWUBYtyruZ5GwtIKN2','accountant','0','المحاسب الأول','',NULL,'25.00','active','0','0','2025-11-04 08:14:12','2025-11-16 01:32:27'),
('3','s','sales@company.com','$2y$10$DiSgJlH7fcYF3s4xxz9fRODANfMPzbtzwyoncher65zH1NRq1.C06','sales','1','مندوب اسامه','',NULL,'15.00','active','0','2','2025-11-04 08:14:12','2025-11-14 19:35:48'),
('4','p','production@company.com','$2y$10$91kPMaWrc859vTduCzBvNeoTwDRhn5G.MW0Xkt03EfPxI0btk7zaS','production','1','عامل الإنتاج الأول','01000000001',NULL,'20.00','active','0','7','2025-11-04 08:14:12','2025-11-14 19:23:28'),
('6','1','osama@co.co','$2y$10$i1WbOh67VWpXu6yo6hWuB.2svIcpwCYSeSAQRPsjSKCgTPAt5FMLy','manager','1','Osama s','0000000000','data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QDsRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAC5ADAAIAAAAUAAAApJAEAAIAAAAUAAAAuJAQAAIAAAAHAAAAzJARAAIAAAAHAAAA1JASAAIAAAAHAAAA3JKQAAIAAAAEMDAwAJKRAAIAAAAEMDAwAJKSAAIAAAAEMDAwAKABAAMAAAABAAEAAKACAAQAAAABAAACOaADAAQAAAABAAACOQAAAAAyMDI1OjEwOjI5IDA1OjQ0OjE2ADIwMjU6MTA6MjkgMDU6NDQ6MTYAKzAzOjAwAAArMDM6MDAAACswMzowMAAA/+0AfFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAABEHAFaAAMbJUccAgAAAgACHAI/AAYwNTQ0MTYcAj4ACDIwMjUxMDI5HAI3AAgyMDI1MTAyORwCPAALMDU0NDE2KzAzMDA4QklNBCUAAAAAABBRJgNzu38/WOObdmjaINW//8AAEQgCOQI5AwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAgICAgICAwICAwUDAwMFBgUFBQUGCAYGBgYGCAoICAgICAgKCgoKCgoKCgwMDAwMDA4ODg4ODw8PDw8PDw8PD//bAEMBAgMDBAQEBwQEBxALCQsQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEP/dAAQAJP/aAAwDAQACEQMRAD8A+yESpF+/QlSIlf5vn9GFipEqPZUiJQEyRKKKkRN1ZnOSQ/dqSo0TbVhE3UAKn3KfQny1IlAAiVJQlSIm6gxmKn3KfQny0UGJIlFFSIm9aABEqwiUIlSUAGyhEqRE3VIny0GYJ8tFFFABUlFFABUmyhEqTZRMCNEqTZUiJUmyucCNEqTZRRQAbKESpNlFXAiYbKNlFFEzLnDZRsooogHOGyo9lSUUTDnI9lFSUVAc5HRsqTZRsoNYFeo3TdVh0o2UFlfZUbpVio3TdWgEeyo6kf5aKzAjqOpKKuAEdRum6pKK1ArulR1Yb79R0AV2+/UdWHSq7/LQaEbpUdWKjegCu6bqjdKsVG6bqAK7pUdWHSo3Sg2gV3TdUb/LVio2+/QbFd03VG6basVBN96gCKo3SpKjegCu336jqw6b2qPZWhcCu9R1I/zUbKDU/9D7MSrCJsWo0qwlf5vn9B85IlSJUaVJQahViH7tRom6pETbWZmSVKn3KRE3VIny0AFSIlCVIlBjMESrCfLTE+5T6DEKkRKEqRKADZUqfcpETdUiJQBIlSIm6o0SrCfLQZgny0UUUTAKkRKESpKy5wDZQiVIibqkT5aOcARKk2UJRTImFFSbKKzMucNlFFFAc4UVIibqNlAEdSIm6jZUifLWhmR7KNlSUVmBHso2VY2VHWgFd/loqR03UbKzNCOipNlRv8tABRsoooDnI3SjZUlGyg1gV3So9lWHSo6Cyu6VHVh03VG6UAR1HUlFXACu6bqjf5asVG6bq1AjqN0qR/lqN6AK7/LUb1Yb79R0GhXoqR0qOgCNvv1XerDpuqN0oKgV3qN03VYdKjoOorv8tRum6rDffqOgCu6bajqWb71RUARulRulSPUb0FwK7ptqOrDpVetDU//R+1NlSIlFSJX+b5/Q84AlSUJUiJurMgkh+7UlRom2rCJuoAVPuU+hPlqRKDGYIlSIlCVKn3KDEeny0UVIlAAiVIiUJUqfcoAeiVJQlSIm6gBU+5T6E+WiiZmFSUUVmBIlSIm6o0SrCJWYAiVJsoooImCJUlFFBkFFSIm6jZQAIm6jZUiJUmygzI0SpNlFFABso2VIibqNlAEeyipNlGygCOipNlGygCPZRsqTZUb/AC0AR1G6bqsUbKAK+yo3+WrFRum6g0I6KH+WigAqN0qSig1gV6jdN1WHSo6Cyu6VHVhvv1HQBXeipHSo6uAEbpuqN0qxUbffrUCu6bqjdNtWKjdN7UAU3oqR0qOg0I6jb79SPUbpuoArvUb1YdKjdKDaBXdN1Rv8tWKjb79BsV3TdUbptqxUE33qAIqjepKjegCu9V6uOlR+T/tVoXzn/9L7YT50qREqNPkSrCV/m+f0ZMKsQ/dqvViH7tZnOSVKn3KiqVPuUAPqRKjqRKDGZIiVYT5aYn3KfQYhUiJQlSUACJVhEpifcqdKACpU+5SIm6pE+WiZmFSJUdSVmAVIiUJUqfcrMB6JUlCUUAFSUUUETCpETdQibqkT5aDIE+WiipESgzCpETdRsqRPloAj2UbKkooAE+WiiigAooooAKKKKACo3TdUlFAEeyjZUlFAFd0o2VI6bqjf5aAI3So9lWKjoNCu/wAtFSN9+o6AI3oqSo6DWBG6VXf5auVG6UFlN6KkdKjq4AR1G6bqkeitQK7/AC1G9WG+/Vd6AI2+/Vd6sOm6o3Sg0K70VI6VHQBG336rvVh03VG6UFQK71G336sPVd03UHUR1BN96p3+Wo3TdQBXqN6sOm2o6AK70VI9R0Af/9P7cSpEqNKk2ba/zbP6IJETdUiJtoh+7UlBmSIm6pE+WmJ9yn0ASJUlRpVhE3UGMxU+5T6E+WpEoMQSpKEqRE3UASp9yn1GnyJVhE3UGYqfcp9CfLRRMCRKKESpK5wBEqwiUxPuVOlAAiVJQlFBEwqRE3UIm6pE+WgyBPlooqREoMwRKsJ8tCfLRQAUUUUAFFFFABRUmyjZQBHUmyiigCOipKNlAEdFSbKNlAEdFFFABUbpuqSigCu/y0VI6bqjf5aAI3Sq7/LVyo3Sg0K9FD/LRQBHUb1YqN0oNYFdvv1HVh0qu/y0FkbpUdSPUb1cAI3TdUbpVio2+/WoFeo2+/Viq7ffoNCu9RvVio3oAjqNvv1JUbffoArvUdSPUb0G0CNvv1HUjffqOg2IJvvVFUs33qioAjejZQ9FAH//1PtxKkoSiv8ANs/oQsQ/dqSo4fu1YRN1ACp9yp0qNPlqRKDGZIlSp9yokqVPuUGI+pEqOpESgCRKsp9yqyJVhPloAkqVPuVEibqsJ8tBmFSJUdSUTAkSpETdUaVKn3K5wHolSIlCVIlBEwooqRE3UGQqfcp9CJUlBmCJVhPlpifcp9ABRRRQAUUVYRN60AR7KkRN61J5P+1QibaADyf9qjyf9qpKKAI/J/2qPJ/2qkooAj8n/ao8n/aqSigCPyf9qo3TbVio3TdQBXqOrnk/7VV3TY1AEdFSbKjoAKjdN1SUUAV3+WipHTdUb/LQBG6VXf5asPUbffoNCOo3qSirgawK71G336sOlRulEyyvUbpUj/LUb1AEdRum6pHoq4AV3+Wo3Te1WG+/Vd61NCu/y1G9WG+/Vd6AI6jb79SPUbpuoAjqN6kf5ajegqBXdN1Rv8tWKjb79B1Fd03VG6basVBN96gCs9FSUbKAP//V+4EqRE3VGlWIfu1/m2f0ICJtqyn3KiqVPuUAPqRKjqRKDGZIiVYT5aYn3KfQYkiVIlRpUiUASp9yn0qfcp9AEqfcp9MT7lPomZkiUUJUiVmAIlWESmJ9yp0rMARKkoSigiYVKn3KRE3VIiUGRIlSIm6o6lT7lBmPT5aKKKACiipKACrEP3ar1IrbP9ygCxvT+Ntn+9WXq2v6Nolu9xrN9Bp0KfekuJViT82IrzP45/FzSPgp8Or/AMbamVlmVWW0hbP7yXsvGfr9K/nj+Jvxf8dfFjWp9b8bajJcKwxHCDtSNMltoX0yT7+tfqHDnCE81h7ac+WAUYTq/Af0cf8AC3vhX/0OGkf+BcX/AMVR/wALf+Fn/Q4aV/4FRf41/L/bWz3Kf6DFJN/1zjq5/Y+rf8tNNuf+/L/4V9/Pw+wn/P46fq398/p0/wCFv/Cz/ocNK/8AAqL/ABoT4vfCxv8AmcNK/wDAqL/4qv5h20fVlb/kF3Df9sn/AMKP7E1r+DS7n/vy/wDhT/4h/hP+fwfVv75/Tw3xe+Fn/Q4aV/4FRf8AxVH/AAt74V/9DhpH/gXF/wDFV/MWNA13/oE3Tf8AbF/8KH0fWof9Zpdyn1gf/Cj/AIh/hP8An8OeGnH7Z/T5a/Fb4Z3s3kWvi3SpZf4VW7i/+KrtEmjeJZ43WRH+6ynctfyf/J9/5k8tv+WfyTK9fdn7Kf7WXiz4d+LLDwn461Q3vhPUpPL8y4Y7rRv4fXj19Ov18zH+HcIUpzw1Yy+rT+M/dwffeo3TdRbz291bpdW7b4pl3K3qtSV+DThOE+Sf2TLnK7ptqOrDpuqN021mBXooeigAqNvv1JUbpuoAjqN0qR/lqN6AK7/LRUjffqOg6YEb1G9WKjetCyu336rvVh03VG6VmBHUdSVG9XACNvv1HUjpuqN/lrUCu336rvVx03tVd0oArvRUjpUdBoRt9+q71Yb79V3oKgRvUbffqR6jb79B1EdQTfeqeoJvvUARUUUUAf/W+4EqxD92q9WIfu1/m2f0ISVKn3KiqVPuUATpUiVXSrFBjMlT7lPpifcp9BiSJUlEKb1qTZQBJD92pKjT5EqwibqDMVPuU+hPlqRKACpEqOpESspgSp9yp0qNEqREogRMkSiipETdRMyFT7lTpUafLUiVBmSIm6pE+WmJ9yn0AFFFFXACRKkRN1CJvWpETbROH8gBsof5FeP+P76/9sv9ZUjvs/75r4z/AG1/jbH8I/hhPpWkXKxeJ9fXyLdQ2HjT+JxwegPHvj3r3MowM8wxEKMAPzX/AG3fji3xc+Jg8OaRcOdA8PhoxEG+SS4J+dxz3AVf+A5714/8M/h3pmp6dP498dEweHrPqB96Ru3+f8jyvwd4X1Dxd4itdBsiZbm/kBkPog+834CvZPjd4ktrUWfw00Fz/ZejLtkYMf3kvfP0/nmv69o4eGFpQwFE9LknCHJA2Lv9olNGJsPAugWdpYJxGzoWZv8Aa4I/r9ajT9qbx7D9y0sPxgX/ABr5n3p/G3z0I9dsMopfbOn6nD7Z9QJ+1h8QU/5ctO/8Bh/8VVxf2u/iRDwllp3/AIDL/wDFV8p1G7/c/wB6ur+x8MKGGgfXi/tj/EtD8llpn/gMv/xVaFr+2v8AEuBwZtL0qWMfwm2Xa3/j2a+b9E+GnjvxJocvibQ9FnvNKgb5p1WuHR/k8vY2/d8ysv3a8yGAwk/ch8ZnCjA/RjQX+DX7WlrceHJ9Ii8GePUV/srWi/ubp/8Ac/dV8B+KfC2r+E/EGo+EPEKG3v7ORo5gTkbl+6wPof1qvoGuah4W12z8SaRM8F/YSLJG4PB2/wAJHoa++P2kfDVl8Zfhlof7T/hCASXcUaW2vQoCyxOhxubP+8o6dCKOSeCrex+wOfuT5PsH2R+wp8fV+Jnw/TwLq8hbxD4cCxDcT++ix8rZPUjBB/D1r70r+Yf4M/FPWvg18RdL8bafMzQRSqLuJePMt+4/Wv6WPC/iXTfGPhzTvE2iOJrLUo0ljZT1VxkH8q/AeOMl+r1frlGHuTPInDkmdBUbpuoR9/7yP7lSV+N/GBTdNjVHVmb71VnqgCiiigCNvv1HUjpuqN/loAjdKrv8tWHqNvv0GhHUb1JUb0GsCOo2+/Uj1G336uBZXeo3qR6jetQCo2+/UlRt9+gCu9Rt9+pHqNvv0AV3qN6keo3oNCNvv1HUjpuqN/loKgRvVd03VYb79R0GxXf5ajdN1WG+/UdBoV3TbUdSzfeqKgD/1/uCrEP3ar1Yh+7X+bZ/QhJVhKrom6rFAAlWKjSpKDGZKn3KfTE+5T6DEsJ8iVYT5qr1Kn3KAJ0qVPuVElSp9ygzH1IlR1IlAEiVKn3KiSpU+5RMCdKkSo0qRK5yJhUqfcqKrCVoZBUiJQlSp9yszMeny0UUUAFSJUdWETetAEkP3akqNE21JvTc+9tiVfOBn6trOlaBptzreqyrDa2cZaSRuiqK/m3/AGjPi/d/Gj4qap4vnkLWEMjQ6euSyhF9u2ev41+kH/BQr47xeH9Fg+D2g3G3VNW/eXew/wCriORtP1/p71+W/wAJvA58a+LLa2mXbpFgVkmOOi+n41/SvBWT/UsJ9ZrfGdOG/nmeweCrWD4R/DW88e3R8rWdZj8myQjLKv8Ae6/U/QCvl9V1PVL4xRQvcXl4chP9qvVPjF41XxZ4naz09h/ZemgQ26j7u1OB/wDW9sV65+yN4WtNZ8U6prWogSnTY0ZQf7xz/hX3c5/V6M8TOB08/JDnmR+E/wBkHxnr1rFd63qMOis67vKZd5/Qiuo1b9ijxMllJJomu293OB8sTKUz/wACyf5V2Hx3/aF8UeCvEjeE/CZW3nWNZJJjz8x5xtPFeL6B+138WdGvBNqN6mrQpyySqq5/FVFeJhq2c4iHtqJzQnWqw5zw/wAZfDrxn4BvDZ+L9Lk04L0kI3I30YcH8DXF/On31+R/u7fndq/Zj4efEP4aftNeE5PDuq2iRX8q5ktXPzKR/Eh9vXtR8Kf2OPAvgjX7zxLrxTVoonZoFfhY4sDhh3O7P4Y4rSHFMMJ7mMh74fXJw9yZyf7A/iu6vvBmqfD7V7V1trZzKCUx5iuFG3PtjNfBf7SPgS2+Hnxq8Q+GrZ8wySedCuPmCSDIHbpmv1wb9pj9nXwtro8OQ6pb2srcSNFbEIP+BbsV6xH8J/gx8T9dX4wNZW+rmWFFF0W3oFTkYXle/p2r46jnc8Fjp4mdGXJM5oVuSfPM/nDe0uNvmT2s8f8AvRuv8xX2Z+xj8W9D8LeJ734U+OnWTwb46gezmVjuWOU/dbk4Geh+ue1fph4//aA/ZE0LT9X8Ia7d6dLdRI8bWqWjKxbaQfm2Fc9utfgnqc2nnX7690SP7PZvPI0IH/PPcdv6V+h4DHzzXDz56Mo/4jt9t9YhyTPSPjh8KtX+DvxH1TwRqkZNvEzNbscBZom+6eP19wRX6Ef8E8/j3Mxl+Cnia7Vcx+dpcjMdzHktEPoBkc+vtXn/AIjkT9q39m+z8UWID+Ofh8nkzIWJlmthzvOBj+8enUH1r88/D/iC/wDCfiCz8S6RIbe802YSR4GQGX7yn1B/Wta2EhmeBnhq3xwNZ+/S5D+qxKkryv4LfE3SPi58ONL8Z6XIAZY1WeNTu8uXALL+H8iDXqn/AFzr+PcZhp4etOjM8iBG6bqrumxquVBN96vONStRQ9FABUbffqSo2+/QBXeo3qxUbpQBXqN6k2baKDpgV3qNvv1Yeq7puq4Fld6KkdKjrUCOo2+/Uj1G6bqAI6rt9+rD/LUc1BoU3qN6sVG9AEdRt9+pKjb79AFdvv1HUj1HQbQI2+/UdSN9+o6DYgm+9UVSzfeqKgD/0PuCrEP3ajRN1WNm2v8AN8/oQlT7lPpifcp9ZmZKn3KfTE+5U6JuoJmKn3KnSo0+WpEoMSRKlT7lRJVlPuUAPSpU+5UVSp9ygzH1IlR1IlEwJEqVPuVElSp9yswJ0qRKjSpErMiYVYSq/wA/91n/AOA1YRH/ALv/AAH+Ol8fwQMiRKlT7lVppIrKJp7pxbxJ/FKwVfzNeZ6/8b/hN4UhM2t+K7CMrzsWUO/TP3Uyf0r18NlWOxH8GBmesfJS7H/utXw14l/4KB/AbQzJHpj32tSR9HtYBs/3d0jr/LFeF+Iv+CmCPC0fhnwVJJJjiS6utoz/ALojP86+sw3BWZ1fjgL35n6ubNifOrJ/vVYT7vmIrOn95a/B/wAQ/wDBQn466lC8GnLpWkxvnlYC0o/4EzEfpXifiD9qH48+KVLan40ujuUL8hWHgf8AXILX11Hw4xfx1pmvsZn9JH2uBP8AXyxw/wC+6r/WvL/iP8ZPAXw18N6j4h1PUbeSewhaRYA6s8jfwgA+pr+bPUPHfjfWXLatrt5eN6vO7j8iTWW1tqWrsmI57sltoB3Pn+de/huAcPSnCdaZr9TrfbOk8ceNNX+JvjbVPHWr7jeaszMik52I33VH0HFe6a4Yfg78Kbfw7a/6Pr/iBUkucnLRr/d/mPzrP+EHwz1C3nk+IPja1MOnabG0oRsZZ0wV6kbcdee9eL+PPFlz438T3PiK8JMcrfu1P8K9hX6ZCHtZ+xo/BE7ocnPOBx9fUn7J/jC28P8AxFfSNQkEVrrMfl8j+LtXy2fuJUlrPd2Vyt7YSmGeH5o2H3lavXx2G9rh50TpnDnhyH3B+138K9Xg1ZfiRpVu8tm0QjuAo+6wJG76Y2ivh9Jv3UU8G54n/h276/Tj4F/tHeFvHGmweCfiLIIrwxiPfNhoplPqeAv48fyrU8dfsU+DPF15Nq/gnVDpZuG3LEg8yL3+YnI/M18Lg84hltGGGxh5FHE+y9yZ+afhDxZrXgfxBbeIdEkMc9hMshI4yvdT7Hoa/dzS/ETfGr4EXWveF3FteatZOh2Abkmxj9DXwPB/wT+8ZzXXlx+JrNE/vOH/APia++P2X/gj4h+B2gXPh7UNWTV7W4lLoIUK+XvAH94/3a+f4mx+XYiEMZD4zLGThI/APU7K+sr+50zUE8ue3mdLgN94MGxiv14/4Jkaxr1/o/ibSLyR5NLtmRo8/MuWzn9FFe6a3+xR8A9f8SXXizxKLiKfUrhpWAuVji3E5PAAP619OfCzwb8IvhZo58NeBTa2kcjbpCZVLMfeubO+JqWNy6FGjA5q2J9z3IH4J/tm6TbeHf2jfFltpc4WN5Ekwv8AekRWP6mvl/5HVI/4N2+v2w/aI/YLb4k+J9U8e+F/Ejf2pqXzCKVPlLBAAu/dx09K/I/4h/DHxn8Ldak8O+M9NeyuVJCPjMUig43K3Qiv0TIcyw9XCUaPP78T18HW54ch3H7Onxcufg78R7PV2Pm6RqbfZtSiJzmJu+M9QSCPpiuk/ah+Flt8PPiAuvaJH53hjxMBeafMn3B5hbcnU4xjIB7EV8x/6mV96/w7Gr74+E3iHR/j78Jn+BXiy7it/EWk7pNGuLg4Tkp8nAPJA/Ie2D6WMh9XxH1k0rQ5J85T/YW+PMXwt8bSeEPEt2bTwx4g3GMuQEhlxyxz67QDz/Kv2w0nx14Q12Lfout2d6ucZinVun+7mv5r/F/wj+IngfVpNB17RJg1v/GEZo2/2lY4B/zmvPzDrOlFcm4s2T+HLx/4V8bm/DOBzOr7bn98562G9/ngf1aQ3NvN/qHWb/cZW/lQ6b/n+4/91q/lr0n4k+O9Eb/iT+JtRtk44jncJ+QOK9U0D9qb9oTwsSdM8YXUkbZys22Vef8AeDY/Cvia3hzOf8GZl9Wn9g/o82fJv/8AQfnqOvwz0D/goh8ddKEaapFp2rxpjl4mWXbj1VwP0r3jQv8AgppZMFTxF4ImjPeW3uFf/wAcKL/6FXzeJ4BzGl8BnOFWHxwP1UqN03V8R+Hv+CgfwD1y4jg1O4utGd/+fqLb/wCiy1fTHhz4x/C3xXbC58O+KbC6LOUCLMnmbh22Z3fpXx2J4czTD+/OiZc56A/y1G9SI/2lPPg27P8Aaao/vf5+Svm60K0PjhyBCZG336jqR6jrlhOEzpgRvUdSPUb10wLI2+/Vd6sN9+q71rMCN6jd9tSPUbpurKAEb/NUb1I/y1G9agR7KrzfI1WHfbVd/neg0I6jb79SVG336AI6r1YqvQVAjb79R1I336joOogm+9UVSzfeqKgD/9H7ohqw9V4akr/Ns/oQlT7lPpifcqdKDMEqyn3KiSpU+5QTMfUiVHUiUGJIlWIfu1XSrKfcoAfUqfcqKpU+5QA+pEqOpE/293+6vzvRCE6vuQgYTJEqxD937+z/AGm+5XjfxB+Onwt+GUBbxTrsMcijPkIytL/3wOe9fC/xA/4KM2sEk1n8MPDrXA5Vby++Vd3+4Dz/AN9CvrcBwnmOK/uhDnn8ED9UP+WW+T5E/vV5X41+N/wp+H0LN4o8SW8EnXykO5+n90c/pX4T+OP2lvjX4+nZ9e8TyxwHjy7NjEgX+6QOv45rzfQvAvjDx/fRReH9E1HVrqRsbhE7oPqwBAr9RwfAOHhDnxlYcKM/t+6frB4t/wCCjPw+sBdWngzRLrWpcYWVsRxZ/U/pXy34y/b0+N3iV5odFjtfDkMi52W6+a3+9lt1c/oH7DXxk1aEah4sFh4atGP3rx1Eqr/uqG/nXQTfBD9lf4byonxG+IkuvXqLva20tdn/AADf5lfZYPK8jwk+TDQ5p/8AbxpyQPlfxN8X/iX4vkLeIvFd9dFgV8oTkR4P+wML+lc3pfhHxT4inUaTpd5fSesUbP8A+gg19oTfHX9mnwSvkfDn4afb5YPuz3/zuz/9+64fXf2y/iXqAki8PW9n4fgbjFvArEfi26vqIYnEfBRw3JAUIHH6L+y/8a9fAl/sc2ka85umVO2enX9K7hP2Um0eHzPF/jLSdIdMFkMis+PYNt9PWvC9c+L/AMT/ABGS2r+JLyQN0QOVT16DArz+6ubq8fzLqZ3f+JmbdmtPY46f2+U7YUZn1JN8Pf2c/Dyf8Tnxxc6rKn8NpGmyqf8Awk/7NOif8g7w/d6k6fxXLf8A2uvlvYm7ei1I/wB7+L/gTVr9QnOHvzH9WnM+nJvjx4Htv+Rf8D2ibPutIv8A9rrHuP2j/FLEtp+j6dabfu4iY7fzavnt/wDgSUI8iVrDLaMA+pwP0k+BfxGb4p6LeaRrgie8iLrIoG1ZEf8A2ense1fDfxQ8Gy+CvG2o6QyMlvJJ5kJP9ztVz4TeOLjwJ4zs9XjO6J22zDO35f8APNfZH7U/gu18S+CbDx9oS+bJZjLMoyZIu35cmvjfY/2bmPJ9iRxcnsqx+df8FFHyf8sF+T+Giv0jkgetOf8AIdR4N8J6h448T2Hh7TDia8kVS391e5/Cv38+HfgTT/Avhaw8NafK8gt41DGUsct3+lfkn+xLY2998crYXCB1t7eWRR/u4H9a+7P2jLX9oo61pcvwbS4a3t0Bm8ooRI+4tjYeSNoHY5Oe9fifFk543Fwwc58sDwMf70+Q3PjFqf7WOgGfUfh3b2V1p0XCIi75tpPdXBB/DJryf4Sft0+IR4stvBnxu0b+z52kWMXCIUZW/ushyR9f071x/hP9tT4u/DHUYNM+Ovh2WOBn2i4khMUo/wCBHAK/Qf4V9geJ/hT8FP2yPAR17w9NFDq4UGG8iG2WOUDcqPj7w56fkR1ryJ4PD4Sj9WxkPc/mObkhCHOcn+3d4D17xN8JrPx14Mmkk/sljJKsTsMxN1Yjpx/LNfiPZ+KPE8Z8+DVrqMj7pWZ1/ka/pc+CnhbxDF8ErbwL8S7c3FzZxtZ3IkbzPMiThGyefu4Ffhv+03+zV4l+CPjO8lggM/hu8kae3mQZ2q3RSvt6/wD6h7nCeZYSHPgPi5TTAYmE/cM/4T/tWfF34U6klzFq0urWG799b3TGRdp645yPwxX6sfavhv8AtqfCR2cRpcxRspK/620n2dRnG5fm9MEe/T8D4ZkfZJ9//ZWvvj/gnxrGtw/EfWdIgVzp1xZM0w/hDggD+Zr6jPsqhh6U8fR92Z24mjCHvnxn478G614B8Wap4Q1uPFzprMAcY3KeVP4jmubhnuLO4iuLeVopYW3KyHa3519wft96TZWXxms7+3ysl/p6NIO2dzjd+mPwr4bdNn3K+py3E/WsPCczuhyTgfRnhz9q3416Bp0elvqiapbRYwLqJZTx/t/e/WusT9r/AF66G3xB4S0W/QdcwMGJ6Z5Yj9DXyHQ/zvSrZbh6v2A+rQPsB/2gfhJr37vxH8NIE/69vk/9p1lzax+yhr3+v0W+8PSv/wA82318p7I9/mSLv/3qN/y7PuJWcMq5fgF9TPqD/hVfwP1tv+KZ8ftbM/3Y71dj1n6j+zbr06iTw9rthqa5xhJVIP48j9a+a9n/AC0dvnrQtr++s38y0nkh/wB1qPqeLhP9zMznRnA9A1f4NfEjQo5PtmiSyRr/ABW4WVef93NedpYXejzf6mS0lT+M7kYfyNdxpfxU+IOilW0/W7gBf4GYsv5HivUNO/aS8SyKbXxRpNhrMPcNEqt6fe5H/jtH+3Q+xGZnOEzzfQPjJ8UvCchbQfGF9FG3JQzmVPX7j5X9K+nPBf8AwUG+M/hoLa+Iks/EcITaN42S/XK4H6Vw/wDwmf7O/ir5PE/hq50eV/8Alpafw/8AkOpIfgb8J/FUW/4e/EGP7Q/3ba9XZ/5EkrxMT9Uq+5jKJj7h90eDf+CiXw01RY4PF+j3mhzDGXRPNiJ/D5v/AB2vrjwh8bPhT4+Abwn4psLuRsfuvN2SDP8A0zbDfpX4X+JP2Z/itoUJvU0satarn57F9+ce3DfpXh8llrPh28xew3WnXQPDYMcq/RuDXyVbg3KcV/B9w2hhp/HA/qQ3/cf5UTbv+b+Ko38xNm9W+ev54/Bf7TXxy+H8iR6R4klu7aMEBLpjOoz/AL2SPwIr7c+Hn/BRXTJBFbfEvQntGQ7WurM+arf8A2jH/fRr4DH8A46l7+G94znCrD7B+nj1XevL/Avxw+FvxJhW58J+JLO4kfH7pn8qZWxnaUPPT2r1B/MTZ5iMm/8AvV+XYzA4vCz5MZDlOXnI3oqR6jrhhOE/gOgjb79V3qw336rvWoEbpuqu/wAj1Yd9tV3+d6DQjqNvv1JUbffoArvUb1I9RvQVAjb79R1I336joOogm+9UVSzfeqKgD//S+6Ifu1JUcP3akr/Ns/oQlT7lTpUCfcqdKDMkSpU+5USVKn3KCZj6kSo6kSgxJEqyn3KrJViH5/kj+/R/gI5+QN6J+73Kn+9Ul1d2Gn2bX13cJDAn3nkbao/E18Z/HH9svwR8LLm68NaDF/bmv22VKZ2xRt7vhvxGP8K/K/4lfHr4n/FK4mfxRrbQ2Dni1hPlJgfwnH3vxzX6jk/BWLxcPbYn3YBDnnP3D9VPip+3F8KfAXnWfh2R/EeooMBVOy3DEf8APTDfoDX5x/Eb9sL4z+PZLhYtSfQNOk48mzJQ4/387u3rXL/Cf9mX4u/GJtvhbQprWw3c3l4pt7ccZ3K7AbvouT7V9WJ8Jf2UP2e9l18XvEsnjnxHAu9tNsG/cr/sP/rf491fr2DyXK8t/gw5pmc5w/xTPgPwz4J8Z/ETWhbeE9Jutc1G4O4kI0oCjqxYdAAOp4r7Q0H9grxRBBHrnxn8TWfg7ScjcJXWW42Yz90lFz/wI0eMP26/ENrYSeHvgjoFl4F0op5YeGFPtDf7RbGM4x/Dn3xxXxf4n8beNPHN0914x1y71V3+95klfVc+Lqw5Ie6aQniJ+5D3D70h8SfsHfBZnTStMu/iRrdr92e5+SHf/n/0KuH8U/t2fEi7t20z4faTYeDdP2FAlrF8+Sc7tx4H4KK+G97onlptRP8AZWiuiGV0vjrHVDBw+OZ2niX4jePfGk73XinX73UWfn97Kx/nmuLT5P4VT+9t/ioor14QhR+CB2whyBs+b+5/u0f99f8AAqKK0AKKKKDTnCiiigOcKKKKDMPn/gr9KP2YfFlh8R/Al/8ADfXADeW8LxKCc+ZCUxj+Y+mK/NevTPhH49vPhx44sPEVtnyTIqzAHGV7183nGA+sYf3PjgcOJhz++Yfj7wtc+CPE+qaDcjAtGbyz/eTsa4/5P4Gr9DP2yPAlhrmkaR8YfDQEsV4oWQr0Knoa/PP5P4Pu105LjPreHhP7cDWjP3D6k/Y31y20P486NLckBbyOWEZH99Tj9RX6iftB/H2+/Z8j0jV/7COp2d/J5byiXyjG30wd3T269e1fhv4R8RP4U8UaX4iTcPsFwkjFf7oOa/ej4p/DXT/2nvglp1vpl6lq2pCK8huGXf5bbduO3YEH61+b8TYalDHUa2J+A8TGfHzmf8O/iV8Ef2tdCn8O6hZRNfsrZtZeJUb+8jcbse2PcDv8f+Gfh38ZP2UP2krDQfBNvca14d8QToY4UGxZItzZ+Y79vlgk5PYZwAa+lPgd+wPovwt8RWHjO98U3l3qNockRARRfTdyenvX2J8S/jV8LfhbYtrXi/VrWO4iXMKLtllP0HU18licZ9XrTw2Ah7WEvsnFWn/Ianxb+Itt8OPh7q/jbUNkU1hbu0Ql5zKF4Xj1PFfCfwz/AG0/hF8btH/4Rf4rW9vp94zYYTfNFJ6NuPC/ifxNfB/7VP7VuqfHq+/sXR420/wnb48u3B/1hH8Tf09P1Pxvv2M/yr/3zX1uT8FYeGH563xnTg8HzwP3E8QfsUfs+eNLn+2NLM0EFyfMBs51ZG+mQ36Gu40bwz8Ef2ZPD889nMmkKwbJldZJZM84HT06AfhX4R6b4y8XaPH5On63fRIf4RO4UfgDgVT1PWtX1vnWr64vv+usrP8AzJr0p8OYur7lbE88D0Z4CrP7Z6p+0B8T/wDhb/xKv/EsBIs0UW1uD2RCT09ySa8X/gSP+4tDvI/3/wCD7tFfpGGw0MPR5IHpcnJ8AUUUV0moUUUUAFFFFABRvf7n8FFFZckAJE8hP4Nn+6zpUfz718tmSiitTKcOc9A8MfFH4h+D5Ufw/rlzbbP4fMr6A0b9rW9v4lsfif4ZsfEds2EeYxokwQDoG2ED8BXx/RXmzwOHkZ/VoTPuB/D37IvxXfZoeoXPgnWJ/wDlnIu+H/2lXN+LP2Lvizo1oNY8IPa+K7BgpSaxfdKVP+x3/wCAlq+Q9+9PIk/1X/j/AP33XoHg34qfEH4fXIufCGv3WnspJCK+5Dng5XofxFeb9TxEJ/uaxn7GrD4JnN3Ntq/hfUsXMd1pd/C23LhreVf5EV9IfDL9sj4yfDmeK2vr8a5YL963vMlygz8quckdfce1eoaH+1/4a8a2a6J+0P4Ls/EcbZUahaxeXcID05z2yfulfx6VsXn7LXwd+M0T6z+zn42iS7++2k6k3z7/AO4n7yuetWhV/c4yiZTnD/l8fWHws/ba+E3xAaDT9Xd/DWqS9Ybr/Vdvuy8DnPcLX2BBdQXUST28iPFIu5XU7lP4iv5v/iJ8HviR8Kb5rPxnoVxZRkkJM6Zt3wcbkfoenY11nwz/AGifil8J7gJ4e1hruzbk2t0TJEemdozx07EV+d5lwPhMR7+AnymfJD7Ez+hTfv8A4W/4FUb18n/Aj9rbwR8YpIdB1OP/AIR/X5gALeU5SR8fwtjn6ECvrCQPG4ST5JU+8v8Adavw7MsoxGX1uSsHORt9+q71Yb79V3rxCiN6jb79SPUbffoArvUb1YqvQVAjb79R1I336joOogm+9UVSzfeqKgD/0/uiH7tSVXR9tSI+6v8ANs/oQsp9yn0xPuU+gzJEqyn3Krp9yp0fbQTMkqRKjT5qkSgxJEr5r/at+LNz8J/hNPc6Q4TV9Zk+w2hzyu9SWYcHoAce+K+lEr81/wDgowT/AGF4IiH3Wu7xv++Iov8AGvtuE8NDEZnCEzM/Of4e+BvEvxe8cWfhDQf3+r6sfmdzwoHLN+AFfoI+ifsofskN5fiNv+Fl+O7Jfmtl/wCPWCf+5/y1ryv/AIJ5RxxfHe5dUVmTQ7jazfeU7V6V8X+Jp57jxLq91PIzyS3c252+83zmv6irUZ4jF+x5/ciROE51eSHwH0Z8UP2vvjJ8TRLpYv28P6GfljsbE+UoXOeSvLfia+X3fe3mP9/dvZv71R0V7f1OjS+A9KjhoUoA773/AIf+A0UUV2850hRRRWYBRRRQAUUUUAFFFFABRRRQAUUUUAFRv5jps3fJ/FUlFAH6WfsxeJbP4vfCvXPgjr0qtqUUMhsnc8hSvb3BJPFfnf4n8PX3hLXtQ8OalE0Nxp0rxMrV1Hws8d3nw18d6X4zs3IFnIvmD+8ncfiK+sP2y/A+n6lNpHx28LkPpHiqCPzgo/1c2W3Nx2K7R9RXx0P9ix3sfsSOHk9lM+C/vxPB/A/yNX0p8O/2tvjX8L/DUfhPwvqitYRfdEihsfmDXzOk0H/LPc/+7Ujvs/havfxNHD4j3K3wHdWhCZ9AeJv2qvj74rSSDUPFtxHFLjKodnT/AHcV4XqOp6lrNx9q1i8mvZf71w5kP5nJrP8A++akf5G/hoo4PD0oe4ZQowh8Afu/4N3/AAJqKk2b/wDV/PRtevWNSOiiiswCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooANkf8a/8CVtj1Ysr2/0y7ivbCd7SeHlZoWMco+jDBqvRWXJAJ+/8Z9meAf21PHui2i+GvifbReN/DbfK8V4m+VV4Hyuc9v7wb2xXaar8Fvgf8e9NuNf/Z61NtH8QQL9ol0O7/i/56eXX5//AMH3m/4DX0B+yrdXVl8fvCD2cphD3DK23ow8s8N7V5OMwfsv31E4p0Zw9+B4fcRat4a1jfAWsdR02f5WXh45I2/oRX7yfst/Fu4+MPwm0vWr47r+zP2O5bpuZAPm/HOa/Ff4x7E+LnjDy12f8TOf5Vr9IP8AgnMSvgfxSinMa6pEyr/d/dR18Txfg4YvLPbfbM60PgmfoY77qjepf4E/7af+h1E9fyoQRvUbffqSo2+/QBHVepHqN6CoEbffqOpG+/UdB1EE33qiqWb71RUAf//U+4KsQ/dqvViH7tf5tn9CFlPuU+o0fbUifNQZkqfcp9RpUlBMyVPuVOlQJ9yp0oMSRK/Nf/goqhfR/A3+1cX/AP6Kir9KEr83P+Ci2f7H8B/9fF//AOioq++4N/5G0APFv+Cex8346XP+3o1x/wCgrXxPrv8AyH9W/wCv26/9HNX2p/wTv/5LlPn/AKAdz/6CtfFetf8AIf1b/r8uf/RjV/T9H/fpm8P4s4GXRRRXvnaFFFFABRRRQAUUUUAFFFFABRRW54b8N6z4t1mLQ9Dg864dXespzhCHPMDDor1zxB8DviR4a0eTWtQsF+zRLubDDgV5H8n8Db1rPDYmjiIc8Ah7/vwCiinf/FV0gNor1T4bfBj4g/Fa3nu/B+nC4t7eTy2bcB82Pej4j/Bb4g/CmOzufGenfZIbyQqrKwYcfQmub65S9t7GEzKc4RPK/v8A+5/Gv96vtD4KftVaR4E+H8vw3+IvhlfFekGXfDv2/ufu46qcgYyM9zXxf8jqjx0fxfdX/vmssZgIYv3K32DWtR9r7kz9ELn9or9k2/8A+Ql8G5N7/wAUciVzdz8Tv2Jr/wCef4V6vbP/ANO0yV8J4/2ajeFHf7q1xQyqBzfVj7UvPEP7D9+v/IteL9Nf+7HJDs/9GVxd/Z/si3n7zSrnxbYf9dI4X/8AalfMaIifwr/wJaNqf3F/75rp+oTh8EzSFHkPaL/QfgQ+/wDs3xdrKf7Nzp6f+hxz1xd/oPhGF/8AiW+KFmT/AKbwvvri/wB2i/ItFaQo1f5zUsXKQQy+XBcx3if3lqvRRXdye4AUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFdZ4G8DeIfiH4ks/CfhO3F1f3Z4BIUKO5JPHSvePFn7HHx58G6Bc+Jda0SNLOzjaSRhIrcD6GuGtjKVKryTmHwfHM+W6K2PDHh7XPGGt6f4c8P232nUNRbYse6vozXf2Pfjr4d0q51fUNHVILONpJDvH3B9D6U62MpYefJOZlOcIny3XvH7Mb+T8ePB8n/TzXg/8Xl17p+zT8nxz8Jf9fVZ43+CFafuHJ/GZ/8Ai7Xi3/sIz1+kn/BOr/kSfFn/AGEIv/RaV+a/xgfzvir4rf8A6iM9fpR/wTq/5EnxZ/2EIv8A0WlfE8Tf8iU563wH6Gf/ABT/APodRt9+pP8A4p//AEOo3r+RYGUyOo2+/UlRt9+tSSu9RvUj1G9BUCNvv1HUjffqOg6iCb71RVLN96oqAP/V+4KsQ/dqvViH7tf5tn9CElSp9yoqlT7lBmTpUiVGlSJQTMlT7lTpUaUUGJYSvzX/AOCir/8AEn8DY/gnv/8A0VFX6SI9fm3/AMFFf+QP4J/673//AKKir77g3/kbQK+2eN/8E8zs+Ok6H/oDXH/oK18T61/yH9W/6/Ln/wBGNX2x/wAE8v8Aku9z/wBga4/9BWvifWv+Q/q3/X5c/wDoxq/qSj/v0zWH+8TMuiiivaO0KKKKACil/i/+Jr6T8G/sq/E/xjp8ep5t9LglGQtw5DfkAetcWMxlLD/HMJ8kPjPmuivsB/2MPiEi/wDIV09/+2lcn4n/AGXfiN4b0uXVd9tfpB97yJK8yGb4SU+TnOb20JnzXRQVkBKSKUZG2srdmor6A6PgCvZPgZ410jwP47g1PWmK2zRuu4LnGf8A9Vcn4W+G/jPxjKh0SwMkUnHmN8q/ma94039kbxnexrJqGo29of7uDL/8TXzeZYzCSh7GczixM6XJyTme0fEj47fDvUPAmr6Vpl+9xPfwmNQVPy5471+c/wC8TZvr7Qj/AGK9enOyLxBb4bn5omX+RauL8Vfsm/Fbw5BJe2scerwoQD5TfPz/ALPB/LNeLlWJy7D+5Csc+DnRhDk5z5joRPmT/eqxdWV3p9xJY6jE9vdJ95JBtP5Go0/g/wC+q++hyVYc563JDkP1k/YBto2+HWrycqz3pXn/AK5x1J/wULR0+Hnhp93/ADEXq5/wT7X/AItrq+f+gkf/AEFKP+ChcLzfDzwuiIzu+puiqtfgMJ8vEPxny/8Ay+PyI/h/4E9JX0x4C/ZG+OvxDjW40jQHtLaU5Wa4PlKfz57dga94g/4JpfHWaDzLjUdHRv7vnyn/ANpV+vVs7wNKfvzPfrYmB+de+pK/Qx/+CbHxrT7+raP/AN/5f/jVUx/wTn+M6/f1TSf+/sv/AMarj/1jyz7dYPbQ5D8/6K+vPGP7Evxu8IWjXq2lvq8a9RZuzt+RQH8s18n3un3+mXktlqMD29xC21o5F2sPzr2sNj8JiIf7NM0hOBToo+fcn9yT+KvdPhJ8AvGfxe0+fVNBaGC2t22s8rkfN+ANdOJxMMPDnrGtb3DwuivaPin8DPGHwnFnLrbRXEV+xWM27E9PXIFSeF/2efil4rjFzZ6X5EDDO+U7f/r/AKVzf2lh/Ywrc5n7aJ4nRX1Z/wAMf/EbZvfUdPR/7vnVT/4ZO8dw/wCs1Cx/4DJXDDOsJ/OZfWKJ8v0V9MP+y144Rv8Aj+sv+/lcvrv7PnxE0WH7StvHdLnH7p9x5+oFawzjCS9znNIYmjP3Dw+irFzbT2d1LY3UTQ3EH3laq9e3D3/gNQooq5pthfaxexabpUElzdztsWNVonyQ+OYFOivqzwr+x78VtfCy3q2+lwt1MzHeMf7IB/WvWIf2AfFbw738V2cb/wDXszf+1BXzlbPcDD7Zze1gfn3RX6Aal/wT5+Ikdt9o0TW7LUZM/dYGLj/x6vk/4jfBr4kfC0lvF+jPBbA4WZfmRvxFaYbOMJiJ8lGfvmkK0Dy+ij+FP9uivo/Yz5/fOmcD7Y/4J+pv/aT0T/rhO9ftp8e5t/wb8Z/M3/Hi/wAu6vxH/YCcr+0lpHp9nuP/AEUa/aD48XP/ABaDxnB/04vX888TTnDOaMIHzGI/in4N/sl7H/aC8KfL8nmvX7ofEO4a48LeIQ8hfzdPuV259Y2r8KP2S38n49eFZP7ks71+2/jq8/4pbXH/AOnG5/8ARZrp4m/36jA0xPxwP5x7n57qWT/af/0OvZP2b32fHPwlJ/09V4vN/wAfEv8AvSf+h17J+zr8nxr8KSf887qv2PE/7uetP4Dm/i3/AMlM8T5/5/5//Rhr9KP+CdX/ACJPiz/sIRf+i0r80/iy+74meJ/+whP/AOjDX6Wf8E6v+RJ8Wf8AYQi/9FpXx3E3/IlOafwH6Ef/ABT/APodRvUn/wAU/wD6HUb1/IsDSYVG336HfbUb/NWpnAjeo6kb79R0GxG336jqRvv1HQaEE33qiqWb71RUAf/W+4KsQ/dqulWIfu1/m2f0ISVKn3KiqVPuUATpUiVXqRKDGZcSio0qSgxJEr81/wDgor/yB/BP/Xe//wDRUVfpQlfmv/wUV/5A/gn/AK73/wD6Kir77g3/AJG0C4fGeP8A/BPbH/C97rP/AEBrj/0EV8T61/yH9W/6/Ln/ANGNX2x/wT5AT46Xkn93Rrj89or4n17/AJD+rf8AX5c/+jGr+n6M/wDbpmn/ADETMuitTQtC1HxLrlhoenqPPv5khXJ7ucD+dfeF5/wT2+JFnpX2/wDtuzeTbu8nHzfTO7FduPx9HC8kJzOmdaEPcmfn3RVzULK70zUrrSb5ds9nI8bfVDg/rVOvShOEzQ+hP2XvBtn4y+LdhBqkfmW1mrTkEZ3bOn6kV+umt6vDp+ky6heSC3s7OHc21ckL/dr8x/2LX2fE29k/552LvX2p8frl4fhL4j2bt/2X726vwribnxGYwozn7h83jPfrHm8X7Vvw31HxLH4atfOLSSLGH52licf3a9wuZo3/ALrxP95W/jr8U/D2/wDt7Sn3f8vlrX7MO6b4kj/up/6BXNnuT4fL50fq0zmxOG9kfkf8S7OCw8fa7aQfcjunq58LPA7+PvGNtojjNsnzSH/ZqD4o/P8AEbXZP791X0v+yRpSPb6xrm397u+zrX6jjMZ9XyyE4Hr1p/uec+wNE0fTtB0uKxsYltreBdny15P4s/aP+Hfg65n0+FH1ORT/AAfL+prU+O/iCfwj8ML+9tm8qe4ZbYMO2/8A+tmvyr/eP+881t8n3vmr4DIcihmEPrOMmcOGw3tYc8z9JNK/bM8F7kTUtFvraL/Zkr648A+OPCHxB08an4TvzKVGZFY/NG1fhP8A9dNv/Aa+hP2ZPGl/4Q+Kel21u5FnqzpbTIT1yePyOK9fOOE8JClz4Y1xOAhCHPA+4P2rfgpY+JfBk/jbS7JE1fSU3SFF5kiHPb+6Mn/Ir8l7b/VRf7df0gXulQanpt/pUq74rqF4W/3XGDX88fiLTv7H8R6hpW7clrdzRL9FdgP5Vlwbj51aM6MzTATnM/Wj/gneu74Yavlf+Ykf/QUr7w1f4feGvGN5pF14ishe/wBkzNNboT8plPqO/bg+lfEf/BOFN3wr1r5f+Yk3/ouOvqz9on4pyfB74Q6v4stMC/IaC3BG3DP0bHt1r8uz6FarnPsaM/iOKtD96anxK/aV+DHwbmNj4o1mNr+MAm1txlwp6KfT8a+d73/gph8Gw/lwaTq06p/Ftj/+Kr8O9a1rU/E2pz61q9699eXknmSE8DdWe/3/ALq1+rYbgTCcn+0z5pnbDLYfbP3Af/gpN8HX/wCYHqv/AAJaz0/4KI/BO8uPInsdSs0/56MtfifR/Ds2r/wKu2HAmWGv1CB/SR4P+JXhD4iaK2t+ENU+0QJtLDoyZGcMD0r4f/bX+C1trvh2X4maJapb6jYYNwiD/WKSBn68/wCcV8t/sX+N9Q0D4vW2i+Y39nayDHImflyASD+lfq548s/7Y8K67pU/zpdWs8Vfl2Jwf9iZpCFGfuHmVoTpTP539nzJs+5uSv1A/Yl+T4Xaj8oZvtr9R/spX5l3MLW95Pbj/lhcSR/9+2I/pX6WfsXvt+GV+p/5/wBv/QUr9W4snz5Yenj/AOFzn1B4g8OaLr+oWF1q9uJ2s2LRqfu7vp3rzPx38a/APgIva63fiS5Trb2/zOufX0/HFWPjd4+f4f8AgK/1uDAuZv3MI9GP8WPbrX456jfXmr3Ml5e3DyzyvmQ/7VfAcOcPTxsOfEz9w8jB0faw98/RCb9rbwKCw+xXzr/CwRP/AIqst/2pvAUnSyvR/vKi/wDsxr8+/k/gWj5K/Q4cIZd8H/yR68Muon34n7TngCaVI5Ir2FP722voDwl4l0HxTbf2noN/54QfMpGNv4V+Qe9/9Xu+X+7X0p+zB4hutN8fJoaNvtNUXYys1eJmXDOHpUvbYY5q2DhGHuHsn7Snwwtr7Qv+E20yERXlm374IPvL6/hXwP8AX/gNftB4m0tdX8Lavp8y8TW7Y9ivT9a/GN/vvHt2bGdP/H69fhDHzq4ecJmmAnzw5Cv8/m/d3/3V/wBuv1o/ZV+DWn+EPCNr4s1S3SfVL+MTLvXmPP1/Ovy78J6Z/bPibSNKzxdXcUZ+jOAf51/QBodhDYW9rp0C7Y7ZEjH0C4ryONcf7KEMND3eYePn9iByfjj4meEPhlpi3njfUTE+Nyog3Oef7v8AkV8xyft9+BbO4Mdv4f1GaIfdbKLu/wDHq+J/2m/Gl941+L2srdOTbae720cOfl/dnB/M5NfP/wDD5dGUcG4SeH9tiZihg4T+M/cj4X/ti/Cn4h6mNIuDNot43+rS4GVk+hGR+dfWmv8Ag7QfGui3PhrxFax3tnfx/KG+Ygj+JfQiv5f4DJBcRS28hiljbMbr1Vv8iv6HP2QfGVz8SvgRoevagS15bFrNmJ3E+X36emDXx3E3D8MqhDH4OZzYnB+xnzwPxL+PXwtufhB8T9U8IMrfZVPn27N1aI9On5fWvG6/Vz/gpt4RiiufB3jTH7+58yzkH+xEQ4/WQ1+Udfs/DmM+t4GFaZ7cJ88Oc+zP2Cp/J/aN0h9vBt5l/wDIbV+xnxyud/wj8Z/7di9fjP8AsMPs/aH0eT/phPX6+fG65/4tT4sz/wA+UuP++Wr8h4m/5HNE8rGfxYH4h/sov/xfXw1/11ev2k8dTbPDGuJ/043P/os1+Kf7LT+T8bvDT/8ATV6/ZTxtced4Y1p/+nO4/wDRZro4l/5GNEyx38aB/Pvcv/pEv+8//odewfs8P/xebwv/ANfSV4/N/wAfEv8AvSf+h165+z98nxf8NP8A9PSV+y1v90Pan8Bz/wAVf+SleJP+v2f/ANDNfpZ/wTq/5EnxZ/2EIv8A0WlfmX8T3874i+JH/wCn2f8A9GGv00/4J1f8iT4s/wCwhF/6LSvjeJv+RKc0/gP0I/8Ain/9DqN6kf8A9mf/ANDqOv5FgEyNvv1HUjffqu9ahAHqN6HqN6DYj37qjd9tSVBN96g0Ed91R0UUAf/X+4EqRH21GlFf5tn9CFhH3VZT7lVofu1Ij7aALFSJUdSJQYzJEerG/dVdKlT7lBiTpX5r/wDBRbP9j+Bv+u9//wCioq/SSvzb/wCCi2f7H8Df9d7/AP8ARUVffcG/8jaBcPjPG/8Agn43/F7b/wD7A1x/6CtfFWvf8h7VP+vyf/0Y1fZv7AM2z423mf8AoB3H/opa+Mte/wCQ9qn/AF+T/wDoxq/pqj/v0zT/AJenY/CDj4o+E/7p1K1T/vuRRX9FmpXP7q48tdm9X+7X85/wqmS2+Ivhi4f7seoQS/8AfEgNf0KXN5vil2Jv3q7r/t+alflXHHv4uicOM+M/nX+ID7/G+uP/ANPc/wD6Ga5Ou0+J1s+lfEHxBY3W7zY7x/4a4tHR1d03bE/2a/cMBCH1SjOEz1oe+fXH7Gz+T8S72T/npZulfZH7QM2/4S+Jf+uG2vjf9jy2kfx5qd9B88UFr96vrD4/Xnk/CPxB/wBN1RK/GM7hz5zDkPAxMP3x+U/h759Z0f8A6aXlrX7CPN+9i/3f/ZK/Hvw8+zWdK/2LmFv/AB8V+vH/AC3i/ubU/wDQK9fi+H72iGP96cD8r/iX8nxB1tP+nrZX2R+yKn/FG3rp/wA/VfHfxU2J8S9d+b/l6r64/Y7v4ptF1zSM/wCkWcgn/wB5Tx/SvWzqHPlMOQ6a3uUTqP2un/4tzZb/ALn9opX5x/8A2f8A6HX6uftJeGpvE3wmv/sQzJYSLcj5c7scH9Ca/KPfG/7z5vvf3a04TrQ+o+4aZbOE4cgV6B8K97/Ebwv5f3/7Rgrz/wC++yvoT9mTwPq3jX4y6HbabETBYTC5mcj5QsZz+pwPxr63Mp+ywk+c9KtyQh75+8FhbbGl+X5H2f8AAa/nb+J+xPiLr+z7v9oT/wDow1/RhdXKWGm3t+/3LWGWVj7RqWP8q/mz8Xakmo+LNV1XkLeXssi4O7iRyetfjvAnx1jyst+2fsZ/wTRXd8Kdc/7Cjf8AoqOo/wDgprM9t8LfDVrG37q61N9y1of8Ey4d3wm1nP8AHqjf+io6p/8ABT6HZ8N/CW99n/EzevN/5qc5p/7wfif/AAUUY+X7v9//ANDox/stX9DThA+nnAKKMf7LUb40T95u/wC+azhRhM5uQ90/ZsmdPjh4R8v/AJ+vmr9sNeuf9F1D+5tnr8a/2T9Avdb+Nehy2sZeKzZ5pG7BcEfzIr9ePEl5BbaDqupTtsiggnevw7jLknmNHkPAx/v1YH4H6x/yG7//AK+5/wD0Nq/RT9jN/wDi2+of9hFK/N/ULhJtRubrdxNcSOv0LE1+in7HU234dXmf+ggf/QBX1vEfuZYduM/hGf8AtjXj/wDCM6JB/A9077a/OtPuf+hV9+ftjfPoPh//AK718Bp8ifdr0uFuT6ia4Dk5OQkoox/stRX3R6QV7J+z87p8WtC2fxs9eN/u02fM27/dr6A/Zj0S61j4saZPAreVZb5WbbXk5xyQwk4HNW5OQ/VS7h/0G+T+/b3H/oBr8Mrr/j+vP+u83/oZr9zdcuodM8P6lqk5wtvbXEg/4ChI/UV+F9y+64mm+8ryuy/i1fmfBUPcmeTgIHoHwiTf8UPC6bf+XxK/fSGH5n+T+L/2Svwz/Z20O51/4x+HrazjZ0gkEkhA+6gOe9fvRCm+63ovybk/+N15HHGJh9YomWMhCdY/nf8AiQ/nfEPxLJJ999Rnri69k/aC8LXngr4veIdIvAzied54WKhfMSQk9j+H1rxv/rn92v2PAT5sJR5D24Q9wkTfv+T/AJ6wbf8Ax+v3Q/4JsW7v+z4PMb7mpXH/AKDHX4X7/JTf/HuTyl/vv/cr+ij9g3wXqHg39nnRrPU48T3kjXhyCp/eBcZz7AV8Lx3OEMu5Oc4cf7kD57/4KgQ7vh74OT7rfbbr/wBBjr8V9m2v18/4Kl+Jbby/BfhaFj54ea5kA7I20D9VNfkHvR/vu3/fNejwbRnSy6BrgP4Xvn15+xC+z4/6U/8A0wnr9aPjNc7/AIWeLY/+nN6/J/8AYes57n452l1ArPFa2s7s22v1I+M1yn/Cr/Fr7vk+xvX5xxN7+c0eQ4sTPnqwPxj/AGY32fGnw1/11ev2E8Z3H/FN6wn/AE53P/os1+Pf7Nn/ACWbw1J/01ev1s8YP/xINY+b/lzuP/RZru4m/wCRjRM8d/GgfhPN/wAfEv8AvPXrHwHfZ8WvDn/X0leTzf62X/ef/wBDr1T4Gvs+K/h3/r6Sv2Sf+6HtVfgOb+JPz/EDxC//AE+z/wDow1+mn/BOph/whPiz/sIRf+i0r8y/iM2fHev/APX7P/6MNfpp/wAE7cf8IT4s/wCwhF/6LSviOJv+RKZT+A/Qz76/8Cf/ANDqOpN/y/8AAn/9Dqu77a/kWBiDffqu9SP81RvWpUCN6jb79SVG336DqI6gm+9U9QTfeoAiooo30Af/0PtxKkqNKk37q/zfP6ELEP3akqOH7tSVmBYSpEqBPuU+gzLCVKn3KrJVhH20EzJK/Nf/AIKK/wDIH8E/9d7/AP8ARUVfpQnzV+a//BRX/kD+Cf8Arvf/APoqKvv+EP8AkZwIh8Z4f+wVL5XxqvH/AOoHcfn5S18ea5/yG9S/6+Zv/QzX1v8AsJvt+Mt5n/oDXH5+UtfJGuf8hvUv+vmb/wBDNf0zR/36Z0/8xImjag+k6rYar/z5zJJ9cHNfvx4H8a6R438F6X4l0i4Ro5YV3puy0b9x+Ffz5/xJ/sV7R8Jfjx4x+D9/s0qWO80yf71lJXk8TZFPM6PPD4zlxmDnM/QD40fsw+HviN4ifxLpV2dG1F/9Yu3crf7XUc18/t+xNrsLKt94ij2f7Mbc/rXYQftu6NNbj+0vDs0czfe8qT5f5VG/7Z/hl03/ANh3f/fyvjcH/bmEh7E4uSr8B7J8MfhXofwl0R9NsZY5ruf55Z2avF/2qfGVrY+E4/DUcgN1fybmQHlU/wDr1x/iT9sD7TZNHoGhtDL/AHp2r4317xPqfi/UJ9X1ubz52/8AHfavSyrIcXPF/WcYZYbDTnPnrGfauba/t7rb9yZG+ig1+uHhjVbXXtEstYtfnSeJH21+Q/z/ACfN/vV7x8MPjvq/w7thpl1bnUbD03bdv6GvpOJsnni4QnRO7GYadWfuH0Z8Qf2Z18aeJJ9b0y/SxFwcshXd835iuo+DXwC8UfC/xI2r/wBsx3FvKnlyR7du7v6muTtv2w/B23emg3f+181akH7ZHhNG/wCQFcD64P8AWvhZ0c59j9W+wcM4Yjk5JwPtz7DbXatbXMYkgbgj/Zr5P8efsV6R4n1OfVPCGqf2M8r7vs5QlMf72c/oay4v21/BkPXQL78Cn/xVbEP7dnglE+bw7esfQlP/AIqvEwGAzzBfwTmhCrD4Dh9J/YB1dr0JrfiaJYec7UZm/XbX6CfBf4KeD/g7ov8AZ/h5TLeOv766f7xb/Cvku2/b78BRf8y3e5/30/8Aiq2Iv+ChvgKPr4Zvz/uFP/iqMyo8Q433DWftpn6Ca74Xi8S+HNQ0PzDD/aFu9tuX5tvmAjd+FfmWf+CZniuad0svGFv5WcrmBv7zf9NPTFeiQ/8ABR/4fQlWHhS/b8Uz/wChf1rct/8Agpp8O7ZefCOp/g8f/wAVXNluDzzL4cmGgEPbQ+A+vP2W/gM37PPgK48L3GpJqk9zcm5aZV29VRcYyf7vrWH+1b8Apf2hfCdhoNnqiaXcWE3nqXXcrcEY6j1r5rl/4Kf/AA+k+54U1FT7mP8A+KrPm/4KZ+ApeB4Uv2X3Kf8AxVcP9j559b+ucnvnNCjPn5zwub/gmx4yi5bxXZr9Ym/+OVnt/wAE5/F//Q12OPo//wATXtjf8FHPAr/c8Laiv4x//FVj3P8AwUP8Eu3/ACLt/wDmn/xVfZQxnEP2/wD209Hnqnjc3/BPPxfE/wDyNNj+T/8AxNRj9gXxLBIPtPie3MQIzsRj9euK9Ul/4KAeCZW/5F2//wC+0/8Aiqy7j9vHwYzf8i3e5/30/wDiq1+s5+a89Y90+D/wN8K/BbS5U0qdrzUrpdjXbVufETS73xL4W1Hw1plwsEl5Ht3tu455r5bm/bn8HP8A8y9fVlv+2r4Sm+5od4n+9XyNbJ82q4j6zOHvniTw1aczz8/sV6/CA8viKHd1GI26fn/SvpD4TfDhfhV4ak0E3Yumebz2dRj5sAe/pXj7/tk+Fd+9NDu/++qz3/a98MP9zQ7uvpMfRznF0fYz+A6ZwrTgemfGb4an4n6PZ2VvdC0ktG3ZYZ3e1fMb/spa0nyprcP/AHx/9nXoD/tXeGZv+YLe1Tf9qLww7c6Nc1rg/wC2cJS9jRgFH20PgOHT9lXXXb/kMQ/l/wDZ1c/4ZH8QM3/IYh/74/8As67BP2pfCqN/yBbutBP2tPCK/wDMDu69L6xnn8h3e2xf2Dl7D9jzWPNRH16JP91a+tPg/wDBzQPhdYSwac7XN7P/AK2dq8HT9sPwcn/MBu/++q0Lb9s/wWn/ADA73/vqvEx/9uYuHJOBzT+tz+OB9UePvCep+LPCeo+HtImWBryPbvbtzzXxna/sI+JXVS3ieHn+5A3H/kSu4H7bPgnGH0S8/NP/AIqtSL9unwTtVP7Avm2+6f8AxVc2W4bOcFR9jRgaUYVoHvnwI/Z98NfBqOTUPO+26jL8punXbt+g5r6khtp9vkQbXuJPnWP/ANnr8y9Z/b+toYWTwn4WcTkcNdNuVfyA/nXx+/7RPxdk8dr8QU12VdRQ58vA8rbnO3Z0x/8Ar61lPhbM8y9/GTCGAnW98/Yj46/szeEfj3YRTu8mm6xaq6RXarXw3J/wTh+J5k22Wu2UsC8AvvVvy2n+dd54O/4KOQwWUcHjrwsZZ4sKZrV/vfgf8a9o0/8A4KOfBRYt66TqaP8A7qn/ANmrpo/6yZfD2MPfga/voTOT+DX/AATdttD8RW2vfE/VodUjs23La26uFYe7hgevbAr9WI7Kx0Wwt9NsIlgt4IxHGg/hUV+ccn/BTP4TWf8AqNC1OU/7qf8AxVc3c/8ABTf4dzHCeFtR/OP/AOKr5fMstz/M58+JPMrQrTn752n7Vv7J9z8fPGVn4v0/X49Lks7RbbY4ZuA7tnjp9/0NfJb/APBOrxCrBf8AhMrdV/iHlN/8VXsFx/wUf8CzNuTwzfr+Kf8AxVY95/wUN8Cyjf8A8I3qO72dP/iq+owH+sOHpexh8B3Q9ryHtnwU/Z/8L/AvSrlbO9+2395uEl1txtBVfl78ZFeb/tbfEHTPCfwzv9ENwDqWsr5EcQJzsPU8e3868f8AEf7fcN5ZFPD3hhxMej3T9PwGf518B+OfiD4l+I2vt4h8S3fnzD7qjhV+gruyvh7HYjF/XMeaQw0+fnmdx+zq/k/Fzw1/fRq/VzxhN5ega5833bWYf99IRX4x+AfFDeBPF2neJTbtPFZtyq98jFfYniP9r/Rdb0e/srLRJo57iNlBLjj3+5Xt59lWIxGOhOB1Yyjz1YHwm6b5Zfm+4z/+h16h8Fvk+Kvhz/rvXl6O/wB91+d/mr0z4LfP8UvD7/3J6/Q63uYfkO2r8Bz/AMQv+R88Qf8AX5PX6cf8E7cf8IT4s/7CEX/otK/Mf4i/8j54g/6/Hr9NP+CduP8AhCfFn/YQi/8ARaV8fxN/yJjmn8B+hjvs/wC+n/8AQ3qu/wA1SP8AP/4//wChvUdfyBAPsBUbffqSo3rUIEdRt9+h321G/wA1B1BVd33tUjvVegCN6KHooA//0ftxKkSo0qRK/wA3z+hCRH21Ij7qr1Yh+7WYFhH21InzVXqVPuUGZOlSVGlSJQTMkR9tfm3/AMFE8vo/gj/rtf8A/oqKv0gr83/+Ch//ACBfBH/Xe/8A/RUVfonCH/I2gRD4z5//AGHX2/GW5/7A1x/6KFfJmt/8h7Uv+vmb/wBDNfV/7EWxPi9cvu/5hFxhf+2Qr5P1tT/bmpf9fM3/AKGa/pSj/v0zo/5ezMuo3T/aapKK+k5DpI9iJ/CtS7I/7opKKAD5P7qpR/31/wACoooAKNqUUUAH/AVf/eoyn9xaKKDQX5P+eS/980j7H/5ZR/8AfNFFaQ9wOcNqf3F/75qN0/3f++akoo5zME+T+7/3zRRRRzmgfJ/y0VXo+5/q1Wiisw5wx/s1G6RvUlFac5mGzZ9yj/gKv/vLRRRzmgfJ/dX/AIDRlP7i0UUAGU/uLRlP7i0UUcgBlP7i0Y/2Vo31Gjo6/eo+APcJMp/cWjKf3FqNH3VJR/jAZsj/ALoo2R/3RT/n/u7/APdof5P7qf71Rz0f5w9wERE/hX/vmlz/ALCf980n+flo+5/rK054T+2HOH8Hlyf+O/JR+7T7m7/gTUb0dvkffRRPkH7OBG6RvQibF/hqSisuQQfw+X8v/fNRpDH/AHV/75qSigzDZGn8K/8AfNHyf3V/4CtFFac4Bj/ZWiiiuacOcOQP4KPn3eZuaiitQCvUPgn/AMlS0KP/AKa15fXqPwT/AOSpeH/+u9cWM+CczOt8Bz3xF+fx54g/6/Hr9NP+CduP+EJ8Wf8AYQi/9FpX5l/EVNnjzxAn/T49fpp/wTwx/wAIP4sk/wCohF/6LSviuJv+RMcM/gP0E/hX/gf/AKG9FH8B/wB9/wD0N6K/kWPwGkCN6jepHeo3egojb79R0P8ANUbvtoNBk33qiqR33VHQBG9G+h6joA//0vtlPuU9HqOpEr/Ns/oeZJViH7tV0qRH20EFipU+5VZH3VYR9tAElSI9Rp81SJQZklfnn/wUJ0i8uvB3hbW4kJttOu545z2Xz1RVb9DX6GJXF/EHwPpHxJ8HX/gnWgDBqS4DH+FwcqR9CK+t4cx8MLmMK0zCfuH4Z/Aj4iR/C34i2niXU4d+mxK9tcEH5grr1A9iAa9o8Z/s4WXjQXvjr4I6tDrlteM08lmuFlifJ3DJf9Dj8a8H+Kfwc8ZfB3XZNL8SwkWzSMkN8E/dSr/Cf9kkdjyK8/8AD/izxD4Qu49U8L3s2k3inDlH+VgexHf6V/V86PtZ/WcHM2n78+eBX1zRtS8O3bWOqWz2s6feWVdp/Ws/7n+s+SvrzTP2iNA8ZWg0z45eHU1G2bKreWqqswz+I/Qis/UvgP4S8YRPqPwg8RwXiP8AOtlct5Myf7H+so+v+y9zEihieT3JnynRXUeJfBXijwhMbbxFp0loV6MR8p+h6GuX/h8yvchWo1fgOmE4TCij/vr/AIFRXQdPIFFFFBmFFFFABRRRWYBRRRQAUUUUAFFH8dCJQAUUP8i/eX/d3fPXQaN4R8TeIjs0TS7i7b/YQlf0rmniYQ+My54Q+M5+jem/y91fQmhfsw/F3WiP+JWLQN3mO3/E/pXtGg/sXXUO2fxT4gVFxzFajdz9Tj+VeJic9wOH+OZzTxMInwnv2P8A+zLRCj3PyWiyTP8A3VWv1E039mb4UaJ893bS37/3p5K9EtPCXhfQgV0XSbe3KknIQbuffrXzeJ4ywkPgPOnmsITPyr0z4d+NtXRZLPRrgo5xuZdo/M4r0DTf2ePiTf8A+vs47b/ro1fo5Ncz7fkdtn91V2VXTe8qeZud3/2d9fN4njKtD4IGVbMpnxPpv7JmvXmw6hrEVr6qql/8K9E039kfw1CU/tHVriZ/SLES/rur6wS2RERHX5/9n+5/38rU8ywsFRr+5it1w23znCbtnXrXz9biPMef3Dm+uVj5/sP2UfhWmzz4ru5f+9JNXcWX7MPwfg2p/Zbv/vSyf417J59nbWx1K6uYorVF3eYzgJ+fSsvSfid8O9Tv49Os9ft5LmUgIu7lm9vWvJ/tXNqvvnNDE1p/GcfD+zD8Fw3z6AG/7aSf/FVqQ/sqfBOb7+g7P92SvTL/AMc+BNBv303XPENlYXafejkkrYsPiN8OroLJD4nsG+bb80yr/M04Zlm0zphOtyc55PN+xt8DL9PL/syeH/dmrm9T/YC+E19Hs0i91HT5/UOjJ/3yV/rX2RoGoaZr8a3WiXsN9Fu2s1u4dR+IzXcWEW/51KzfN95W3V5kOI82hzmf1msflfr/APwTb14FpPC3i6K6AX/VXUGxv++g5/lXzn4v/Yo/aA8KRGU6IuoRrzm3cN+nB/Sv6ALNIJmRHRXf/d2ba6izttmx0Zk/vr/BXpYPj7HYf3K3vmkMfOED+TvWdD1nw7dfYdesJtOlH3lmQofyOKy/+Wvl7fk/vLX9VHj74V/Dfx7YtZeLNEtbouP9aqbZB/wMc/rX5V/Hf/gnt9njn174N3W7YuTYuPzPmF/rxt/Gv03KuOMJjfcn7h6WGzL2vuTPyrorQ1fR9T0DUJ9I1q3e1vIjh0cYwPVT/EPes+v1GE4fY989uAUUUVoAUUfu9n+1Q+xF8yRv+A/x0BMKHruPDXw18b+LGT+z9LdYJM4mf5U4/n+FeuJ8Ovht4AX7X4/1mPUtQT5/sVp89eRWx9KE/cmc08TCB4X4e8K+IPFV19k0CxkvJf8AZWvojw/4Q0X4NyjxZ4z1GOXVEQtDYwtuf/gX+ce56Vy+r/HTUI4DpfgWyXw/ZjB8xeJWx7jp/P3rwe9vbm8upL3UZmkd+rudxrn/AH2I9yfwGXvzNDXNQfWdbutRnXa1/I0n0yc1+rn/AAT40y9tfhhrOryxgQalqBaEnqQsaD+YxX53/B74G+NvjRrsdl4atDHpcDobi+cFYlUn5lB6M23kDP5Dmv3g8E+E9F8C+GNO8L6DD5dnYR+WCOSx7sT6nvXwHHGb4fD4T6nCfMZ1p+/yQOodNjeXJVd6kd5Hb95UbvX8uQnzhAjeo2+/UlRt9+tTYjqCb71T1BN96g0IqjepKjegCN6KHeo99aAf/9P7UR961YSqaPVjfX+b5/RkywlFRo9SVmc5Yh+7UlV0fbUiPuoAsp9yn1Gj7akT5qDMkR6k+d/k/g/u1GlSJQBj6/4c0PxXpb6H4isotRs5PvRyqGX8jXwH8Vf2B9L1EPrPwivf7PuMs39nXGWifr0fkr+TfhX6MIm6jZ/z0+dP7v8ABX1mVcR5jl8/9mOSEOSfOfzn+NvhV8QfhfdtZeLNCmsZCeLjb+6df9luh/CuL0+e402ZbqxleGUNkOrFW/Sv6XNZ0jSdfsm07WrKG+tX4MVwgkQ/gcivjP4g/sL/AAw8VySXPhOSXwzeSjjb81vuA/ucfoQK/bcq47wmLhyYmHLM6p1v5z839E/aC8badaix15E1ywOQUuhltp/n+Oa6RH+APxFfy51k8ManJ/Evzw/+0qufEL9j34z+B5JZrfTRrthEeLizO58AZ+5jd+Qr5fvYLzT7p7HVYmtJ0+9HMpVvyNffwhhMR7+GmZexoz+CZ9Cal+zb4o8hr7wnf2+uWiDcGjf5/wDvnkf+PV4nrHhXxH4ed01zSruzeP8A56Q1X0XxJrXhy5EukX8lrI3A2Pxj3Xv+NfQGh/tPeNrZEsPEtpDr9sBjZcRLuK/7w4/MGumf1vD/AB/AEJzgfMaPvXenzp/s1J/1z2vX2Ani39mXxzLs8VaHP4SvX/itvuN/t1cuf2b/AAB4wTf8NfH9pNK/zrbXv7l/++/Mo/tLk+OBp7aZ8Z0V9IeIP2T/AI3aBGLldC/tCCXJV7F1uCce33v/AB2vD9c8I+KfDLvBr+k3Viw4xLEw/mBXdDGUZ/Ad0Jwmc/RUasXbyY/nl/55oNzfpXoHh/4VfEjxSQug+G76cMM7/KITGM53dP1rSeJpUv40zKc4HB1Js+X93tr7U8F/sCftB+LhHLeadHoto5+Z7iQZx/urk19WeEf+CZ3hfT0jl8beJ5b+Rfvx2sflRfqzGvm8ZxNl2H+OZzTxkIH49/J/H8j11nh3wF4z8Wyqnh3R7q+B/iSNiv5gV+9nhn9lL4B+CCkth4YjvJ4znfdEy8/Rsj9K9gjtbGwh8ixtIbZEXCrCioPyGK+JxPH2Hh/u3vTOKeP/AJD8N/Cn7F/xu8RASy2Eel8/euG/h/4Dur6U8N/sCeGrCNJfF/iKW6l3/vILVNq4/wB/cf8A0EV2n7Wvxq8e+E/FmjeAvhvqUkV5Lbtc3BwG+Riygcj1U16J+zP8TdQ+JPwrsNT165e71G1kMExf73GDnp6EVzZlmuZ/UfrkPdM54mtOHuGfoP7O/wACvDMy2dlpMd1eLubMjl2/U4r1i1tdN0mLy9KtIbSL+7CgUfkMV8B+Cb+6/wCGytbtJ5ZHt089VjZq++Lmb5fvV8TnX1ulOHPW+yeZW54fGcH8QviFo/gPQX8R+Jml+zo23ctcP4C+Kvh74pWtxqHh5JkjtpFjy+Afn+hPoa8r/bDudnwvij++j3ifLXlf7Mlwvhrxj4h8L3LlFlt0vIx/wHcPzBFe3gMlo4jLoVvtmf1bmo850nxF/aYvPDHjGfwnpmlw3C20xjaZnxlh142H+demfE34lW/gTwdHr06hr+4j/doOMtX53+JpP7WvL3xZIctPq8qD0IQI2f8Ax+vdP2jbx7z/AIQzTt37p4kdq+pnkWHhOHuHV7GEIQOXf4kfGzUrdPFVpFImn7v4Y96V9WfBb4lL8R9Aa5nUx3luWWQDjPy/ertNJ0O1h8LWvh2Jf9G+zqhHXLsuC35818p/s7SLofxW1/w0gbawlA3H/nm2P61y/wCz42E+SHJynRzwqnSfAfVdV1j4v+I7W+1C5mt7XfsVpP8AbrQ/bAufJtfCkCMyeezu3zVh/sxw+d8YvFH/AAOtj9seHZe+DkH8Qm/9CWn7H/hWhAzh78/fKf7TfibUNF8J+EPBOiSeSL+0U4ztyFUDFV/A/wCyZ8QdA8R+GPF97JayWsVxDPLGjEOqqVfpjGeMdaP2ttFurK28DeIol3RJaRRkkdG2k/4/lX2x8BvixovxW8NWws5QuqW8KxzW+ehVeT+NdOZYnEYTA/7N738xpz+57h8t/Hr9lz4mfED4j6j4v0G2tW05lQLl8NtQAdMY/WvjPwP8KfG3xE8SXPhPwvZJPf2aM7AMBwv1+tfvxsge1uJ/KX5ILr7v+5X5j/sIwC8+OniG5T5ZEgl5/wC2rVlk+fVp5dOfJ8Jpg8T7h9Mfs7eDfFHwS+A3i+48Xwiyv4DNcoCQc4iX0/3K+H/2bfit46g+N/hltY1e8bTtWu2BjaU7GMrYyR064NfpZ+2DrkXh/wDZ51mVT5cl/iPrndk8/pmvzT1XRH8B+GfgZ418jY9632iX+D/VT/365sq/2vCVq1aHxhDkmfr5+1F8QfEvwq+D+o+OvCciR39vPCo3jOVdwp/nXwH4T/4Kb/Euxmth4s8N2upwXDYEqObb/Z7pLX2Z+3SIL39lbVLlerGzkX/gShq5P9lbwh8JvFf7NHg5fFmnaTe36W8okaUIZVcTydTjOa+by2jhKWUzniaPNPmPOhD3Oc+rPFPxV8NeGfh7bfEjxRN9ksJ4YpDgFseZjHHXnIri/BXxh8BfE+2a88E6kL0RfeJBVh+BxXy3/wAFENXXTfhToHgnSIlgtdW1BYwgxnbGqk/qRXgf7IcMvw1+OHif4Z3JKRy28UkIbuSqv/I15tHhmlVy6eMo/GaQo+5zn0Z+078AtH+L+hXWsafAkGv2EYaORF5kWPcQh+pPBr8R9R0+70m/n07UU8m5tm2yIfvBhX9Il5Ns2bPk8v71fm/8cfg78EdO8cT+L/HviJ9IOpK0otYhl32AA44Pc+nU9a+k4Q4grQh9TxJ04PE8nxn5n/8AXRdldp4b+HXjjxVOkGh6NPco/wDEq19EXPxX+BHgmXyPhz4M/ti7j+7e3/3P++K4PxN+038S9ajays72PRYMYxZptPP+1kt+Rr9j+s4ur/BonpVq05+5A3LH9nNtKQ3PxI1uHRY4xv8AJDI0pXt0f+WakufGHwT8Bts8K6VJr17Gvyz3LfJv/wC/dfM97qF9qdwZ9VuWurh/m3SuxJ/E0aXp2razcjTtJspbu4f7sVqhlc/gATWc8BOfv4mYex/nmeseJvjT498Uw/ZprgafZqu0Q242qPr3/M14399nnnkZE/ikk+Te/wDv19YeAv2OPjd41aOa+03+w7NjgvcHEqjGd2zg/nivvT4a/sQfC3wcY9Q8UK/ibUV+8LgDyh/wDkfnmvIxmd5Zl8PjCE4Q+A/KfwH8IfiL8U7xbbwZokt3Hu2tMw8uIfVzgfrX6MfCj9gvw9pAXV/ilcHULyQKVtYsqkR46t1b8h+NfoRp+n6bo1olhpFsllbou1ViXaB+AqwfuJX47mniBiMX7mA92ATnzmXpWi6RoFjHpmg2sdlZxHARB8rE9296uOm2pHfbUbvX5JVrTqz9tMyhCBG9RvUjvUdcx1kbvtqN/mqRvv1HQaEbvtqN33Us33qioAKjeh6jeguBG9R76keo9laGvIf/1PsxKuJVNKkR6/zfP6MmXEqRKr76kR6zOckqxD92q9SI+2gCxUqfcqsj7qsI+2gCSpEeo0+apEoMyRHqwnzVXSpEfbQTMkqT7/8ADUafNUiUThz/ABmJJ99dm5v+AtXB+L/hR8O/iBbNbeKPDtndnr5/lATDjHDj5v1ruKkR69LB4zEYf/dpkT98/Pfxz/wT28G6rFPd+Bddl0O4x8sMi+bFn8wf1r478X/sX/HXwiJWg01NZtojw9i+SRj+4cN+lfuh/rP9irG+fzfM81t/96v0TLfEHM8P/vMOcIc8PgP5i9f0PXPDt19i17TprGX+5MjIfyIFZ8O+Fd8G6H/db/43X9NmueHdC8SQNBr+n298jcbZ4lkH5Mpr5n8WfsUfAPxRO95DpMmizsCCbGXyk3k53bMFfyFfoeD47wOI9zEw5ZnT7bkPxz8IfGL4l+Ciq+F/El1BGT9zexTrn7rZH6V9GaT+3N8VrUC28WWWmeIraMYxdQKz/wDfSlf5V7h4v/4J0hoZJ/CHjIuy5IttQg/LM8bfyi/xr5r8TfsUfHzw6JZ4dHh1mCE/fs5geP8Atr5R/SvqIY/KcX9sz9tD7Z9SfCL9rT9mm/1JLvx58PrLwxez/wDL3bQ+dD/3x+6r9TPh58Rfhb4v08XPgjWNOnjbpHEFicfUHkfiK/mX1z4V/EjwyI217wze28bDO94CQBjP3l4/HNc3o2u634evDcaLf3Wnzxdw5iI/EV52a8M0sw/3asc9bCUavwTP6zNSm2bPP8z7v/LSubvLn915e6v5/wD4d/tx/HnwQfsd3qya5YKeUuvnfpj7/wB78zX2R4P/AOCiXgzUxFbeNtEm0lwCWltz5ik9vlwD/OvyDH8D47Dz/mPM+rTgfohcumyubublEf8AeN8ib3Zq8v8AD/x3+E3jWNF8PeJoZ5JB9xvlf8jg/pWh47vtTtvBmr3OiwnVLp7dljS3JZt54HTmvm6OT4iGIhCtA4uSfOfl2Pin4Fu/2qdc8Z+Pb37PpdotxbRrzJyEMXGM+54+nvXQfse+L7Cy+IXifwhpd0JdLvJHntmPBwGwPlJ9CPyrsP2YfgEsWn+Idb+MPhtZ7q8kHkx3SfMMA9j9a5fxn8OtY+HX7R2ieJvB2iyJoU+zzVto/kVJXeP/ANkr91xOMwk4f2bznrTrQn7hh+G/9G/bK1OR/wDlozo1fejzSPF93/x6vzf+It/4x8DftE6x4/8AD+gz38W7fF+7+98le6fC748eJviL4l/sDxB4c/s35d/mMtfN59lVXEUoVqP8pzYmjzz5zD/bCff8OrBP+n0f+gNXi+pX6eDPi1o+qxvsi1TQoN3/AG1gr1z9ryZ/+EO0u0+9i939fRSP/Zq8b/aP0uWz0DwdrULDfb2iW7H/AHV//XX0nD8/ZYeFGZ04bk5OQ8v1LTPL+C8Op/xPqkx/8dSu8+NL77LwFqL/AHHtUSrnxC0h9E/Zz0e1ki2S+akrbf8AprXUfEXwrd+JPgV4c1mxgZ7vToN23+PZXtzrfBOZ0H154fUTWNlOn3Hgh2/98CvjP4UJJ/w07qqJ9z/Sv/QK9U+FXxu8Jr4HtU1u/FvqNhGIhE3322Dj9BXm/wCzJaTeKPjBrPjBEYQZlK57+Y2a+bweGrYedadb4DzqMJwNj9mSPy/jL4piHLRJKPTo4FaH7ZZH9seC4P4lEmf+Bsv+Fc38NNb034aftHeI7HxGy2dve79skjbEo/aG8R6V8RvjL4W8PeGpherb7Yyycrlnx/hXT9Tn9ehiYfBymkIH3Z40+F+n/FD4aweF9QwtylvEbeU/wt5Q/h/nX5f+Erzxf+zp8Y4IdQDQSRSeXIB8qzRfj+f1r9cNV+IfgnwXr1h4T8S6iljftCrgsdq4KnqTx/Ca/PP9uPxD4Q8Q+MfDdx4au4tQvLaE/aJIjlT83yrn25PXvXk5DWxE51sNWh7kh4ac4e4frQbiG60Oe7tcNFPYTSqw9HhLD9K/NP8A4J8xpJ8XvFl12SBsf9/Wr9EPClpcW/wpsJbpWjlTQ23BvaCvgf8A4JyW7Xfj3x5cgcLAuB9ZW/wFeJg6PJgcZCBpH4D0T/gpFrkdh4E8MeE45P315cSyMMfwqq9/xr5f/aG+N3ww8d/BzwB4M8GSv/a/hIRxyAx7FJ8tBJ9ckDGPSvTP22YH+Jv7Svhb4YWUxjjWOK2aVRuwZ5G3NtHoMfgBVz4+fsEaF8JvhNq/j3S9fur65sFXCGIIvKgf3z3r6zJPqmFwmGo4mfvyNYckIe+fVH7Qeur4v/YJsPEUJ2i8t7A44bmKVkbp/tKc1+Wfw1/Zw+PPjjwtYeLPBNk76QxOHNyq4w2CpBINfYln4nTXv+CcFxYyNvfS54Lf/cT/AFn/ALPX0h+xRPu/Zv8ADzTkeXm4Xr/dZhXFPE4jLMDPkhz+8csPcgfKf7buvL4fm+F2g62D52k2qz3caNu/eNgHP4ofwrzOP46eE/Ff7U3hP4g+E7Cays7yGKxnjuPlBkLEb+CR3X8q9E/aItbL4h/tk+HvCeoGO60+zWBJkfP3H/enp7PW5+1B8F9I8Oy+FtX+GHh1LSSwvV8xbWMDJ6hiAOxH616VHGYeFKFGt8conTCcIfGfdmpTJDcXEaNvRP4v+AV+Wf7dN/BceKvDdrFjzLa3Zps9lcsB/Kv0cuNYWPQrfU9QH2QxW6tMX/hJ7f0r8W/jL4sk+KXxUv8AULNvOjmuLeztEzjcu7A6nuT+tfN8LYOf16dbk9yJz4OHv855n4f8O+JvFEkdpoej3F9K5wFiiZsZ/wBoCvpzwT+xR8dfFMyzXenJ4ftmOHe6bceP9kZP6V+0ngrwzpnhTwxp2kafZRWpit4lcoirlwoBJ9z1NdZ8jr+8Xe9a5lx9WpVvY4Oiel7atM/PPwT/AME+PAWl+Vc+N9WuNcuMfMiHZFn9T+tfZnhP4Z/D7wJaCz8J6Fb6cFJJaFfnbPXLdT+JrvHfZ/t1Xf5q/JcZxNmON/jTNPY/bmSJM6fJu+So2+/RUbvXy3xz55kkb0UVG77aABvv1XepHeo3egqBG9Ru+2pKjb79B1Eb/NRRUbvtoAZN96oqkd91V3oAHeo3eh6jb79aFwI3ejfUb0UGp//V+zEoX79Ro9SJX+b5/RhcqRKro9Sb6DKZYSio0epKzILEP3akquj7akR91AFlPuU+o0fbUifNQZkiPUlV6kR6CZllPuU+q6PVhPmoMSSpEqvUiPQBZT7lPquj1JvrLkAsVIj7aro9SVryGZY++v3aPk/1jrvf+81Ro+2pE+agCOdEuovIu4kmj/uuilf1rw/4g/s1/Bv4mI7+IdAjS5Ygi4t/3bjHqR169817pRXt4bOMXhPfozI5D8r/AB7/AME6rqLzNR+G/iLeiKWNrdJ/F7Pu/wDZa+L/ABl+z18ZPA7u+veFpmiA/wBdar5ibfcrkCv6JN/yUffi8h/ni/iWv0jLfETHUof7ZDngac84H8t7PLp8vzSSQzp8uTmJ1/rXpHhb4xfEvwdIW0HxFdRxrj5C+5DjttPFfvh41+Bvwm8fRsviLwxayzspXz1QLNz/ALYw3618h+Kf+Cdnw+vFluvCet3WmS4+VHAkiz+h/Wv0TDcZZTiof7T7pt9Zh9uB8t6H+3B8RLVI49esLfUwu3DYKt/PH6V7JoP7aPgi+iMOvWFxpDsPvIPMXP6H9K8b8a/sG/GvwpIZtE+y+I7NhkNay7No9GWTb830zXy3r/wz8feFS/8AbXhm9tEH3mMbMB9SRgV639l5Njffwxy+xw9U/WTS/jV8NPEcYbT9dty7jOyUbG/XFdBDNps8y3VjLZyEj70LI5/MZr8Q9/zbE/1v3fm+R63LLX/EWj82moz2p/uiU4/75zivEnwb7k/YzkZzwf8AJM/YTWdP0fVolh1S2S4SM7lV1z8w/irm9b0fRtbsksdYsYLy3j+7Gy1+c+i/Hr4n6REYodR+0R5xiYb/AOfP613mm/tTeKIZFGr6XDcf7uV/xrxP9Vsdh/gmebPBzh8B9keIPBOg+LtLTRNXhYWY2bUjbao2dOmK6zQ/D+maTo8fh22jMlmoMe2Q7vlr5b0r9qnw1MwfUdLe3Pfym3L/AEr0zRv2kfhTfyKJtRNk3pLG/wDQEV4lbKsx+CcA/fQgY+v/ALJvgnXtTkvrW6m0/wA1tzImCn6g19EfDX4a+Hvhnov9ieHoyryHdJM33masfSfi18MNTJaz8SWpK9iwU/kcV6Zpuv8Ah3UFV7HVLecnoEkU/oK4sZWzacPY1vgM51sQeD/Gj9m3T/itqC61pV0ml3+MMWVmDfqKj+CX7Jtt8P8AX18Ua9qg1S5i/wBWqrtVf1NfWFm6TJ+7l+T/AGZK6i2tt/391cP9t5pCl9W+GAvbVfgmfHf7Rn7MPiH4w6/B4s8PajGtzHAIhDKv90s33t3+10xXmfwl/YN8T23im11f4iX9r9js5Fka3Ql/M29t3y8Gv0wtrb5Vj/8AZXroLaGPen3f8/8AAKzhxJjoYf6tCcTp+s1vgI73TpbrQLvTrLBeW1e3j3Hp+72L+VfLf7Gv7Ofjr4Ea14p1XxgLfZqyRpD5bk/dZ27geor7Qs7ZPnk2x7ZPk27XrqLC2k8r59v3k+7vr5+jnWLpUp0fd94z55nwXov7KfjnUv2oZvjl4lv7NtLjuzJDbhiz7MfL82BjHHftX2h8X/A8XxH+Hur+BZrgWo1KPaHIDbT1ztNekIkaW+9F+5/s1zepXjovnzyxJ/vNWU81x2InCt8U4/Ccs/fPhvwp+yHpnhz4K6p8G9X8QPdWerXCXJkiQp5ZQg/d3t/cFeufDP4e6R8JPBNn4J0SRp7azZmLP1Yucn+ddp4h8e+D9GVm1XXbG2I/heZEb8ia+Z/HH7WvwU8Jxsra2uoXOcCG1G9unr0/M19BP+1sw9yZ08k5wPSLrwR4MtPEjeM59LhfVJWXN0w+b5ABx+AFU/E3iDRdC0+TVPEN+ljYK2QSepPT5a+A/Hn7e884a3+H2ifZ227fPvDubPsm3/2Y18N+NfiX4z8fXbXvizVpJ06iPO2Jc/wgdK+ywHCeOxHJPGfAd31CtP35zPpD9oP9pu68fGfwv4QZ4NOB2lyeZuf4faoP2LvhDL8RPijb6/c27No3hJhNJIy5Rpeqrzx7/hXlXwX+BfjP4462lt4egaDTomHnXzp8sK/xbem4+2fyHNfup8NPhp4d+FXhCDwh4Xh8qBVHmSY+aZv7zY/z+FfUZ9j8JkmBnhsN8czp5IQhyUT0BKko3738yo3ev5Z+P35/aOmHuQI2+/UdDvUdaEg71HQ9FABUbffod9tRu9BUCN6jepHeo6DYjd9tRv8ANUjffqOg0I3fbUbvupZvvVFQAVG70PUb0FwB3qu77qkeq9aGoO9G+o3ooA//1vsVPuVOlU0fYtWEev8AN8/owkX79XKppVhHoAsJUiVX31Ij0GUySrEP3ar1Ij7azILFSI+2q6PuqSgCwnzVIlQJ9yn0GZYSpEfbVdHqSgmZYT5qKYn3KfQYkiPUlV6kR6ALCPtqRHqvUiPtoAsVIj7aro9SUGZYT5qKjR9tSJ81ABUm+o6KznCHxgSUf7e5kf8AvK1R1JvoAkd98vnvud/4W3VXuYI7yPybuKKaP+7Iiv8AzqSitIVq1H4JkThCZ4/4m/Z7+DHjGN217wpZySOMeZGvlv8AmuDXzf4g/wCCeHwf1GKRvDV7f6LIx5VZVkU8/wC2C3/j1feFH8dfUYPinM8J8FaQexPyL8T/APBObxnZOG8L+KYdRDfdS6i8pv8A0Jq+e/Ev7HX7QHhy5MT+HTelQW32b+auPTHDbvbFfv5v+Sh3d2+83/fVfb0fETHQh++hzHTCc4H8yerfD/x74fd4Nc0C+sWj+8ZYnUfmRXL/APHmnlv8j7v4lev6kJ7W1uYjDdwJMn911Vv51xesfC/4d64mzUfDdhL/ALTW8e788V9RR8ScPOH76iHtpn8z77Jv3+2N3+5ujkoW4u4ZP3N0/wAn8Su3/wBav6BNf/ZG/Z819JFufClvDKcfvoRsYY/3ceteP6t/wT1+Cl1G76Ve6tZTv0bz4mRf+A+VX0FHjjKav8xp9YPx/tvGPiqwVfseu3luP7sc7Kv5A11Fl8YfinpnyWfiu9Vd2eJmP9a/RzUP+CcPh5oR/Z/jS6hPfzbdXH5iRf5Vw93/AME5NeR2/s/xpbsv/TW2P/sstet/b2R1YfHH/t4z9tD7cD5DtP2kfjlpw223jK9I6/vCsn6sCa6Sy/a+/aKsk8uDxW7p6NErf0r3y7/4J1fEVQDZeLdKlJAyGEi/+yn+Zrn5P+CfPxk/5Y63pL/9tZv/AIzRDGZHL3/3Rnz0f5Dzf/htj9pdP+Zs2f8AbGq91+2h+0rdDB8ZSxD0RI1/9lr0j/h398a92X1HSP8Av7J/8aq5B/wT2+LrnL63o8f/AG0l/wDjVa+2yD7fKHPR/kPB779qf9orUY/Km8fajHGTnEchjH/juK4fUvi18UNVX/ia+L9QvH/6b3FfZlv/AME6fiDtzf8AivTI/wDZQSN/7LXcaH/wTjt3iH9teNXx/F9ltvl/8ekrL+28hpfy/wDbo+eH8h+Yd5qeq38u++u5blv+mjs/86pp8jeXAzbvv7Y13vX7OeGf+Cf/AMG9KPm6ve6nq8m7q8oVP++VUH9a+jPDPwE+EXgoq2g+FrOOZf8Alq6BpMj/AGjz+teJieOMpwvwF+2gfhf4L+CHxW+I1zHD4a8N3EsMjYEzARxdM/efAP4Gvvz4V/8ABPyztJoNZ+LN8L11YMLG3BVcf7Um8E89to+tfpZDDbwrsgiWJP4VRQo/SpN//PT/AMdr88zXj7F4j3MH7kAnzzMfRdH0jw5p8GkaDaxWVnEMBEGDt9W/vH3rUd9/36Puf6uo3fbX5LWrTqz56xlCEIfADvtqN3of5qjesiwd6N9RvRQAVG77aHfbUbvQVAHeo3eh3qOg2Co3fbQ77ajf5qAB/mqN321JUE33qDQR33VHRUb0ADvUe+h6jdKC4A71XoqN60NQd6j31G336N9AH//X+vEerKfcqts21Ij7Fr/N8/owsVIlRp81SJQBcSiq6PVigJkiPUlRpUiVmc5Yh+7UlV0fbUiPuoAsI+2pE+aq9SI+2gCSpEeo0+aigzLCPVhPmqmj1Ij0EzLFFR76kT5qDEkR6kqvUiPQBYR9tSI9V99CPQBc30I9V99SI9BmXE+aiq6PUm+gCSio99SJ81HIAVJvqOispgSb6KjoqAJKKN9G+gzCpN9R76N9aGhJvqOjfRvrMA30b3/vbP8Ado30b6uAB5zp/E3/AAGo/wAG/wC+qKK15IGZIjuv/wC1Q7/7K/8AAqjqN321lyGhJ86b9jbKr7Nn32Z6k31G/wA1HJACTfUb/NRRvrU0Co3eh3qu/wA1AEm+o3eio6AJN9Ru9FR0AFRu+2h321G/zUFQB3qOh6KDYjeo3fbUlRt9+gCN/mooqN320GgO+2o3fdQ77qjoAKjd6Heo3eguAO9V99Sb6rv8taGoVG70VXb79AA/zvUdDvUe+gD/0Prjzt38NSI9U99WEfbX+ckz+kCwj1YR6po9WU+5WRmTpVjfVOpEoAuI9SI9V0fbUiPQZTLFSI+2q6PUlZkFhH3VJVdH21Ij7qALCPtqRPmqvUiPtoAkqRHqNPmooMyxUiPtquj1JQTMsJ81FRo+2pE+agxJKKjqTfQBJUiPtquj1JvoAsI9Sb6po9Sb6ALFSI+2q6PUm+gzJN9G+o6KALCfNRUaPto30cgElFR76N9HIBJRUe+jfRyASUVHvo30cgElFR76N9AA77aN9Rv81FAEm+o3+aijfQAUVG77aj30GhI71HvqN/mooAH+aio99G+gAd6N9R0UAFRu+2h321G/zUFQB/mooqN3oNgd6joqN320ADvtqN/mof5qKDQjd9tRu+6lm+9UVABUb1JUbvQBG9RvUjvVd3rQuAb6jeio3eg1I3fbUb/O9DvUdEAI2+/UdDv89G+teQD/0fqyrFV6k31/nJM/pAsp9yp0fYtV0fbUiPWRmXE+apEqmj1YR6ALFSp9yqyPUiPQEy4lSJVdHqRHoOckqRH21HRWYFhH3VJVdH21Ij7qALCPtqRPmqvUiPtoMySpEeo0+aigCxUiPtquj1JvoJmWE+aiq6PUm+gxJKk31GnzUUASI9Sb6r1JQBIj1JvqvUm+gCTzqkR91V6kR9tAFjfRvqvvo30GZY30b6r76N9AFjfRvqvvo30AWN9G+q++jfQBY30b6r76N9BoWN9Ru+2o99Rv81AEm+jfUdG+gAf5qKN9Ru9AEm+o3ejfUdABRRUbvtoAHfbRvqN/mooKgDvRvqN3o30GwO9R0VG77aAB321G/wA1D/NRQaBUbvtod9tRu+6gAd91R0VG70ADvUbvQ71Xf5qC4A71G70PUb1oag71Xd6kb79V3oAHeo/O+Shvv1HWsAI3ejfUdFWaH//S+rE+aiq6P8lWEev85z+kCTfVhH21XqSomBYR6sp9yqafcqdH2LWRmWKkR6jT5qKALCPVhHqmj1Ij0GUy4j1JVdHqRHoIJKkR9tR0VmBYR91SVXR9tSI+6gCwj7akT5qr1Ij7aDMkqTfUafNRQBIj1JVepEegnkLCPto31HvooCZYT5qKjR9tG+gxLG+jfUafNRQBJvo31HRQBY30b6j30b6AJN9G+o99G+gCSio99G+gCSio99G+gCTfRvqPfRvoAk30b6j30b6AB3o31HRQBJvqOio3fbQBJUbvto31G/zUASb6jd6Kjd6CoEm+o3ejfUdBsFFRu+2jfQaA77ajf5qH+aigAqN320O+2o3fdQAO+6o6Kjd6AB3qOio3fbQXAG+/UdDvUbvWhqDvUbvQ71Xd6AB3qN3od6rv81EAB3qN3oeo3rQ0B3qPfQ336jrQD//T+oU+5VhPuVWR9tSI/wAlf5zn9KzLFSI9Rp81FBkWEerCPVNKsI+2omBYR6sJ81U0epEesjMuJRUaPUlAEiPVhHqulSI+2gOQsI9Sb6ro9SUGUySpEfbUaUVmQWEfdUlV0fbUnnf7NAFhH20b6ro+6pKALCfNRUaPto30GZY30I9Rp81FAFjfRUe+hHoJmWEfbRvqPfRvoMSwnzUVXR6k30ASUVHvo30ASUVHvo30ASUVHvo30ASUVHvo30ASUVHvo30ASUVHvo30ADvto31G/wA1FAEm+o3+ajfUe+gqBJUe+jfUdBpyEm+o6Kjd9tBRJUbvto31G/zUGgP81FFRu+2gAd9tHnf7NRu+6o6AJHfdUdFRu9AA71HRUbvtrQuAO+2o3eh3qN3oNQd6jd6Krt9+gAd6jd6Kjb79EAI3+aiio3etAB3qN3od6ru/z1oaA7/PUe+o3+aigD//1PpxPmqRH21TR/kqwnzV/nOf0rMsI/yVYT5qpo+2pEf5KDIuI+2pE+aq6fNUiUAWEfbUiPVepEfbUTAsI9WEeqaPUiPWRmXEepN9V0epN9AEiPVhHqmj1Ij0AXN9G+o0+aigymWKKjR6koIJEfbUiPuqvUiPtrMCxRUfnf7NCPuoAsI+2jfUdFBmWE+aio0fbRvoAsb6N9Rp81FBPISI9Sb6r1JvoDkJN9G+o99G+gOQk30VHvo30ByElFR76N9AchJRUe+jfQHISUb6j30b6A5CTfRvqPfRvoDkJN9Ru9G+o6A5CTfUdRu+2jfQUSVG77aN9Rv81BoSb6jf5qKjd9tAElRu+2jzv9mo3fdQBJ53+zUbvuqOigAoo31G70ADvUdDvUe+guAO+2o3eh3qN3rQ1B3qN3od6ru9AEm+o3+d6N9Ru9EAI3fbUbvQ71G71oAO9R0VG77a0NAb79V2+/Ujv89V3+agIEbvto31G336N9BryH//1fpFPuU9Hqmj1YR6/wA5z+mC4nzVIj7apo9WE+agiZYR/kqwj1TR9tSI/wAlBkXEepKro9SI9AFhH21Ij1XqRHqJgWEerCfNVNHqRHrIzLFSI9Rp81FAFhHqTfVdHqSgCwj1Ij1XSpN9BlMsb6Kj30I9ZkElSI+2o99FAFjzv9mhH3VXqRH20AWKKj87/Zo87/ZoAsI+2jfVdH3VJQBJvo31HRQBYT5qKjR9tG+gzJKKj30b6AJKKj30b6AJKKj30b6AJKKj30b6AB320b6jf5qKDQk30b6jooAH+aiio3fbQBJUbvto87/ZqN33UASed/s1G77qjooAKKKj30ASVG70b6jd60LgSb6j31HvqN3+eg15Ad/no31HRQAO9Ru9DvVd3oAHeo6Kjd9tAA77ajd6Heo3etYADvUdFRu+2rNAd9tRu/z0O/z1Xf5qAgD/ADVG77aHfbUcz0GhG7/PUe+o9+6ig0P/1voRHqRHquj1Ij1/nOf0wXEerKfcrOR6uJN8lAFipEfbVdH3VJQRMsI/yVYR6po+2pEf5KDIuUJUaPUlAFhHqRHqmlWEfbUTAsI9Sb6ro9Sb6yMywj1Ij1TR6sI9AElWU+5VbfRQBY31Ij1XqRKA5CxvoR6r76kR6DKZY30VHvoR6CCSijfRvrMCRH21J53+zVeigCx53+zR53+zVeigCwj7qkquj7ak87/ZoAkoqPzv9mjzv9mgCSio/O/2aPO/2aAJKKj87/Zo87/ZoAkoqPzv9mjzv9mgCSo3fbR53+zUbvuoAk87/Zo87/ZqvRQBY87/AGajd91R0b6ACijfUdAEm+jfUdG+tAB3qOh3qPfQXAHfbUb/ADUO/wA9G+g1Co3eh3qN3oAk31G71HvqN3oAHeo6Heo99EAB321G70O9Ru9a8gA71HRUbvtpGgO+2o3f56Hf56rv81aBAH+ao3fbQ77ajd6DQHeq7vUjvVd3oNAo31G70b6AP//X94R6sI9U0epEev8AOs/pguI9SI9V0+dKsJWYFxJvkqRH3VTR9tWEm+SgCxUqfcqsj7qsI+2giZYR9tSI9U99SI/yUGRc30b6jT5qKALCPUm+q6PUlRMCwj1Ij1XR6kR6yMyxvqRHqvvoR6ALm+jfUafNRQBYqRH21XR6k30ASb6kR6r76kR/koDkLG+jfVffRvoMplhHqTfVffUm+syCTfRUe+jfQBJRUe+pN9aAFFG+jfWYBRRvo30AFFG+jfQAUUb6N9ABRvqN3o31oBJvo31Hvo31mXAKKN9R760NeQk30b6j31HvoDkJN9G+q7v89R0ByEjv89R0Ub6ACjfUbvUe+gCR3qu70O9Ru9AEm+o3eo99Rv8ANRAAf5qKKjd60AHeo6Kjd9taGgO+2o3f56Hf56rv81AQB/mqN320O+2o3eg0B3qN3od6ru9BoDvUbvQ71G70ADvUe+o3f56j30Af/9D3BN/92rCI9aiW2xak8n/Zr/Oz3D+mDLT5asI7/wB2tBLbfVhIdi0gMvL/ANypId5X7taiW2+rCW1Zkc5lpvT+GpN7/wB2tRIak8mgyMtPMf8AgqRN9aiW1SfZtlRMftIGem/+7UmX/uVoJD8n3asJD/s1lzmXOZab/wC7RtetTZs/hqXYP7lAc5lIlSJWh9m30fZfegy5ynl/7lGX/uVsQw/LUnk/7NAc5lpv2fdqT560EtqsJbUBzmXl/wC5UeX/ALlbH2X3o8msw5zH3v8A3aky/wDcrU8mpfJjoDnMbL/3Kk+etnyY6ie2oDnKCfcp77/7tXPsvvUnk7KB+4Z6VJsq55O+pEhoMueBn7KK0PJo8mgOcz6K0PJo8mgOcz6K0HhoSGgOcz6K0HhoSGgOcz6K0PJo8mgOcz9lGytDyaPJoDnM/ZUeytR4ajeGgITM96rvv3fdrU+y+9SfZfeg05zDy/8Aco3un8Fbnk/7NR+TQHOYe9/7tSZf+5Wx5NR/ZfegOcx/norY+y+9RvbUBzmO/wA1Rvv/ALtbDw0eTWgc5h1G9bj2e+q72f8AtUBzmPRl/wC5Wo9ts/26PJ/2aDXnMd9/92o3d/7tbDp/s0eTv/ho5w54GHvf+7Ubu/8AdrYe2+ao3tqOcOcw3d9/3aj3v/drYe2o8n/ZrWBpAx3qu+/d92th7be1R/Zv9mrNecw33/3ajff/AHa3Hh/2aj+zf7NAc5h5f+5Vd9+77tdA9tUf2X3qoBA5t9/92jL/ANyuge2qP7L71fuFn//R+rEh/wBmpPJrYSFKPJ31/m+f0h7Yy0tqkS2rUS2qRLagz5zPhh+WpNmz+GtRIdi1YRKOcy5zH8nf/DUkMPy1sJCn92jyaOcOcz/svvUn2X3rQSGpNlHOHOZn2eOp0tquJDVhIazM+cy/JqXyY6v+TUnk0DM9IU/u1J5P+zWgkNHk0GZn+TUiJtrQ8mjyaDHnKfk76PJrQ8mpPJoJM/yaPJrQ8mpPJoAy/s2+h7bZWpsqRId9AGOkNHk/7NbiQ7Kk8n/ZoK5zn/J/2akSH/Zrc8n/AGaXZH/doDnMb7L70fZfetjyd9Hk0BzmO8NHk1sbNn8O+jyd/wDsUC9wy/JqN4a2PJqTyaA9wxNg/uUbB/crb8pP7lHlJ/coEYmwf3Kf5O+tjyk/uUPDQZmG8NL5L/3a2/Jo8pP7lAGJ5L/3aPJf+7W35Sf3KPKT+5Qa+4c/5MlSfZfetx0T+7UbpQHuGG8Oyo/J/wBmug8mjyf9mgfOYaQ1G8Pz1uPDUf2X3oDnMdLbfQ9tWw8Oyo9lBJj+TR5Nank0eT/tUAZfk1G8Pz1seTUbw0AY7w1G8NbHk1H5NBtzmP5NHlJ/crUeGo/JoD3Sh5MdRPDWp5NRvDQa85lvbb6Z9njrX8mo3hoDnMd7aOq723zVuPDUfk0GnOYbps/hqPyd/wDDXQeTUbw1pzhznPvD/s1G9tXQPDVd4aOcOcw3tqrvbfNW48NRvDRzmsJmG9tUf2X3roPJpdg/uUGnOf/S+2PJqRIasVIlf5tn9CFdIasbKkSigzI9lSbKlT7lPoJmRolSbKkSpU+5QYkSQ1J5NWEqRKAK/k0bKsUUGZHsqRIalT7lTpQBX2UbKsUUF8xGkO+pPJqxD92pKJkFfZQkNWKkSs+YCv5NHk1YqVPuUcxUyt5NSJD8lWKkSjmM7sr7KNlWKKOYkr7KEtt9WKsQ/do5gKf2X3qTyauUUcwFPyaPJq5RRzAU/Jo8mrlFHMZlPyaPJq5RRzAU/Jo8mrlFHMbXZT8mjyauUUcwXZT8mjyauUUcxJn/AGX3qN4dlalQTfeo5gKWyjZViijmAr7Kj2VcqN6OYCm8O+jyauUUcxUJGf5NRulaDffqu9HMUV9lRvDVyilACn5NRum2tCoJvvVqaFLZUbw1cqN6DMp+TQ8NXKjb79AFPyajeGrlRvQaFN4aj8mrj0UF8xT2VG6Vcb79V3oFAr7KjeGrlRt9+g2Kfk1G8NXKjeg0Kfk7KNlWHooA/9k=','0.00','active','0','0','2025-11-05 03:25:17','2025-11-11 18:25:33');

-- هيكل الجدول `vehicle_inventory`
DROP TABLE IF EXISTS `vehicle_inventory`;
CREATE TABLE `vehicle_inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `product_category` varchar(100) DEFAULT NULL,
  `product_unit` varchar(50) DEFAULT NULL,
  `product_unit_price` decimal(15,2) DEFAULT NULL,
  `manager_unit_price` decimal(15,2) DEFAULT NULL,
  `finished_batch_id` int(11) DEFAULT NULL,
  `finished_batch_number` varchar(100) DEFAULT NULL,
  `finished_production_date` date DEFAULT NULL,
  `finished_quantity_produced` decimal(12,2) DEFAULT NULL,
  `finished_workers` text DEFAULT NULL,
  `product_snapshot` longtext DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_updated_by` int(11) DEFAULT NULL,
  `last_updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehicle_product_unique` (`vehicle_id`,`product_id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `vehicle_inventory_ibfk_4` (`last_updated_by`),
  CONSTRAINT `vehicle_inventory_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vehicle_inventory_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vehicle_inventory_ibfk_3` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vehicle_inventory_ibfk_4` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `vehicle_inventory`
INSERT INTO `vehicle_inventory` (`id`, `vehicle_id`, `warehouse_id`, `product_id`, `product_name`, `product_category`, `product_unit`, `product_unit_price`, `manager_unit_price`, `finished_batch_id`, `finished_batch_number`, `finished_production_date`, `finished_quantity_produced`, `finished_workers`, `product_snapshot`, `quantity`, `last_updated_by`, `last_updated_at`, `created_at`) VALUES
('1','4','3','22','منتج رقم 8','finished','قطعة','0.00','0.00','6','251115-102778','2025-11-15','1.00',NULL,'{\"id\":22,\"name\":\"منتج رقم 8\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"0.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"0.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-11-15 09:26:08\",\"updated_at\":\"2025-11-15 09:26:32\"}','0.00','1','2025-11-18 11:40:14','2025-11-16 03:09:21'),
('2','4','3','19','منتج رقم 6','finished','قطعة','0.00','0.00','5','251115-765452','2025-11-15','1.00',NULL,'{\"id\":19,\"name\":\"منتج رقم 6\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"0.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"0.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-11-15 07:44:53\",\"updated_at\":\"2025-11-15 07:51:06\"}','0.00','3','2025-11-17 07:28:34','2025-11-16 03:13:46'),
('3','4','3','17','منتج رقم 7','finished','قطعة','0.00','0.00','4','251115-185290','2025-11-15','1.00',NULL,'{\"id\":17,\"name\":\"منتج رقم 7\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"0.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"0.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-11-15 07:44:33\",\"updated_at\":\"2025-11-15 07:51:06\"}','0.00','3','2025-11-17 06:37:09','2025-11-16 03:25:08'),
('4','4','3','13','منتج رقم 4','finished','قطعة','0.00','0.00','3','251115-058200','2025-11-15','1.00',NULL,'{\"id\":13,\"name\":\"منتج رقم 4\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"0.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"0.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-11-15 06:27:38\",\"updated_at\":\"2025-11-15 06:50:00\"}','0.00','1','2025-11-18 13:07:21','2025-11-16 06:07:56'),
('5','4','3','7','منتج رقم 3','finished','قطعة','0.00','0.00','2','251115-238486','2025-11-15','1.00',NULL,'{\"id\":7,\"name\":\"منتج رقم 3\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"0.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"0.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-11-15 05:58:32\",\"updated_at\":\"2025-11-15 06:06:34\"}','0.00','1','2025-11-18 16:36:19','2025-11-17 04:40:23'),
('6','4','3','24','صابون كبير','منتجات خارجية','قطعة','20.00','20.00',NULL,NULL,NULL,NULL,NULL,'{\"id\":24,\"name\":\"صابون كبير\",\"category\":\"منتجات خارجية\",\"unit\":\"قطعة\",\"unit_price\":\"20.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"4.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-11-17 08:55:05\",\"updated_at\":\"2025-11-18 16:49:22\"}','1.00','3','2025-11-18 19:23:00','2025-11-17 09:01:58');

-- هيكل الجدول `vehicles`
DROP TABLE IF EXISTS `vehicles`;
CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_number` varchar(50) NOT NULL,
  `vehicle_type` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL COMMENT 'مندوب المبيعات صاحب السيارة',
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehicle_number` (`vehicle_number`),
  KEY `driver_id` (`driver_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vehicles_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `vehicles`
INSERT INTO `vehicles` (`id`, `vehicle_number`, `vehicle_type`, `model`, `year`, `driver_id`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('4','2020 س ط ل','نص نقل','شيفروليه','2025','3','active','','1','2025-11-08 02:45:38',NULL);

-- هيكل الجدول `warehouse_transfer_items`
DROP TABLE IF EXISTS `warehouse_transfer_items`;
CREATE TABLE `warehouse_transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_id` (`batch_id`),
  KEY `batch_number` (`batch_number`),
  CONSTRAINT `warehouse_transfer_items_ibfk_1` FOREIGN KEY (`transfer_id`) REFERENCES `warehouse_transfers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfer_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `warehouse_transfer_items`
INSERT INTO `warehouse_transfer_items` (`id`, `transfer_id`, `product_id`, `batch_id`, `batch_number`, `quantity`, `notes`, `created_at`) VALUES
('7','14','19','5','251115-765452','1.00',NULL,'2025-11-16 02:11:25'),
('8','15','22','6','251115-102778','1.00',NULL,'2025-11-16 02:24:10'),
('9','16','17','4','251115-185290','1.00',NULL,'2025-11-16 03:21:46'),
('10','22','13','3','251115-058200','1.00',NULL,'2025-11-16 06:07:56'),
('11','23','7','2','251115-238486','1.00',NULL,'2025-11-17 04:23:10'),
('12','26','24',NULL,NULL,'5.00',NULL,'2025-11-17 09:01:58'),
('13','28','24',NULL,NULL,'1.00','','2025-11-17 09:36:40'),
('14','29','24',NULL,NULL,'1.00','','2025-11-17 09:47:28'),
('15','30','24',NULL,NULL,'3.00','','2025-11-17 10:32:23'),
('16','31','24',NULL,NULL,'1.00','','2025-11-17 10:47:10'),
('17','32','24',NULL,NULL,'1.00','','2025-11-17 10:48:22'),
('18','33','24',NULL,NULL,'1.00','','2025-11-17 10:49:41'),
('19','36','13','3','251115-058200','1.00','','2025-11-18 11:11:39'),
('20','37','22','6','251115-102778','1.00','','2025-11-18 11:40:08'),
('21','38','13','3','251115-058200','1.00','','2025-11-18 13:06:49'),
('22','39','24',NULL,NULL,'1.00','','2025-11-18 14:14:51'),
('23','40','24',NULL,NULL,'1.00','','2025-11-18 14:28:43'),
('24','41','24',NULL,NULL,'3.00',NULL,'2025-11-18 16:34:26'),
('25','42','24',NULL,NULL,'2.00',NULL,'2025-11-18 16:34:55'),
('26','43','24',NULL,NULL,'2.00','','2025-11-18 16:36:05'),
('27','43','7','2','251115-238486','1.00','','2025-11-18 16:36:05'),
('28','44','24',NULL,NULL,'10.00',NULL,'2025-11-18 16:49:22');

-- هيكل الجدول `warehouse_transfers`
DROP TABLE IF EXISTS `warehouse_transfers`;
CREATE TABLE `warehouse_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_number` varchar(50) NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `transfer_date` date NOT NULL,
  `transfer_type` enum('to_vehicle','from_vehicle','between_warehouses') DEFAULT 'to_vehicle',
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','completed','cancelled') DEFAULT 'pending',
  `requested_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transfer_number` (`transfer_number`),
  KEY `from_warehouse_id` (`from_warehouse_id`),
  KEY `to_warehouse_id` (`to_warehouse_id`),
  KEY `transfer_date` (`transfer_date`),
  KEY `status` (`status`),
  KEY `requested_by` (`requested_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `warehouse_transfers_ibfk_1` FOREIGN KEY (`from_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_2` FOREIGN KEY (`to_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_3` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `warehouse_transfers`
INSERT INTO `warehouse_transfers` (`id`, `transfer_number`, `from_warehouse_id`, `to_warehouse_id`, `transfer_date`, `transfer_type`, `reason`, `status`, `requested_by`, `approved_by`, `approved_at`, `rejection_reason`, `notes`, `created_at`, `updated_at`) VALUES
('14','TRF-202511-0002','2','3','2025-11-16','to_vehicle',NULL,'completed','4','1','2025-11-16 03:13:46',NULL,NULL,'2025-11-16 02:11:25','2025-11-16 03:13:46'),
('15','TRF-202511-0003','2','3','2025-11-16','to_vehicle',NULL,'completed','4','1','2025-11-16 03:09:21',NULL,NULL,'2025-11-16 02:24:10','2025-11-16 03:09:21'),
('16','TRF-202511-0004','2','3','2025-11-16','to_vehicle',NULL,'completed','4','1','2025-11-16 03:25:08',NULL,NULL,'2025-11-16 03:21:46','2025-11-16 03:25:08'),
('21','TRF-202511-0005','2','3','2025-11-16','to_vehicle','نقل منتجات من مخزن الشركة إلى مخزن السيارة','approved','1','1','2025-11-16 06:01:05',NULL,'','2025-11-16 06:01:05',NULL),
('22','TRF-202511-0006','2','3','2025-11-16','to_vehicle','نقل منتجات من مخزن الشركة إلى مخزن السيارة','completed','1','1','2025-11-16 06:07:56',NULL,'','2025-11-16 06:07:56','2025-11-16 06:07:56'),
('23','TRF-202511-0007','2','3','2025-11-17','to_vehicle','كده','completed','4','1','2025-11-17 04:40:23',NULL,NULL,'2025-11-17 04:23:10','2025-11-17 04:40:23'),
('24','TRF-202511-0008','3','2','2025-11-17','from_vehicle','','rejected','3','1','2025-11-17 08:58:37','كده','','2025-11-17 08:51:37','2025-11-17 08:58:37'),
('25','TRF-202511-0009','3','2','2025-11-17','from_vehicle','','rejected','3','1','2025-11-17 09:01:34','1','','2025-11-17 08:59:16','2025-11-17 09:01:34'),
('26','TRF-202511-0010','2','3','2025-11-17','to_vehicle','نقل منتجات من مخزن الشركة إلى مخزن السيارة','completed','1','1','2025-11-17 09:01:59',NULL,'','2025-11-17 09:01:58','2025-11-17 09:01:58'),
('27','TRF-202511-0011','3','2','2025-11-17','from_vehicle','','rejected','3','1','2025-11-17 09:36:53','6','','2025-11-17 09:09:59','2025-11-17 09:36:53'),
('28','TRF-202511-0012','3','2','2025-11-17','from_vehicle','0','rejected','3','1','2025-11-17 09:52:11','6','','2025-11-17 09:36:40','2025-11-17 09:52:11'),
('29','TRF-202511-0013','3','2','2025-11-17','from_vehicle','0','rejected','3','1','2025-11-17 09:52:04','3','','2025-11-17 09:47:28','2025-11-17 09:52:04'),
('30','TRF-202511-0014','3','2','2025-11-17','from_vehicle','','rejected','3','1','2025-11-17 10:47:28','1','','2025-11-17 10:32:23','2025-11-17 10:47:28'),
('31','TRF-202511-0015','2','3','2025-11-17','to_vehicle','','completed','3','1','2025-11-17 10:47:36',NULL,'','2025-11-17 10:47:10','2025-11-17 10:47:36'),
('32','TRF-202511-0016','3','2','2025-11-17','from_vehicle','','completed','3','1','2025-11-17 10:48:41',NULL,'','2025-11-17 10:48:22','2025-11-17 10:48:41'),
('33','TRF-202511-0017','3','2','2025-11-17','from_vehicle','','completed','3','1','2025-11-17 10:49:49',NULL,'','2025-11-17 10:49:41','2025-11-17 10:49:49'),
('34','TRF-202511-0018','3','2','2025-11-18','from_vehicle','','rejected','3','1','2025-11-18 11:07:32','11','','2025-11-18 00:26:57','2025-11-18 11:07:32'),
('36','TRF-202511-0019','3','2','2025-11-18','from_vehicle','','rejected','3','1','2025-11-18 11:12:33','ش','','2025-11-18 11:11:39','2025-11-18 11:12:33'),
('37','TRF-202511-0020','3','2','2025-11-18','from_vehicle','','completed','3','1','2025-11-18 11:40:14',NULL,'','2025-11-18 11:40:08','2025-11-18 11:40:14'),
('38','TRF-202511-0021','3','2','2025-11-18','from_vehicle','','completed','3','1','2025-11-18 13:07:21',NULL,'','2025-11-18 13:06:49','2025-11-18 13:07:21'),
('39','TRF-202511-0022','3','2','2025-11-18','from_vehicle','','completed','3','1','2025-11-18 14:19:12',NULL,'','2025-11-18 14:14:51','2025-11-18 14:19:12'),
('40','TRF-202511-0023','3','2','2025-11-18','from_vehicle','','completed','3','1','2025-11-18 14:28:57',NULL,'','2025-11-18 14:28:43','2025-11-18 14:28:57'),
('41','TRF-202511-0024','2','3','2025-11-18','to_vehicle','نقل منتجات من مخزن الشركة إلى مخزن السيارة','completed','1','1','2025-11-18 16:34:26',NULL,'','2025-11-18 16:34:26','2025-11-18 16:34:26'),
('42','TRF-202511-0025','3','2','2025-11-18','from_vehicle','نقل منتجات من بضاعة المندوب (مندوب اسامه) إلى المخزن الرئيسي','completed','1','1','2025-11-18 16:34:55',NULL,'','2025-11-18 16:34:55','2025-11-18 16:34:55'),
('43','TRF-202511-0026','3','2','2025-11-18','from_vehicle','','completed','3','1','2025-11-18 16:36:19',NULL,'','2025-11-18 16:36:05','2025-11-18 16:36:19'),
('44','TRF-202511-0027','2','3','2025-11-18','to_vehicle','نقل منتجات من مخزن الشركة إلى مخزن السيارة','completed','1','1','2025-11-18 16:49:22',NULL,'','2025-11-18 16:49:22','2025-11-18 16:49:22');

-- هيكل الجدول `warehouses`
DROP TABLE IF EXISTS `warehouses`;
CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `warehouse_type` enum('main','vehicle') DEFAULT 'main',
  `vehicle_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `warehouse_type` (`warehouse_type`),
  KEY `vehicle_id` (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `warehouses`
INSERT INTO `warehouses` (`id`, `name`, `location`, `description`, `warehouse_type`, `vehicle_id`, `status`, `created_at`, `updated_at`) VALUES
('2','مخزن الشركة الرئيسي',NULL,NULL,'main',NULL,'active','2025-11-05 23:21:30',NULL),
('3','مخزن سيارة 2020 س ط ل','سيارة',NULL,'vehicle','4','active','2025-11-08 02:45:38',NULL);

-- هيكل الجدول `webauthn_credentials`
DROP TABLE IF EXISTS `webauthn_credentials`;
CREATE TABLE `webauthn_credentials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `credential_id` varchar(255) NOT NULL,
  `public_key` text NOT NULL,
  `counter` bigint(20) DEFAULT 0,
  `device_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_used` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_id` (`credential_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `webauthn_credentials_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات الجدول `webauthn_credentials`
INSERT INTO `webauthn_credentials` (`id`, `user_id`, `credential_id`, `public_key`, `counter`, `device_name`, `created_at`, `last_used`) VALUES
('4','4','Dz0lHGOE2h8Mu2mmbXmpRs/yycs=','pQECAyYgASFYICbgjjt64U8dNfEA2tfMi3esqqMfM3Y1POlfZTwKHcIeIlggl3GjxHovDfhZnvrkvK50U9DjT0rBK+2qxkS3G3itoJc=','8','3','2025-11-06 18:35:34','2025-11-10 06:02:46'),
('6','6','yR2cPlbS+LYRPbVRc6e6fMl55us=','pQECAyYgASFYIMxIkVXhAvA9n5MDesj1kjyPAJgczuE9MfmDIQNAW4ViIlggLal4DBSeEs6NcYmOIu8Ay8zkrvmwMVYFMuelZ6SDn8s=','3','1st','2025-11-06 19:04:52','2025-11-11 20:40:35'),
('10','3','SQJkI1JNcz5S9pP1/3T4sBlIGFc=','pQECAyYgASFYINLPEJDM+nNvNmEm4enyCpmYxkH9o2tDNHOnCOfx0gdPIlggrjh3iL6pymmtkDA9iq+YaWNhmcB0Fs5uAwrLH3eF0cQ=','2','iPhone','2025-11-10 09:10:23','2025-11-10 10:04:26'),
('11','1','kBULwmQv1W2ZI+zIfMJUvedMYVg=','pQECAyYgASFYIHP9i8x7oJIFWanny4F5up5CBBmRIT5OVCvg5kYTCUYOIlggGYZNpyD83Oyks0gU0C5stdZbpIwKaRt8VqI/Q0DbDco=','3','Windows','2025-11-14 18:35:24','2025-11-17 11:04:28');

COMMIT;
SET FOREIGN_KEY_CHECKS=1;
SET AUTOCOMMIT=1;
